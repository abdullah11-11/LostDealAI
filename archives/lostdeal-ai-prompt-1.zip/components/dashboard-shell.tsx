"use client";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { BrandLogo } from "@/components/brand-logo";

const nav = [["/dashboard", "Overview"], ["/deals", "Lost deals"], ["/upload", "Upload"]];

function NavLinks({ mobile = false }: { mobile?: boolean }) {
  const pathname = usePathname();
  return <nav aria-label="Dashboard navigation" className={mobile ? "flex gap-2" : "space-y-1.5"}>{nav.map(([href, label]) => { const active = pathname === href || (href === "/deals" && pathname.startsWith("/deals/")); return <Link key={href} href={href} aria-current={active ? "page" : undefined} className={`flex shrink-0 items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-semibold ${active ? "bg-blue-50 text-[#2952cc]" : "text-slate-600 hover:bg-slate-50 hover:text-slate-950"}`}><span className={`size-2 rounded-full ${active ? "bg-[#2952cc]" : "bg-slate-300"}`} />{label}</Link>; })}</nav>;
}

export function DashboardShell({ children }: { children: React.ReactNode }) {
  return <div className="min-h-screen bg-[#f7f8fb]"><aside className="fixed inset-y-0 left-0 z-30 hidden w-64 border-r border-slate-200 bg-white lg:flex lg:flex-col"><div className="flex h-18 items-center border-b border-slate-200 px-5"><BrandLogo /></div><div className="flex-1 px-3 py-5"><p className="mb-3 px-3 text-[10px] font-bold uppercase tracking-[0.16em] text-slate-400">Workspace</p><NavLinks /></div><div className="border-t border-slate-200 p-5 text-xs leading-5 text-slate-400">Prompt 1 foundation<br />No customer data connected</div></aside><div className="lg:pl-64"><header className="sticky top-0 z-20 border-b border-slate-200 bg-white/95 backdrop-blur"><div className="flex h-18 items-center justify-between px-4 sm:px-6 lg:px-8"><div className="lg:hidden"><BrandLogo compact /></div><div className="hidden lg:block"><p className="text-xs font-semibold text-slate-400">LostDeal AI</p><p className="mt-0.5 text-sm font-bold text-slate-800">Recovery workspace</p></div><div className="flex items-center gap-2"><span className="hidden rounded-full border border-blue-200 bg-blue-50 px-3 py-1.5 text-[10px] font-bold uppercase tracking-wide text-blue-700 sm:inline-flex">Foundation preview</span><Link href="/upload" className="inline-flex h-9 items-center rounded-xl bg-[#172554] px-3.5 text-sm font-bold text-white">Import deals</Link></div></div><div className="overflow-x-auto border-t border-slate-100 px-3 py-2 lg:hidden"><NavLinks mobile /></div></header><main className="px-4 py-6 sm:px-6 sm:py-8 lg:px-8 lg:py-10">{children}</main></div></div>;
}
