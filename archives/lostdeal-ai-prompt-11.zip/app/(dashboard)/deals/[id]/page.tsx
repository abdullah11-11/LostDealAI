import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import {
  AlertCircle,
  ArrowLeft,
  Bot,
  Calculator,
  CalendarClock,
  Clock3,
  Database,
  FileText,
  LayoutDashboard,
  Lightbulb,
  LoaderCircle,
  MessageSquareText,
  ShieldCheck,
  Target,
  ThumbsDown,
  ThumbsUp,
} from "lucide-react";

import { AnalyzeDealButton } from "@/components/analyze-deal-button";
import { CalculateRecoveryScoreButton } from "@/components/calculate-recovery-score-button";
import { CopyMessageButton } from "@/components/copy-message-button";
import { DealPriorityBadge, DealStatusBadge } from "@/components/deal-status";
import { ExpandableTranscript } from "@/components/expandable-transcript";
import { Badge, Card, buttonStyles } from "@/components/ui";
import { requireOrganization } from "@/lib/auth/server";
import { getSafeNextPath } from "@/lib/auth/validation";
import { formatDealCurrency, formatDealDate, formatDealTimestamp, humanizeDealEnum } from "@/lib/deals/format";
import { deriveDealExperienceState, evidenceIsGrounded, type DealExperienceState } from "@/lib/deals/intelligence";
import { getDealDetail, type DealAnalysisDetail, type DealDetail } from "@/lib/deals/server";
import { createClient } from "@/lib/supabase/server";

export const metadata: Metadata = { title: "Deal intelligence" };
export const dynamic = "force-dynamic";

const UUID_PATTERN = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;

export default async function DealPage({
  params,
  searchParams,
}: {
  params: Promise<{ id: string }>;
  searchParams: Promise<Record<string, string | string[] | undefined>>;
}) {
  const [{ id }, query] = await Promise.all([params, searchParams]);
  const decodedId = decodeURIComponent(id);
  if (!UUID_PATTERN.test(decodedId)) notFound();

  const context = await requireOrganization(`/deals/${encodeURIComponent(decodedId)}`);
  const supabase = await createClient();
  const result = await getDealDetail(supabase, context.organization.id, decodedId);
  if (!result.error && !result.deal) notFound();

  const rawFrom = typeof query.from === "string" ? query.from : null;
  const safeFrom = getSafeNextPath(rawFrom);
  const backHref = safeFrom === "/deals" || safeFrom.startsWith("/deals?") ? safeFrom : "/deals";

  if (result.error || !result.deal) return <DealLoadError dealId={decodedId} backHref={backHref} />;

  const deal = result.deal;
  const analysis = deal.analysis;
  const experience = deriveDealExperienceState({
    analysisStatus: deal.analysis_status,
    hasAnalysis: Boolean(analysis),
    recoveryScore: analysis?.recovery_score ?? null,
    recoveryPriority: analysis?.recovery_priority ?? null,
    recommendedChannel: analysis?.recommended_channel ?? null,
  });

  return (
    <main className="mx-auto max-w-7xl">
      <DealHeader deal={deal} backHref={backHref} />

      {analysis && deal.analysis_status === "completed" ? (
        <div className="mt-7 space-y-5">
          <RecoverySummary analysis={analysis} />
          <RecommendedNextAction analysis={analysis} noAction={experience === "no_action"} />
          <SuggestedFollowUp analysis={analysis} noAction={experience === "no_action"} />
          <WhyLost analysis={analysis} />
          <SignalSections analysis={analysis} />
          <EvidenceSection deal={deal} analysis={analysis} />
          <RecoveryScoreBreakdown deal={deal} />
        </div>
      ) : (
        <div className="mt-7"><AnalysisStateCard deal={deal} experience={experience} /></div>
      )}

      <SourceSeparationNote />
      <SourceSections deal={deal} />
    </main>
  );
}

function DealLoadError({ dealId, backHref }: { dealId: string; backHref: string }) {
  return (
    <main className="mx-auto max-w-3xl">
      <Link href={backHref} className="inline-flex items-center gap-2 text-sm font-semibold text-slate-500 hover:text-slate-900">
        <ArrowLeft aria-hidden="true" className="size-4" /> Back to Deals
      </Link>
      <div role="alert" className="mt-8 rounded-2xl border border-red-200 bg-white p-8 text-center shadow-sm">
        <AlertCircle aria-hidden="true" className="mx-auto size-9 text-red-600" />
        <h1 className="mt-4 text-xl font-bold text-slate-950">This deal could not be loaded</h1>
        <p className="mt-2 text-sm leading-6 text-slate-500">Your data has not changed. Try again shortly.</p>
        <Link href={`/deals/${dealId}?from=${encodeURIComponent(backHref)}`} className={buttonStyles("outline", "mt-6")}>Try again</Link>
      </div>
    </main>
  );
}

function DealHeader({ deal, backHref }: { deal: DealDetail; backHref: string }) {
  const hasCompleteScore = deal.analysis?.recovery_score !== null && deal.analysis?.recovery_score !== undefined && Boolean(deal.analysis.recovery_priority);
  return (
    <>
      <nav aria-label="Deal navigation" className="flex flex-wrap items-center justify-between gap-3">
        <Link href={backHref} className="inline-flex min-h-10 items-center gap-2 rounded-lg text-sm font-semibold text-slate-500 hover:text-slate-900 focus-visible:outline-none focus-visible:ring-4 focus-visible:ring-blue-100">
          <ArrowLeft aria-hidden="true" className="size-4" /> Back to Deals
        </Link>
        <Link href="/dashboard" className="inline-flex min-h-10 items-center gap-2 rounded-lg px-2 text-sm font-semibold text-slate-500 hover:bg-slate-100 hover:text-slate-900 focus-visible:outline-none focus-visible:ring-4 focus-visible:ring-blue-100">
          <LayoutDashboard aria-hidden="true" className="size-4" /> View Overview
        </Link>
      </nav>

      <header className="mt-5 rounded-2xl border border-slate-200 bg-white p-5 shadow-sm sm:p-7">
        <div className="flex flex-col gap-6 lg:flex-row lg:items-start lg:justify-between">
          <div className="min-w-0">
            <div className="flex flex-wrap items-center gap-2">
              <DealStatusBadge status={deal.analysis_status} />
              {deal.external_deal_id && <Badge tone="neutral">{deal.external_deal_id}</Badge>}
            </div>
            <h1 className="mt-4 break-words text-3xl font-semibold tracking-[-0.025em] text-[#0b1739] sm:text-4xl">{deal.customer_name || "Unnamed customer"}</h1>
            <p className="mt-2 text-sm leading-6 text-slate-500">
              {deal.service_type || "Service not provided"} <span aria-hidden="true">·</span> Quoted {formatDealDate(deal.quote_date)}
            </p>
          </div>
          <div className="grid shrink-0 gap-3 sm:grid-cols-2 lg:min-w-[25rem]">
            <HeaderMetric label="Deal Value" value={formatDealCurrency(deal.deal_value)} detail="Imported source value" />
            <HeaderMetric
              label="Recovery"
              value={hasCompleteScore ? `${deal.analysis?.recovery_score}/100` : "Not scored"}
              detail={hasCompleteScore ? `${humanizeDealEnum(deal.analysis?.recovery_priority ?? null)} priority` : "Persisted score status"}
            />
          </div>
        </div>
      </header>
    </>
  );
}

function HeaderMetric({ label, value, detail }: { label: string; value: string; detail: string }) {
  return (
    <div className="rounded-xl border border-slate-200 bg-slate-50 px-4 py-3">
      <p className="text-[10px] font-extrabold uppercase tracking-[0.12em] text-slate-500">{label}</p>
      <p className="mt-1 text-xl font-semibold tracking-tight text-[#0b1739]">{value}</p>
      <p className="mt-1 text-[11px] leading-5 text-slate-500">{detail}</p>
    </div>
  );
}

function RecoverySummary({ analysis }: { analysis: DealAnalysisDetail }) {
  const hasCompleteScore = analysis.recovery_score !== null && Boolean(analysis.recovery_priority);
  return (
    <Card
      title="Recovery Summary"
      description="The recovery decision at a glance"
      action={hasCompleteScore ? <DealPriorityBadge priority={analysis.recovery_priority} /> : <Badge tone="neutral">Unscored</Badge>}
      className="overflow-hidden border-blue-200 shadow-md"
    >
      <dl className="grid gap-px bg-slate-200 sm:grid-cols-2 xl:grid-cols-5">
        <SummaryMetric label="Recovery Score" value={hasCompleteScore ? `${analysis.recovery_score}/100` : "Not scored yet"} detail="Deterministic ranking" />
        <SummaryMetric label="Lost Reason" value={humanizeDealEnum(analysis.lost_reason)} detail="AI classification" />
        <SummaryMetric label="Buying Intent" value={`${analysis.buying_intent_score}/100`} detail="How strongly source data suggests intent to purchase" />
        <SummaryMetric
          label="Analysis Confidence"
          value={`${analysis.confidence_score}/100`}
          detail={analysis.confidence_score < 40 ? "Low confidence — review source evidence" : "How strongly notes or transcript support the analysis"}
          warning={analysis.confidence_score < 40}
        />
        <SummaryMetric label="Recommended Timing" value={analysis.recommended_timing || "Not provided"} detail="AI recommendation" />
      </dl>
      <p className="border-t border-slate-100 px-5 py-3 text-xs leading-5 text-slate-500 sm:px-6">
        Recovery Score is a prioritization indicator based on stored deal signals. It is not a probability, prediction, or guarantee of conversion.
      </p>
    </Card>
  );
}

function SummaryMetric({ label, value, detail, warning = false }: { label: string; value: string; detail: string; warning?: boolean }) {
  return (
    <div className="bg-white p-5">
      <dt className="text-[10px] font-extrabold uppercase tracking-[0.1em] text-slate-500">{label}</dt>
      <dd className="mt-2 break-words text-lg font-bold leading-6 text-[#0b1739]">{value}</dd>
      <dd className={`mt-2 text-xs leading-5 ${warning ? "font-semibold text-amber-700" : "text-slate-500"}`}>{detail}</dd>
    </div>
  );
}

function RecommendedNextAction({ analysis, noAction }: { analysis: DealAnalysisDetail; noAction: boolean }) {
  return (
    <Card
      title={noAction ? "No Active Recovery Recommended" : "Recommended Next Action"}
      description={noAction ? "A restrained outcome based on the stored analysis" : "The clearest next step from the persisted analysis"}
      action={noAction ? <ShieldCheck aria-hidden="true" className="size-6 text-amber-700" /> : <Target aria-hidden="true" className="size-6 text-[#2952cc]" />}
      className={noAction ? "border-amber-200 bg-amber-50/30" : "border-blue-200"}
    >
      <div className="p-5 sm:p-6">
        <p className="max-w-4xl text-lg font-semibold leading-8 text-[#0b1739]">
          {analysis.recommended_action || (noAction ? "Do not initiate recovery outreach at this time." : "No next-action recommendation was stored.")}
        </p>
        <dl className="mt-5 grid gap-3 sm:grid-cols-2">
          <ActionDetail icon={<CalendarClock aria-hidden="true" className="size-4" />} label="Timing" value={analysis.recommended_timing || "Not provided"} />
          <ActionDetail icon={<MessageSquareText aria-hidden="true" className="size-4" />} label="Channel" value={noAction ? "No outreach" : humanizeDealEnum(analysis.recommended_channel)} />
        </dl>
        {noAction && <p className="mt-4 text-sm leading-6 text-amber-900">Keep this deal for reference and reassess only if new customer information changes the recommendation.</p>}
      </div>
    </Card>
  );
}

function ActionDetail({ icon, label, value }: { icon: React.ReactNode; label: string; value: string }) {
  return (
    <div className="rounded-xl border border-slate-200 bg-white p-4">
      <dt className="flex items-center gap-2 text-[10px] font-extrabold uppercase tracking-[0.1em] text-slate-500">{icon}{label}</dt>
      <dd className="mt-2 text-sm font-bold text-slate-900">{value}</dd>
    </div>
  );
}

function SuggestedFollowUp({ analysis, noAction }: { analysis: DealAnalysisDetail; noAction: boolean }) {
  const message = !noAction && analysis.follow_up_message?.trim() ? analysis.follow_up_message : null;
  return (
    <Card title="Suggested Follow-Up" description="Persisted AI draft · Review and personalize before use" action={<MessageSquareText aria-hidden="true" className="size-5 text-slate-400" />}>
      <div className="p-5 sm:p-6">
        {message ? (
          <>
            <div className="grid gap-5 lg:grid-cols-[1fr_auto] lg:items-end">
              <p className="whitespace-pre-wrap break-words rounded-xl border border-slate-200 bg-slate-50 p-4 text-sm leading-7 text-slate-700">{message}</p>
              <CopyMessageButton message={message} />
            </div>
            <p className="mt-3 text-xs leading-5 text-slate-500">Review before sending. LostDeal AI does not contact the customer automatically.</p>
          </>
        ) : (
          <div className="rounded-xl border border-slate-200 bg-slate-50 p-4">
            <p className="text-sm font-semibold text-slate-800">{noAction ? "No outreach message is recommended for this deal." : "No follow-up message was stored."}</p>
            <p className="mt-1 text-xs leading-5 text-slate-500">LostDeal AI has not created or sent any customer communication.</p>
          </div>
        )}
      </div>
    </Card>
  );
}

function WhyLost({ analysis }: { analysis: DealAnalysisDetail }) {
  return (
    <Card title="Why This Deal Was Lost" description="AI interpretation grounded in the imported source" action={<Lightbulb aria-hidden="true" className="size-5 text-amber-600" />}>
      <div className="p-5 sm:p-6">
        <Badge tone="neutral">{humanizeDealEnum(analysis.lost_reason)}</Badge>
        <p className="mt-4 max-w-4xl text-sm leading-7 text-slate-700">{analysis.lost_reason_detail || "No additional explanation was stored."}</p>
      </div>
    </Card>
  );
}

function SignalSections({ analysis }: { analysis: DealAnalysisDetail }) {
  return (
    <div className="grid gap-5 lg:grid-cols-2">
      <SignalCard title="Positive Signals" items={analysis.positive_signals} empty="No strong positive buying signals identified." positive />
      <SignalCard title="Negative Signals" items={analysis.negative_signals} empty="No major negative signals identified." />
    </div>
  );
}

function SignalCard({ title, items, empty, positive = false }: { title: string; items: string[]; empty: string; positive?: boolean }) {
  return (
    <Card title={title} description="AI-identified signal" action={positive ? <ThumbsUp aria-hidden="true" className="size-5 text-emerald-600" /> : <ThumbsDown aria-hidden="true" className="size-5 text-red-500" />}>
      <div className="p-5 sm:p-6">
        {items.length ? (
          <ul className="space-y-3 text-sm leading-6 text-slate-700">
            {items.map((item, index) => (
              <li key={`${item}-${index}`} className="flex gap-3">
                <span aria-hidden="true" className={`mt-2 size-1.5 shrink-0 rounded-full ${positive ? "bg-emerald-500" : "bg-red-500"}`} />
                <span>{item}</span>
              </li>
            ))}
          </ul>
        ) : <p className="text-sm text-slate-500">{empty}</p>}
      </div>
    </Card>
  );
}

function EvidenceSection({ deal, analysis }: { deal: DealDetail; analysis: DealAnalysisDetail }) {
  return (
    <Card title="Grounded Evidence" description="These excerpts come directly from the imported sales notes or transcript" action={<ShieldCheck aria-hidden="true" className="size-5 text-emerald-600" />}>
      <div className="space-y-3 p-5 sm:p-6">
        {analysis.evidence.length ? analysis.evidence.map((evidence, index) => {
          const grounded = evidenceIsGrounded(evidence.source, evidence.excerpt, deal.sales_notes, deal.transcript);
          return (
            <figure key={`${evidence.source}-${index}`} className={`rounded-xl border p-4 ${grounded ? "border-emerald-200 bg-emerald-50/40" : "border-amber-200 bg-amber-50/60"}`}>
              <figcaption className="flex flex-wrap items-center gap-2">
                <Badge tone="neutral">{humanizeDealEnum(evidence.source)}</Badge>
                <span className={`text-xs font-semibold ${grounded ? "text-emerald-700" : "text-amber-700"}`}>{grounded ? "Exact imported excerpt" : "Source match unavailable"}</span>
              </figcaption>
              <p className="mt-3 whitespace-pre-wrap break-words text-sm leading-7 text-slate-800">{evidence.excerpt}</p>
            </figure>
          );
        }) : (
          <div className="rounded-xl border border-amber-200 bg-amber-50 p-4">
            <p className="text-sm font-semibold text-amber-900">No grounded evidence was stored.</p>
            <p className="mt-1 text-xs leading-5 text-amber-800">Review the source notes and transcript before acting on this analysis.</p>
          </div>
        )}
      </div>
    </Card>
  );
}

function RecoveryScoreBreakdown({ deal }: { deal: DealDetail }) {
  const analysis = deal.analysis;
  if (!analysis) return null;
  if (analysis.recovery_score === null || !analysis.recovery_priority) {
    return (
      <Card title="How Recovery Score Was Calculated" description="Deterministic prioritization · Separate from AI analysis" action={<Calculator aria-hidden="true" className="size-5 text-[#2952cc]" />}>
        <div className="flex flex-col gap-5 p-5 sm:flex-row sm:items-center sm:justify-between sm:p-6">
          <div>
            <p className="text-xl font-semibold text-[#0b1739]">Completed analysis, not scored yet</p>
            <p className="mt-2 max-w-2xl text-sm leading-6 text-slate-600">Calculate from stored analysis signals and quote recency. This deterministic action makes no OpenAI request.</p>
          </div>
          <CalculateRecoveryScoreButton dealId={deal.id} />
        </div>
      </Card>
    );
  }

  const scoring = analysis.scoring_metadata;
  return (
    <Card title="How Recovery Score Was Calculated" description="Persisted deterministic components · No recalculation on page load" action={<DealPriorityBadge priority={analysis.recovery_priority} />}>
      <div className="p-5 sm:p-6">
        <div className="flex flex-col gap-4 border-b border-slate-100 pb-5 sm:flex-row sm:items-end sm:justify-between">
          <div>
            <p aria-label={`Recovery Score ${analysis.recovery_score} out of 100`} className="text-4xl font-semibold tracking-[-0.04em] text-[#0b1739]">{analysis.recovery_score}<span className="text-xl text-slate-400">/100</span></p>
            <p className="mt-2 text-sm leading-6 text-slate-600">{analysis.score_explanation || "A stored deterministic score is available."}</p>
          </div>
          <div className="text-left text-xs leading-5 text-slate-500 sm:text-right">
            {scoring ? (
              <>
                <p>Scoring model: v{scoring.version}</p>
                <p>{scoring.calculated_at ? `Score calculated ${formatDealTimestamp(scoring.calculated_at)}` : "Score calculation date unavailable"}</p>
                <p>Inputs evaluated as of {formatDealDate(scoring.as_of_date)}</p>
              </>
            ) : <p>Versioned breakdown unavailable for this older score.</p>}
          </div>
        </div>

        {scoring ? (
          <>
            <dl className="mt-5 grid gap-3 sm:grid-cols-2 xl:grid-cols-4">
              <ScoreFactor label="Buying Intent" value={`${scoring.buying_intent_score}/100`} detail={`${Math.round(scoring.buying_intent_weight * 100)}% weight · ${scoring.buying_intent_contribution.toFixed(1)} points`} />
              <ScoreFactor label="Loss Recoverability" value={`${scoring.reason_recoverability}/100`} detail={`${humanizeDealEnum(scoring.reason)} · ${scoring.reason_contribution.toFixed(1)} points`} />
              <ScoreFactor label="Recency" value={`${scoring.recency_score}/100`} detail={`${Math.round(scoring.recency_weight * 100)}% weight${scoring.quote_age_days === null ? " · Date unavailable" : scoring.quote_age_days < 0 ? " · Future date neutralized" : ` · ${scoring.quote_age_days} days old`}`} />
              <ScoreFactor label="Analysis Confidence" value={`${scoring.confidence_score}/100`} detail={`Confidence multiplier ${scoring.confidence_multiplier.toFixed(3)}`} />
            </dl>
            <div className="mt-5 rounded-xl border border-slate-200 bg-slate-50 p-4">
              <h3 className="text-xs font-extrabold uppercase tracking-[0.1em] text-slate-500">Score Caps</h3>
              {scoring.applied_caps.length ? (
                <ul className="mt-3 space-y-2 text-sm leading-6 text-slate-700">
                  {scoring.applied_caps.map((cap) => (
                    <li key={cap.code} className="flex gap-2">
                      <span aria-hidden="true" className="mt-2 size-1.5 shrink-0 rounded-full bg-amber-500" />
                      <span>{cap.limitedScore ? `Score limited to ${cap.maximum}` : `Maximum ${cap.maximum} considered`} because {cap.explanation}.</span>
                    </li>
                  ))}
                </ul>
              ) : <p className="mt-2 text-sm text-slate-600">No limiting caps applied.</p>}
            </div>
          </>
        ) : (
          <div className="mt-5 rounded-xl border border-slate-200 bg-slate-50 p-4 text-sm leading-6 text-slate-600">
            The score and priority remain available, but the detailed component, cap, version, and freshness metadata was not stored with this older analysis.
          </div>
        )}
      </div>
    </Card>
  );
}

function ScoreFactor({ label, value, detail }: { label: string; value: string; detail: string }) {
  return (
    <div className="rounded-xl border border-slate-200 bg-white p-4">
      <dt className="text-[10px] font-extrabold uppercase tracking-[0.1em] text-slate-500">{label}</dt>
      <dd className="mt-2 text-sm font-bold text-slate-950">{value}</dd>
      <dd className="mt-1 text-xs leading-5 text-slate-500">{detail}</dd>
    </div>
  );
}

function AnalysisStateCard({ deal, experience }: { deal: DealDetail; experience: DealExperienceState }) {
  const state = experience === "processing" ? {
    title: "Analysis in progress",
    description: "LostDeal AI is processing the imported notes or transcript. Refresh later to view the persisted result.",
    icon: <LoaderCircle aria-hidden="true" className="size-7 animate-spin" />,
    tone: "border-blue-200 bg-blue-50 text-[#2952cc]",
  } : experience === "failed" ? {
    title: "Analysis needs attention",
    description: "A usable analysis is not available. Your imported source data is unchanged, and you can retry explicitly.",
    icon: <AlertCircle aria-hidden="true" className="size-7" />,
    tone: "border-red-200 bg-red-50 text-red-700",
  } : {
    title: "Ready for Analysis",
    description: "Analyze the imported sales notes or transcript to identify the loss reason, buying intent, evidence, and next action.",
    icon: <Clock3 aria-hidden="true" className="size-7" />,
    tone: "border-blue-200 bg-blue-50 text-[#2952cc]",
  };
  return (
    <Card title="Deal Intelligence" description="No analysis is inferred or generated during normal page load" action={<Bot aria-hidden="true" className="size-5 text-slate-400" />}>
      <div className="p-5 sm:p-6">
        <div className="flex flex-col gap-5 sm:flex-row sm:items-start">
          <div className={`flex size-12 shrink-0 items-center justify-center rounded-xl border ${state.tone}`}>{state.icon}</div>
          <div className="flex-1">
            <h2 className="text-xl font-bold text-slate-950">{state.title}</h2>
            <p className="mt-2 max-w-2xl text-sm leading-6 text-slate-600">{state.description}</p>
            {experience !== "processing" && <div className="mt-5"><AnalyzeDealButton dealId={deal.id} retry={experience === "failed"} /></div>}
          </div>
        </div>
      </div>
    </Card>
  );
}

function SourceSeparationNote() {
  return (
    <aside className="mt-5 rounded-2xl border border-blue-200 bg-blue-50 p-5" aria-label="Data provenance">
      <div className="flex items-center gap-2 text-sm font-bold text-blue-950"><Database aria-hidden="true" className="size-4" />Source, AI, and score stay separate</div>
      <p className="mt-2 text-sm leading-6 text-blue-900"><strong>Deal Information, Sales Notes, and Transcript</strong> are imported source data. <strong>Recovery intelligence</strong> is stored AI interpretation. <strong>Recovery Score</strong> is a separate deterministic ranking calculated from stored signals and quote recency.</p>
    </aside>
  );
}

function SourceSections({ deal }: { deal: DealDetail }) {
  return (
    <div className="mt-5 space-y-5">
      <Card title="Deal Information" description="Imported business information · Not AI-generated" action={<Badge tone="neutral">Source</Badge>}>
        <dl className="grid gap-px bg-slate-100 sm:grid-cols-2 lg:grid-cols-3">
          <DataField label="Customer Name" value={deal.customer_name || "Unnamed customer"} />
          <DataField label="External Deal ID" value={deal.external_deal_id || "—"} />
          <DataField label="Deal Value" value={formatDealCurrency(deal.deal_value)} />
          <DataField label="Quote Date" value={formatDealDate(deal.quote_date)} />
          <DataField label="Status" value={humanizeDealEnum(deal.status)} />
          <DataField label="Salesperson" value={deal.salesperson || "—"} />
          <DataField label="Service Type" value={deal.service_type || "—"} />
          <DataField label="Lead Source" value={deal.lead_source || "—"} />
          <DataField label="Imported Date" value={formatDealTimestamp(deal.created_at)} />
        </dl>
      </Card>

      <Card title="Sales Notes" description="Complete imported source text" action={<FileText aria-hidden="true" className="size-5 text-slate-400" />}>
        <div className="p-5 sm:p-6">
          {deal.sales_notes ? <p className="whitespace-pre-wrap break-words rounded-xl border border-slate-200 bg-slate-50 p-4 text-sm leading-7 text-slate-700">{deal.sales_notes}</p> : <p className="text-sm text-slate-500">No sales notes provided.</p>}
        </div>
      </Card>

      <Card title="Transcript" description="Complete imported conversation text" action={<MessageSquareText aria-hidden="true" className="size-5 text-slate-400" />}>
        <div className="p-5 sm:p-6">
          {deal.transcript ? <ExpandableTranscript text={deal.transcript} /> : <p className="text-sm text-slate-500">No transcript provided.</p>}
        </div>
      </Card>
    </div>
  );
}

function DataField({ label, value }: { label: string; value: string }) {
  return (
    <div className="bg-white px-5 py-4 sm:px-6">
      <dt className="text-[10px] font-extrabold uppercase tracking-[0.1em] text-slate-500">{label}</dt>
      <dd className="mt-2 break-words text-sm font-semibold text-slate-800">{value}</dd>
    </div>
  );
}
