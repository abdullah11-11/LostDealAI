import { NextResponse } from "next/server";

import { analyzePendingDeals } from "@/lib/ai/deal-analysis-service";
import { mutationIssueResponse, validateMutationRequest } from "@/lib/security/origin";
import { enforceRateLimitOrRespond } from "@/lib/security/rate-limit";
import { getAuthorizedRouteContext } from "@/lib/security/route-auth";
import { EmptyMutationSchema } from "@/lib/security/schemas";

export async function POST(request: Request) {
  try {
    const requestIssue = validateMutationRequest(request, "empty-json");
    if (requestIssue) return mutationIssueResponse(requestIssue);
    const parsedBody = EmptyMutationSchema.safeParse(await request.json().catch(() => null));
    if (!parsedBody.success) return NextResponse.json({ error: "The request body is invalid." }, { status: 400 });
    const authorization = await getAuthorizedRouteContext();
    if (authorization.response) return authorization.response;
    const { supabase, identity, organization } = authorization.context;
    const limited = await enforceRateLimitOrRespond(identity.id, "analyze_batch");
    if (limited) return limited;

    const result = await analyzePendingDeals(supabase, organization.id);
    return NextResponse.json({ success: true, result });
  } catch {
    return NextResponse.json({ error: "Pending deals could not be analyzed right now. Please try again." }, { status: 503 });
  }
}
