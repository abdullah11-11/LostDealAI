import { NextResponse } from "next/server";

import { analyzeAuthorizedDeal } from "@/lib/ai/deal-analysis-service";
import { authorizeDealReference } from "@/lib/security/authorization";
import { mutationIssueResponse, validateMutationRequest } from "@/lib/security/origin";
import { enforceRateLimitOrRespond } from "@/lib/security/rate-limit";
import { getAuthorizedRouteContext } from "@/lib/security/route-auth";
import { DealMutationSchema } from "@/lib/security/schemas";

export async function POST(request: Request) {
  try {
    const requestIssue = validateMutationRequest(request, "json");
    if (requestIssue) return mutationIssueResponse(requestIssue);
    const parsedBody = DealMutationSchema.safeParse(await request.json().catch(() => null));
    if (!parsedBody.success) {
      return NextResponse.json({ error: "A valid deal is required." }, { status: 400 });
    }
    const authorization = await getAuthorizedRouteContext();
    if (authorization.response) return authorization.response;
    const { supabase, identity, organization } = authorization.context;
    const authorized = await authorizeDealReference(supabase, organization.id, parsedBody.data.deal_id);
    if (!authorized) return NextResponse.json({ error: "Deal unavailable." }, { status: 404 });
    const limited = await enforceRateLimitOrRespond(identity.id, "analyze_single");
    if (limited) return limited;

    const result = await analyzeAuthorizedDeal(supabase, organization.id, parsedBody.data.deal_id);
    if (result.status === "not_found") return NextResponse.json({ error: "Deal unavailable." }, { status: 404 });
    if (result.status === "processing") {
      return NextResponse.json({ status: "processing", message: "Analysis is already in progress." }, { status: 409 });
    }
    if (result.status === "failed") {
      const status = result.code === "SOURCE_TOO_LONG" || result.code === "INSUFFICIENT_SOURCE" ? 422 : 503;
      return NextResponse.json({
        status: "failed",
        code: result.code,
        error: "We couldn't analyze this deal right now. Please try again.",
      }, { status });
    }
    return NextResponse.json({
      status: "completed",
      fresh: result.fresh,
      ...(result.fresh ? { usage: result.usage } : {}),
    });
  } catch {
    return NextResponse.json({ error: "We couldn't analyze this deal right now. Please try again." }, { status: 500 });
  }
}
