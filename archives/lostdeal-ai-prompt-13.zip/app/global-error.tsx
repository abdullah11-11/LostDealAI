"use client";

export default function GlobalError({ reset }: { reset: () => void }) {
  return (
    <html lang="en">
      <body className="bg-[#070b12] text-[#f8fafc]">
        <main className="flex min-h-screen items-center justify-center px-5">
          <div className="w-full max-w-lg rounded-2xl border border-[#1e293b] bg-[#0d1523] p-8 text-center">
            <p className="font-bold text-[#22d3ee]">LostDeal AI</p>
            <h1 className="mt-3 text-2xl font-semibold">The application could not start</h1>
            <p className="mt-3 text-sm leading-6 text-[#94a3b8]">Reload the application to try again.</p>
            <button onClick={reset} className="mt-6 min-h-10 rounded-lg border border-[#22d3ee] bg-[#22d3ee] px-4 text-sm font-bold text-[#031318]">Reload Application</button>
          </div>
        </main>
      </body>
    </html>
  );
}
