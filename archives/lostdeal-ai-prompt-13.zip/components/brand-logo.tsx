import Link from "next/link";
import Image from "next/image";

export function BrandLogo({
  compact = false,
  size = "md",
}: {
  compact?: boolean;
  inverted?: boolean;
  size?: "sm" | "md" | "lg";
}) {
  const fullSizes = size === "lg" ? "h-12 w-auto sm:h-14" : size === "sm" ? "h-7 w-auto" : "h-9 w-auto";
  const iconSizes = size === "lg" ? "size-12" : size === "sm" ? "size-8" : "size-9";

  return (
    <Link
      href="/"
      aria-label="LostDeal AI home"
      className="inline-flex shrink-0 items-center rounded-lg focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-brand/40 focus-visible:ring-offset-2 focus-visible:ring-offset-background"
    >
      {compact ? (
        <Image src="/lostdeal-icon.png" width={256} height={256} alt="" aria-hidden="true" sizes="48px" className={`${iconSizes} rounded-lg object-cover`} />
      ) : (
        <Image src="/lostdeal-wordmark.webp" width={1054} height={254} alt="LostDeal AI" sizes="210px" className={`${fullSizes} max-w-[210px] object-contain object-left mix-blend-lighten`} />
      )}
    </Link>
  );
}
