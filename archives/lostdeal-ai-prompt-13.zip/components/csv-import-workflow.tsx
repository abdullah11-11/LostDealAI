"use client";

import Link from "next/link";
import { useRef, useState } from "react";
import {
  AlertCircle,
  ArrowLeft,
  ArrowRight,
  Check,
  CheckCircle2,
  Download,
  FileCheck2,
  FileSpreadsheet,
  Info,
  RefreshCw,
  UploadCloud,
  X,
} from "lucide-react";

import { Badge, Button, Card, Select, Table, buttonStyles } from "@/components/ui";
import {
  CANONICAL_FIELDS,
  FIELD_DETAILS,
  MAX_CSV_FILE_BYTES,
  MAX_CSV_ROWS,
  type CanonicalField,
} from "@/lib/csv/constants";
import {
  autoMapColumns,
  validateColumnMapping,
  type ColumnMapping,
} from "@/lib/csv/mapping";
import {
  parseCsvText,
  validateCsvFileMetadata,
  validateParsedCsvShape,
  type ParsedCsv,
} from "@/lib/csv/validation";
import { formatDealCurrency } from "@/lib/deals/format";

export type RecentImport = {
  id: string;
  filename: string;
  createdAt: string;
  rowsImported: number;
  status: "pending" | "processing" | "completed" | "failed";
};

type ValidationSummary = {
  totalRows: number;
  validRows: number;
  invalidRows: number;
  blankRows: number;
  malformedRows: number;
  invalid: Array<{
    rowNumber: number;
    customer: string | null;
    externalDealId: string | null;
    errors: string[];
  }>;
  preview: Array<{
    rowNumber: number;
    customer_name: string | null;
    deal_value: string;
    quote_date: string | null;
    service_type: string | null;
    salesperson: string | null;
    context: string;
  }>;
};

type ImportResult = {
  uploadId: string;
  filename: string;
  organizationName: string;
  insertedCount: number;
  invalidRows: number;
  createdAt: string;
};

type Stage = "select" | "mapping" | "review" | "confirm" | "success";

const STEP_LABELS: Array<{ key: Exclude<Stage, "success">; label: string }> = [
  { key: "select", label: "Select CSV" },
  { key: "mapping", label: "Map Columns" },
  { key: "review", label: "Review" },
  { key: "confirm", label: "Confirm Import" },
];

function stageIndex(stage: Stage): number {
  if (stage === "success") return 4;
  return STEP_LABELS.findIndex((step) => step.key === stage);
}

function formatBytes(bytes: number): string {
  if (bytes < 1024) return `${bytes} bytes`;
  return `${(bytes / 1024).toFixed(bytes < 1024 * 100 ? 1 : 0)} KB`;
}

function formatDate(value: string): string {
  return new Intl.DateTimeFormat("en-US", {
    dateStyle: "medium",
    timeZone: "UTC",
  }).format(new Date(value));
}

function statusTone(status: RecentImport["status"]): "pending" | "completed" | "failed" {
  if (status === "completed") return "completed";
  if (status === "failed") return "failed";
  return "pending";
}

async function responseJson(response: Response): Promise<Record<string, unknown>> {
  try {
    return (await response.json()) as Record<string, unknown>;
  } catch {
    return {};
  }
}

export function CsvImportWorkflow({
  organizationName,
  recentImports,
  recentImportsUnavailable,
}: {
  organizationName: string;
  recentImports: RecentImport[];
  recentImportsUnavailable?: boolean;
}) {
  const inputRef = useRef<HTMLInputElement>(null);
  const [stage, setStage] = useState<Stage>("select");
  const [file, setFile] = useState<File | null>(null);
  const [parsed, setParsed] = useState<ParsedCsv | null>(null);
  const [mapping, setMapping] = useState<ColumnMapping | null>(null);
  const [validation, setValidation] = useState<ValidationSummary | null>(null);
  const [result, setResult] = useState<ImportResult | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [mappingError, setMappingError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const [dragging, setDragging] = useState(false);
  const [imports, setImports] = useState(recentImports);

  const currentStep = stageIndex(stage);

  function resetImport() {
    setStage("select");
    setFile(null);
    setParsed(null);
    setMapping(null);
    setValidation(null);
    setResult(null);
    setError(null);
    setMappingError(null);
    if (inputRef.current) inputRef.current.value = "";
  }

  async function selectFile(selectedFile: File | null) {
    setError(null);
    setMappingError(null);
    setValidation(null);
    if (!selectedFile) {
      setError("Choose a CSV file to continue.");
      return;
    }

    const metadataError = validateCsvFileMetadata(selectedFile);
    if (metadataError) {
      setError(metadataError);
      return;
    }

    try {
      const csv = parseCsvText(await selectedFile.text());
      const shapeError = validateParsedCsvShape(csv);
      if (shapeError) {
        setError(shapeError);
        return;
      }
      setFile(selectedFile);
      setParsed(csv);
      setMapping(autoMapColumns(csv.headers));
      setStage("mapping");
    } catch {
      setError("LostDeal AI could not read this CSV. Confirm it is valid UTF-8 text and try again.");
    }
  }

  function updateMapping(field: CanonicalField, rawValue: string) {
    if (!mapping) return;
    const nextIndex = rawValue === "" ? null : Number(rawValue);
    if (nextIndex !== null) {
      const duplicate = CANONICAL_FIELDS.find(
        (candidate) => candidate !== field && mapping[candidate] === nextIndex,
      );
      if (duplicate) {
        setMappingError(
          `${parsed?.headers[nextIndex] ?? "That column"} is already mapped to ${FIELD_DETAILS[duplicate].label}. Choose a different CSV column.`,
        );
        return;
      }
    }
    setMapping({ ...mapping, [field]: nextIndex });
    setMappingError(null);
  }

  async function reviewFile() {
    if (!file || !parsed || !mapping) return;
    const errors = validateColumnMapping(mapping, parsed.headers.length);
    if (errors.length) {
      setMappingError(errors.join(" "));
      return;
    }

    setBusy(true);
    setError(null);
    setMappingError(null);
    const formData = new FormData();
    formData.append("file", file);
    formData.append("mapping", JSON.stringify(mapping));

    try {
      const response = await fetch("/api/uploads/validate", { method: "POST", body: formData });
      const body = await responseJson(response);
      if (!response.ok || !body.validation) {
        throw new Error(typeof body.error === "string" ? body.error : "CSV validation failed.");
      }
      setValidation(body.validation as ValidationSummary);
      setStage("review");
    } catch (requestError) {
      setError(requestError instanceof Error ? requestError.message : "CSV validation failed.");
    } finally {
      setBusy(false);
    }
  }

  async function importDeals() {
    if (!file || !mapping || !validation?.validRows || busy) return;
    setBusy(true);
    setError(null);
    const formData = new FormData();
    formData.append("file", file);
    formData.append("mapping", JSON.stringify(mapping));

    try {
      const response = await fetch("/api/uploads/import", { method: "POST", body: formData });
      const body = await responseJson(response);
      if (!response.ok || !body.success) {
        throw new Error(typeof body.error === "string" ? body.error : "The import could not be completed.");
      }
      const nextResult = body as unknown as ImportResult;
      setResult(nextResult);
      setImports((current) => [
        {
          id: nextResult.uploadId,
          filename: nextResult.filename,
          createdAt: nextResult.createdAt,
          rowsImported: nextResult.insertedCount,
          status: "completed" as const,
        },
        ...current,
      ].slice(0, 6));
      setStage("success");
    } catch (requestError) {
      setError(requestError instanceof Error ? requestError.message : "The import could not be completed.");
    } finally {
      setBusy(false);
    }
  }

  return (
    <div>
      <ol aria-label="CSV import progress" className="grid gap-2 sm:grid-cols-2 xl:grid-cols-4">
        {STEP_LABELS.map((step, index) => {
          const complete = currentStep > index;
          const active = currentStep === index;
          return (
            <li
              key={step.key}
              aria-current={active ? "step" : undefined}
              className={`flex items-center gap-3 rounded-xl border px-4 py-3 text-sm font-bold ${active ? "border-brand/40 bg-brand/10 text-cyan-200" : complete ? "border-emerald-500/35 bg-emerald-500/10 text-emerald-300" : "border-line bg-panel text-secondary"}`}
            >
              <span className={`flex size-7 shrink-0 items-center justify-center rounded-full text-xs ${active ? "bg-brand text-[#031318]" : complete ? "bg-emerald-600 text-white" : "bg-panel-hover text-secondary"}`}>
                {complete ? <Check aria-hidden="true" className="size-3.5" /> : index + 1}
              </span>
              {step.label}
            </li>
          );
        })}
      </ol>

      <div aria-live="polite" className="mt-5 min-h-0">
        {error && (
          <div role="alert" className="flex gap-3 rounded-xl border border-red-500/35 bg-red-500/10 px-4 py-3 text-sm leading-6 text-red-300">
            <AlertCircle aria-hidden="true" className="mt-1 size-4 shrink-0" />
            <span>{error}</span>
          </div>
        )}
      </div>

      {stage === "select" && (
        <section className="mt-5 grid gap-5 lg:grid-cols-[1.35fr_0.65fr]">
          <Card>
            <div className="p-5 sm:p-6">
              <div
                onDragEnter={(event) => { event.preventDefault(); setDragging(true); }}
                onDragOver={(event) => { event.preventDefault(); setDragging(true); }}
                onDragLeave={(event) => { event.preventDefault(); setDragging(false); }}
                onDrop={(event) => {
                  event.preventDefault();
                  setDragging(false);
                  void selectFile(event.dataTransfer.files.item(0));
                }}
                className={`flex min-h-[25rem] flex-col items-center justify-center rounded-2xl border-2 border-dashed px-6 text-center transition ${dragging ? "border-brand bg-brand/15" : "border-brand/30 bg-brand/5"}`}
              >
                <span className="flex size-16 items-center justify-center rounded-2xl bg-panel text-brand shadow-sm">
                  <UploadCloud aria-hidden="true" className="size-7" />
                </span>
                <h2 className="mt-6 text-xl font-bold text-content">Drop your lost-deals CSV here</h2>
                <p className="mt-2 max-w-lg text-sm leading-6 text-secondary">
                  Upload a CSV containing lost sales opportunities, sales notes, or conversation transcripts.
                </p>
                <p className="mt-3 max-w-lg text-xs leading-5 text-secondary">
                  Import only information your organization is authorized to process. Avoid unnecessary sensitive personal data in notes or transcripts.
                </p>
                <input
                  ref={inputRef}
                  id="csv-file"
                  type="file"
                  accept=".csv,text/csv"
                  className="sr-only"
                  onChange={(event) => void selectFile(event.target.files?.item(0) ?? null)}
                />
                <label htmlFor="csv-file" className={buttonStyles("primary", "mt-6")}>Choose CSV</label>
                <div className="mt-5 flex flex-wrap justify-center gap-2">
                  <Badge tone="neutral">CSV only</Badge>
                  <Badge tone="neutral">Maximum {MAX_CSV_FILE_BYTES / 1024 / 1024} MB</Badge>
                  <Badge tone="neutral">Maximum {MAX_CSV_ROWS.toLocaleString()} deals</Badge>
                </div>
              </div>
            </div>
          </Card>

          <aside className="space-y-5">
            <Card title="Prepare your file" description="Only deal context is needed—no contact details required.">
              <ul className="space-y-4 p-5 sm:p-6">
                {[
                  "One lost opportunity per row",
                  "Include a deal value for every row",
                  "Add sales notes or a transcript",
                  "Use ISO dates such as 2026-08-14",
                ].map((item) => (
                  <li key={item} className="flex gap-3 text-sm leading-6 text-secondary">
                    <CheckCircle2 aria-hidden="true" className="mt-0.5 size-4 shrink-0 text-emerald-600" />
                    {item}
                  </li>
                ))}
              </ul>
            </Card>
            <Card>
              <div className="p-5 sm:p-6">
                <div className="flex items-start gap-3">
                  <span className="flex size-10 shrink-0 items-center justify-center rounded-xl bg-panel-hover text-secondary"><FileSpreadsheet aria-hidden="true" className="size-5" /></span>
                  <div>
                    <h2 className="text-sm font-bold text-content">Test with synthetic data</h2>
                    <p className="mt-1 text-xs leading-5 text-secondary">Choose a quick import sample or a richer product walkthrough.</p>
                  </div>
                </div>
                <div className="mt-5 space-y-4">
                  <div>
                    <h3 className="text-sm font-bold text-content">Sample CSV</h3>
                    <p className="mt-1 text-xs leading-5 text-secondary">10 simple synthetic rows for testing CSV import and mapping.</p>
                    <a href="/sample-lost-deals.csv" download className={buttonStyles("outline", "mt-3 w-full")}>
                      <Download aria-hidden="true" className="size-4" /> Download Sample CSV
                    </a>
                  </div>
                  <div className="border-t border-line pt-4">
                    <h3 className="text-sm font-bold text-content">Demo HVAC Dataset</h3>
                    <p className="mt-1 text-xs leading-5 text-secondary">20 realistic synthetic lost opportunities for exploring analysis, scoring, and dashboard workflows.</p>
                    <a href="/lostdeal-demo-hvac.csv" download className={buttonStyles("outline", "mt-3 w-full")}>
                      <Download aria-hidden="true" className="size-4" /> Download Demo HVAC CSV
                    </a>
                  </div>
                </div>
                <p className="mt-4 border-t border-line pt-4 text-[11px] leading-5 text-secondary">
                  Synthetic data only. Do not treat these records as real customer opportunities.
                </p>
              </div>
            </Card>
            <div className="flex gap-3 rounded-2xl border border-brand/30 bg-brand/10 p-5 text-sm leading-6 text-cyan-100">
              <Info aria-hidden="true" className="mt-0.5 size-4 shrink-0" />
              Uploaded values are treated as plain text. LostDeal AI never executes spreadsheet formulas.
            </div>
          </aside>
        </section>
      )}

      {stage === "mapping" && file && parsed && mapping && (
        <section className="mt-5">
          <Card
            title="Map your columns"
            description="Tell LostDeal AI which columns in your CSV correspond to each field. Deterministic suggestions are selected where names match."
            action={<Badge tone="completed">{parsed.rows.length.toLocaleString()} rows detected</Badge>}
          >
            <div className="border-b border-line px-5 py-4 sm:px-6">
              <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
                <div className="min-w-0">
                  <p className="truncate text-sm font-bold text-content">{file.name}</p>
                  <p className="mt-1 text-xs text-secondary">{formatBytes(file.size)} · {parsed.headers.length} columns · {parsed.blankRows} blank rows ignored</p>
                </div>
                <Button type="button" variant="ghost" onClick={resetImport}><X aria-hidden="true" className="size-4" />Choose another file</Button>
              </div>
            </div>
            <div className="grid gap-x-5 gap-y-6 p-5 sm:grid-cols-2 sm:p-6">
              {CANONICAL_FIELDS.map((field) => (
                <Select
                  key={field}
                  id={`mapping-${field}`}
                  label={`${FIELD_DETAILS[field].label}${FIELD_DETAILS[field].required ? " *" : ""}`}
                  description={FIELD_DETAILS[field].description}
                  value={mapping[field] ?? ""}
                  onChange={(event) => updateMapping(field, event.target.value)}
                >
                  <option value="">Not mapped</option>
                  {parsed.headers.map((header, index) => (
                    <option key={`${header}-${index}`} value={index}>{header || `Column ${index + 1}`}</option>
                  ))}
                </Select>
              ))}
            </div>
            {mappingError && (
              <div role="alert" className="mx-5 mb-5 flex gap-3 rounded-xl border border-red-500/35 bg-red-500/10 px-4 py-3 text-sm leading-6 text-red-300 sm:mx-6 sm:mb-6">
                <AlertCircle aria-hidden="true" className="mt-1 size-4 shrink-0" />{mappingError}
              </div>
            )}
            <div className="flex flex-col-reverse gap-3 border-t border-line px-5 py-5 sm:flex-row sm:justify-between sm:px-6">
              <Button type="button" variant="outline" onClick={resetImport}><ArrowLeft aria-hidden="true" className="size-4" />Back</Button>
              <Button type="button" loading={busy} onClick={() => void reviewFile()}>
                {busy ? "Validating on server…" : "Validate & review"}<ArrowRight aria-hidden="true" className="size-4" />
              </Button>
            </div>
          </Card>
        </section>
      )}

      {stage === "review" && file && parsed && mapping && validation && (
        <section className="mt-5 space-y-5">
          <div className="grid gap-4 sm:grid-cols-3">
            {[
              { label: "Total rows", value: validation.totalRows, color: "text-content" },
              { label: "Valid", value: validation.validRows, color: "text-emerald-300" },
              { label: "Invalid", value: validation.invalidRows, color: "text-red-300" },
            ].map((item) => (
              <Card key={item.label}>
                <div className="p-5">
                  <p className="text-xs font-bold uppercase tracking-[0.12em] text-secondary">{item.label}</p>
                  <p className={`mt-3 text-3xl font-semibold tracking-tight ${item.color}`}>{item.value.toLocaleString()}</p>
                </div>
              </Card>
            ))}
          </div>

          {validation.invalidRows > 0 && (
            <Card
              title="Invalid row review"
              description={`${validation.invalidRows.toLocaleString()} invalid ${validation.invalidRows === 1 ? "row will" : "rows will"} be skipped. Correct the source file and restart if you want to include them.`}
              action={<Badge tone="failed">Skipped</Badge>}
            >
              <div className="max-h-80 divide-y divide-line overflow-y-auto">
                {validation.invalid.map((row) => (
                  <div key={row.rowNumber} className="grid gap-2 px-5 py-4 sm:grid-cols-[7rem_1fr_2fr] sm:px-6">
                    <p className="text-sm font-bold text-content">Row {row.rowNumber}</p>
                    <p className="text-sm text-secondary">{row.customer || row.externalDealId || "Unnamed deal"}</p>
                    <ul className="space-y-1 text-sm text-red-300">
                      {row.errors.map((rowError) => <li key={rowError}>{rowError}</li>)}
                    </ul>
                  </div>
                ))}
              </div>
            </Card>
          )}

          <Card
            title="Normalized preview"
            description={`First ${validation.preview.length} valid ${validation.preview.length === 1 ? "row" : "rows"}. Full transcripts are intentionally not shown.`}
          >
            {validation.preview.length ? (
              <Table label="Normalized deal preview" headers={["Customer", "Deal value", "Quote date", "Service", "Salesperson", "Notes / transcript"]}>
                {validation.preview.map((row) => (
                  <tr key={row.rowNumber} className="text-sm text-secondary">
                    <td className="px-5 py-4 font-bold text-content">{row.customer_name || "Unnamed deal"}</td>
                    <td className="px-5 py-4">{formatDealCurrency(row.deal_value)}</td>
                    <td className="px-5 py-4">{row.quote_date || "—"}</td>
                    <td className="px-5 py-4">{row.service_type || "—"}</td>
                    <td className="px-5 py-4">{row.salesperson || "—"}</td>
                    <td className="max-w-xs px-5 py-4 text-xs leading-5 text-secondary">{row.context}</td>
                  </tr>
                ))}
              </Table>
            ) : (
              <div className="p-6 text-sm text-secondary">No valid rows are available to preview.</div>
            )}
          </Card>

          <Card title="Review complete" description="Confirm the valid and skipped rows before any data is inserted.">
            <div className="flex flex-col-reverse gap-3 p-5 sm:flex-row sm:items-center sm:justify-between sm:p-6">
              <Button type="button" variant="outline" onClick={() => { setStage("mapping"); setError(null); }}><ArrowLeft aria-hidden="true" className="size-4" />Back to Mapping</Button>
              <Button type="button" disabled={!validation.validRows} onClick={() => { setStage("confirm"); setError(null); }}>
                Continue to Confirm <ArrowRight aria-hidden="true" className="size-4" />
              </Button>
            </div>
            {!validation.validRows && <p role="alert" className="px-5 pb-5 text-sm font-semibold text-red-300 sm:px-6 sm:pb-6">All rows are invalid. Correct the CSV before importing.</p>}
          </Card>
        </section>
      )}

      {stage === "confirm" && file && validation && (
        <section className="mt-5">
          <Card title="Confirm Import" description={`Review the final import into ${organizationName}.`} action={<Badge tone="pending">No AI starts automatically</Badge>}>
            <div className="p-5 sm:p-6">
              <dl className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
                <div className="rounded-xl border border-line bg-panel-raised p-4 sm:col-span-2">
                  <dt className="text-[10px] font-extrabold uppercase tracking-[0.1em] text-secondary">Filename</dt>
                  <dd className="mt-2 break-all text-sm font-bold text-content">{file.name}</dd>
                </div>
                <div className="rounded-xl border border-emerald-500/35 bg-emerald-500/10 p-4">
                  <dt className="text-[10px] font-extrabold uppercase tracking-[0.1em] text-emerald-300">Valid deals</dt>
                  <dd className="mt-2 text-2xl font-semibold text-content">{validation.validRows.toLocaleString()}</dd>
                </div>
                <div className="rounded-xl border border-line bg-panel-raised p-4">
                  <dt className="text-[10px] font-extrabold uppercase tracking-[0.1em] text-secondary">Skipped rows</dt>
                  <dd className="mt-2 text-2xl font-semibold text-content">{validation.invalidRows.toLocaleString()}</dd>
                </div>
              </dl>
              <div className="mt-5 rounded-xl border border-brand/25 bg-brand/5 p-4">
                <p className="text-sm font-bold text-content">Final import count: {validation.validRows.toLocaleString()} {validation.validRows === 1 ? "deal" : "deals"}</p>
                <p className="mt-1 text-xs leading-5 text-secondary">The server reparses and revalidates the original file before inserting. Invalid rows are skipped, existing deals are not imported twice, and AI analysis does not start.</p>
              </div>
              <div className="mt-6 flex flex-col-reverse gap-3 sm:flex-row sm:justify-between">
                <Button type="button" variant="outline" disabled={busy} onClick={() => { setStage("review"); setError(null); }}><ArrowLeft aria-hidden="true" className="size-4" />Back to Review</Button>
                <Button type="button" loading={busy} disabled={!validation.validRows} onClick={() => void importDeals()}>
                  <UploadCloud aria-hidden="true" className="size-4" />
                  {busy ? "Importing…" : `Import ${validation.validRows.toLocaleString()} ${validation.validRows === 1 ? "Deal" : "Deals"}`}
                </Button>
              </div>
            </div>
          </Card>
        </section>
      )}

      {stage === "success" && result && (
        <section className="mt-5">
          <Card>
            <div className="flex min-h-[28rem] flex-col items-center justify-center p-6 text-center sm:p-10">
              <span className="flex size-20 items-center justify-center rounded-full bg-emerald-500/10 text-emerald-600">
                <FileCheck2 aria-hidden="true" className="size-9" />
              </span>
              <Badge tone="completed" className="mt-6">Import completed</Badge>
              <h2 className="mt-4 text-2xl font-bold tracking-tight text-content">Deals imported successfully</h2>
              <p className="mt-3 max-w-xl text-sm leading-6 text-secondary">
                {result.insertedCount.toLocaleString()} lost {result.insertedCount === 1 ? "deal is" : "deals are"} ready for analysis in {result.organizationName}. No AI analysis has started.
              </p>
              {result.invalidRows > 0 && <p className="mt-2 text-sm text-secondary">{result.invalidRows.toLocaleString()} invalid {result.invalidRows === 1 ? "row was" : "rows were"} skipped as confirmed.</p>}
              <div className="mt-7 flex flex-col gap-3 sm:flex-row">
                <Link href="/deals" className={buttonStyles("secondary")}>View Deals <ArrowRight aria-hidden="true" className="size-4" /></Link>
                <Button type="button" variant="outline" onClick={resetImport}><RefreshCw aria-hidden="true" className="size-4" />Import Another File</Button>
              </div>
            </div>
          </Card>
        </section>
      )}

      <section className="mt-8">
        <Card title="Recent imports" description={`Real CSV imports for ${organizationName}.`}>
          {imports.length ? (
            <div className="divide-y divide-line">
              {imports.map((item) => (
                <div key={item.id} className="flex flex-col gap-3 px-5 py-4 sm:flex-row sm:items-center sm:justify-between sm:px-6">
                  <div className="min-w-0">
                    <p className="truncate text-sm font-bold text-content">{item.filename}</p>
                    <p className="mt-1 text-xs text-secondary">{formatDate(item.createdAt)} · {item.rowsImported.toLocaleString()} rows imported</p>
                  </div>
                  <Badge tone={statusTone(item.status)}>{item.status}</Badge>
                </div>
              ))}
            </div>
          ) : recentImportsUnavailable ? (
            <div className="flex min-h-40 flex-col items-center justify-center px-6 py-8 text-center">
              <AlertCircle aria-hidden="true" className="size-7 text-amber-500" />
              <p className="mt-3 text-sm font-bold text-content">Recent imports are temporarily unavailable</p>
              <p className="mt-1 text-xs leading-5 text-secondary">Your import workflow still works. Refresh this page to try loading history again.</p>
            </div>
          ) : (
            <div className="flex min-h-40 flex-col items-center justify-center px-6 py-8 text-center">
              <FileSpreadsheet aria-hidden="true" className="size-7 text-secondary" />
              <p className="mt-3 text-sm font-bold text-content">No imports yet</p>
              <p className="mt-1 text-xs leading-5 text-secondary">Your completed and failed CSV imports will appear here.</p>
            </div>
          )}
        </Card>
      </section>
    </div>
  );
}
