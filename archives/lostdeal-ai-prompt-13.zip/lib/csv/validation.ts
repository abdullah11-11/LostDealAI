import Papa from "papaparse";

import {
  CANONICAL_FIELDS,
  FIELD_MAX_LENGTHS,
  MAX_CSV_FILENAME_LENGTH,
  MAX_CSV_FILE_BYTES,
  MAX_CSV_HEADER_LENGTH,
  MAX_CSV_ROWS,
  type CanonicalField,
} from "@/lib/csv/constants";
import { normalizeHeader, type ColumnMapping } from "@/lib/csv/mapping";

export type ParsedCsvRow = {
  rowNumber: number;
  values: string[];
  parserErrors: string[];
};

export type ParsedCsv = {
  headers: string[];
  rows: ParsedCsvRow[];
  blankRows: number;
  malformedRows: number;
  parserErrors: string[];
};

export type NormalizedDeal = {
  rowNumber: number;
  external_deal_id: string | null;
  customer_name: string | null;
  deal_value: string;
  quote_date: string | null;
  status: "lost";
  salesperson: string | null;
  service_type: string | null;
  lead_source: string | null;
  sales_notes: string | null;
  transcript: string | null;
};

export type InvalidCsvRow = {
  rowNumber: number;
  customer: string | null;
  externalDealId: string | null;
  errors: string[];
};

export type CsvValidationResult = {
  totalRows: number;
  validRows: NormalizedDeal[];
  invalidRows: InvalidCsvRow[];
};

export type CsvFileMetadata = {
  name: string;
  size: number;
  type?: string;
};

const LOST_STATUSES = new Set([
  "lost",
  "closed lost",
  "unsold",
  "not won",
  "declined",
  "not sold",
]);
const WON_STATUSES = new Set(["won", "closed won", "completed", "sold"]);
const MAX_DEAL_VALUE = 999_999_999_999.99;

function isBlankRow(row: readonly string[]): boolean {
  return row.every((value) => !value.trim());
}

function cleanParserMessage(message: string): string {
  if (/quoted field malformed|missingquotes/i.test(message)) return "Malformed quoted CSV field.";
  return message.replace(/\s+/g, " ").trim() || "Malformed CSV row.";
}

export function validateCsvFileMetadata(file: CsvFileMetadata): string | null {
  const name = file.name.trim();
  if (!name) return "Choose a CSV file to continue.";
  if (name.length > MAX_CSV_FILENAME_LENGTH) {
    return `The filename must be ${MAX_CSV_FILENAME_LENGTH} characters or fewer.`;
  }
  if (!name.toLocaleLowerCase("en-US").endsWith(".csv")) {
    return "LostDeal AI accepts CSV files only.";
  }
  if (file.size <= 0) return "This CSV is empty.";
  if (file.size > MAX_CSV_FILE_BYTES) {
    return "This file is larger than 5 MB. Choose a smaller CSV.";
  }

  const mime = file.type?.toLocaleLowerCase("en-US").trim();
  const clearlyUnsupported = mime && [
    "application/pdf",
    "application/json",
    "application/zip",
    "application/x-zip-compressed",
    "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
  ].includes(mime);
  if (clearlyUnsupported) return "The selected file does not appear to be a CSV.";

  return null;
}

export function parseCsvText(text: string): ParsedCsv {
  if (!text.trim()) {
    return { headers: [], rows: [], blankRows: 0, malformedRows: 0, parserErrors: [] };
  }

  const result = Papa.parse<string[]>(text.replace(/^\uFEFF/, ""), {
    quoteChar: '"',
    escapeChar: '"',
    skipEmptyLines: false,
  });
  const matrix = result.data.map((row) => row.map((value) => String(value ?? "")));
  while (matrix.length && isBlankRow(matrix[matrix.length - 1])) matrix.pop();
  if (!matrix.length || isBlankRow(matrix[0])) {
    return {
      headers: [],
      rows: [],
      blankRows: Math.max(matrix.length - 1, 0),
      malformedRows: 0,
      parserErrors: result.errors.map((error) => cleanParserMessage(error.message)),
    };
  }

  const headers = matrix[0].map((header) => header.trim());
  const errorsByDataIndex = new Map<number, string[]>();
  for (const error of result.errors) {
    const dataIndex = Math.max((error.row ?? 1) - 1, 0);
    const existing = errorsByDataIndex.get(dataIndex) ?? [];
    existing.push(cleanParserMessage(error.message));
    errorsByDataIndex.set(dataIndex, existing);
  }

  const rows: ParsedCsvRow[] = [];
  let blankRows = 0;
  for (let dataIndex = 1; dataIndex < matrix.length; dataIndex += 1) {
    const values = matrix[dataIndex];
    if (isBlankRow(values)) {
      blankRows += 1;
      continue;
    }
    const parserErrors = errorsByDataIndex.get(dataIndex - 1) ?? [];
    if (values.length !== headers.length) {
      parserErrors.push(
        `Expected ${headers.length} columns but found ${values.length}.`,
      );
    }
    rows.push({ rowNumber: dataIndex + 1, values, parserErrors });
  }

  const duplicateHeaders = new Set<string>();
  const seenHeaders = new Set<string>();
  for (const header of headers.map(normalizeHeader).filter(Boolean)) {
    if (seenHeaders.has(header)) duplicateHeaders.add(header);
    seenHeaders.add(header);
  }

  const parserErrors = result.errors
    .filter((error) => (error.row ?? 1) === 0)
    .map((error) => cleanParserMessage(error.message));
  if (headers.some((header) => !header.trim())) parserErrors.push("Every CSV column needs a header.");
  if (duplicateHeaders.size) parserErrors.push("CSV headers must be unique.");

  return {
    headers,
    rows,
    blankRows,
    malformedRows: rows.filter((row) => row.parserErrors.length > 0).length,
    parserErrors: Array.from(new Set(parserErrors)),
  };
}

function sanitizeText(value: string): string {
  return value
    .replace(/\r\n?/g, "\n")
    .replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F\u007F]/g, "")
    .trim();
}

function fieldValue(
  row: ParsedCsvRow,
  mapping: ColumnMapping,
  field: CanonicalField,
): string {
  const index = mapping[field];
  return index === null ? "" : sanitizeText(row.values[index] ?? "");
}

export function normalizeDealValue(value: string):
  | { value: string; error: null }
  | { value: null; error: string } {
  const trimmed = sanitizeText(value);
  if (!trimmed) return { value: null, error: "Missing deal value." };
  if (/^\(.*\)$/.test(trimmed) || /^-/.test(trimmed)) {
    return { value: null, error: "Deal value cannot be negative." };
  }

  let normalized = trimmed
    .replace(/^USD\s*/i, "")
    .replace(/\s*USD$/i, "")
    .replace(/^\$\s*/, "")
    .replaceAll(",", "")
    .trim();
  if (!/^\d+(?:\.\d{1,2})?$/.test(normalized)) {
    return { value: null, error: "Deal value is not a valid amount." };
  }
  const numeric = Number(normalized);
  if (!Number.isFinite(numeric) || numeric > MAX_DEAL_VALUE) {
    return { value: null, error: "Deal value is outside the supported range." };
  }
  normalized = numeric.toFixed(2);
  return { value: normalized, error: null };
}

function validDateParts(year: number, month: number, day: number): boolean {
  if (year < 1900 || year > 2100 || month < 1 || month > 12 || day < 1 || day > 31) {
    return false;
  }
  const value = new Date(Date.UTC(year, month - 1, day));
  return (
    value.getUTCFullYear() === year &&
    value.getUTCMonth() === month - 1 &&
    value.getUTCDate() === day
  );
}

function isoDate(year: number, month: number, day: number): string {
  return `${year.toString().padStart(4, "0")}-${month.toString().padStart(2, "0")}-${day.toString().padStart(2, "0")}`;
}

const MONTHS = new Map(
  ["jan", "feb", "mar", "apr", "may", "jun", "jul", "aug", "sep", "oct", "nov", "dec"].map(
    (month, index) => [month, index + 1],
  ),
);

export function normalizeQuoteDate(value: string):
  | { value: string | null; error: null }
  | { value: null; error: string } {
  const trimmed = sanitizeText(value);
  if (!trimmed) return { value: null, error: null };

  let match = /^(\d{4})-(\d{2})-(\d{2})$/.exec(trimmed);
  if (match) {
    const [, year, month, day] = match.map(Number);
    return validDateParts(year, month, day)
      ? { value: isoDate(year, month, day), error: null }
      : { value: null, error: "Quote date is not a valid calendar date." };
  }

  match = /^(\d{4})\/(\d{1,2})\/(\d{1,2})$/.exec(trimmed);
  if (match) {
    const [, year, month, day] = match.map(Number);
    return validDateParts(year, month, day)
      ? { value: isoDate(year, month, day), error: null }
      : { value: null, error: "Quote date is not a valid calendar date." };
  }

  match = /^(\d{1,2})[/-](\d{1,2})[/-](\d{4})$/.exec(trimmed);
  if (match) {
    const [, first, second, year] = match.map(Number);
    if (first <= 12 && second <= 12) {
      return { value: null, error: "Quote date is ambiguous; use YYYY-MM-DD." };
    }
    const month = first > 12 ? second : first;
    const day = first > 12 ? first : second;
    return validDateParts(year, month, day)
      ? { value: isoDate(year, month, day), error: null }
      : { value: null, error: "Quote date is not a valid calendar date." };
  }

  if (/^\d{1,2}[/-]\d{1,2}[/-]\d{2}$/.test(trimmed)) {
    return { value: null, error: "Quote date is ambiguous; use a four-digit year in YYYY-MM-DD format." };
  }

  match = /^([A-Za-z]{3,9})\s+(\d{1,2}),?\s+(\d{4})$/.exec(trimmed);
  if (match) {
    const month = MONTHS.get(match[1].slice(0, 3).toLocaleLowerCase("en-US"));
    const day = Number(match[2]);
    const year = Number(match[3]);
    return month && validDateParts(year, month, day)
      ? { value: isoDate(year, month, day), error: null }
      : { value: null, error: "Quote date is not a valid calendar date." };
  }

  match = /^(\d{1,2})\s+([A-Za-z]{3,9})\s+(\d{4})$/.exec(trimmed);
  if (match) {
    const day = Number(match[1]);
    const month = MONTHS.get(match[2].slice(0, 3).toLocaleLowerCase("en-US"));
    const year = Number(match[3]);
    return month && validDateParts(year, month, day)
      ? { value: isoDate(year, month, day), error: null }
      : { value: null, error: "Quote date is not a valid calendar date." };
  }

  return { value: null, error: "Quote date is invalid; use YYYY-MM-DD." };
}

export function normalizeLostStatus(value: string):
  | { value: "lost"; error: null }
  | { value: null; error: string } {
  const normalized = sanitizeText(value)
    .toLocaleLowerCase("en-US")
    .replace(/[_-]+/g, " ")
    .replace(/\s+/g, " ");
  if (!normalized || LOST_STATUSES.has(normalized)) return { value: "lost", error: null };
  if (WON_STATUSES.has(normalized)) {
    return { value: null, error: `Deal status “${sanitizeText(value)}” appears won.` };
  }
  return { value: null, error: `Status “${sanitizeText(value)}” is not a recognized lost status.` };
}

export function validateCsvRows(
  parsed: ParsedCsv,
  mapping: ColumnMapping,
  existingExternalIds: ReadonlySet<string> = new Set(),
): CsvValidationResult {
  const validRows: NormalizedDeal[] = [];
  const invalidRows: InvalidCsvRow[] = [];
  const seenExternalIds = new Set<string>();

  for (const row of parsed.rows) {
    const values = Object.fromEntries(
      CANONICAL_FIELDS.map((field) => [field, fieldValue(row, mapping, field)]),
    ) as Record<CanonicalField, string>;
    const errors = [...row.parserErrors];

    for (const field of CANONICAL_FIELDS) {
      if (values[field].length > FIELD_MAX_LENGTHS[field]) {
        errors.push(`${field.replaceAll("_", " ")} exceeds the ${FIELD_MAX_LENGTHS[field]} character limit.`);
      }
    }

    const dealValue = normalizeDealValue(values.deal_value);
    if (dealValue.error) errors.push(dealValue.error);
    if (!values.sales_notes && !values.transcript) errors.push("Missing sales notes or transcript.");

    const quoteDate = normalizeQuoteDate(values.quote_date);
    if (quoteDate.error) errors.push(quoteDate.error);
    const status = normalizeLostStatus(values.status);
    if (status.error) errors.push(status.error);

    const externalIdKey = values.external_deal_id.toLocaleLowerCase("en-US");
    if (externalIdKey) {
      if (seenExternalIds.has(externalIdKey)) {
        errors.push(`Deal ID ${values.external_deal_id} is duplicated in this CSV.`);
      } else if (existingExternalIds.has(externalIdKey)) {
        errors.push(`Deal ID ${values.external_deal_id} already exists in this workspace.`);
      }
      seenExternalIds.add(externalIdKey);
    }

    if (errors.length || !dealValue.value || status.error) {
      invalidRows.push({
        rowNumber: row.rowNumber,
        customer: values.customer_name || null,
        externalDealId: values.external_deal_id || null,
        errors: Array.from(new Set(errors)),
      });
      continue;
    }

    validRows.push({
      rowNumber: row.rowNumber,
      external_deal_id: values.external_deal_id || null,
      customer_name: values.customer_name || null,
      deal_value: dealValue.value,
      quote_date: quoteDate.value,
      status: "lost",
      salesperson: values.salesperson || null,
      service_type: values.service_type || null,
      lead_source: values.lead_source || null,
      sales_notes: values.sales_notes || null,
      transcript: values.transcript || null,
    });
  }

  return { totalRows: parsed.rows.length, validRows, invalidRows };
}

export function validateParsedCsvShape(parsed: ParsedCsv): string | null {
  if (!parsed.headers.length) return "This CSV does not contain a header row.";
  if (parsed.headers.some((header) => header.length > MAX_CSV_HEADER_LENGTH)) {
    return `CSV headers must be ${MAX_CSV_HEADER_LENGTH} characters or fewer.`;
  }
  if (parsed.parserErrors.length) return parsed.parserErrors.join(" ");
  if (!parsed.rows.length) return "This CSV contains headers but no deal rows.";
  if (parsed.rows.length > MAX_CSV_ROWS) {
    return "LostDeal AI currently supports up to 2,000 deals per CSV import.";
  }
  return null;
}
