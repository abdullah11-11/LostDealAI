import assert from "node:assert/strict";
import { register } from "node:module";
import test from "node:test";

register(new URL("../scripts/cloudflare-workers-loader.mjs", import.meta.url), import.meta.url);

const stalePreviewMeta = /<meta(?=[^>]*\bname=["']codex-preview["'])[^>]*>/i;

process.env.NEXT_PUBLIC_SUPABASE_URL ||= "https://example.supabase.co";
process.env.NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY ||= "public-test-key";

test("renders production social metadata without stale preview markers", async () => {
  const workerUrl = new URL("../dist/server/index.js", import.meta.url);
  workerUrl.searchParams.set("test", `${process.pid}-${Date.now()}`);
  const { default: worker } = await import(workerUrl.href);

  const response = await worker.fetch(
    new Request("http://localhost/", {
      headers: { accept: "text/html" },
    }),
    {
      NEXT_PUBLIC_SUPABASE_URL: "https://example.supabase.co",
      NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY: "public-test-key",
      ASSETS: {
        fetch: async () => new Response("Not found", { status: 404 }),
      },
    },
    {
      waitUntil() {},
      passThroughOnException() {},
    },
  );

  assert.equal(response.status, 200);
  assert.match(
    response.headers.get("content-type") ?? "",
    /^text\/html\b/i,
  );
  const html = await response.text();
  assert.doesNotMatch(html, stalePreviewMeta);
  assert.match(html, /property=["']og:image["'][^>]*content=["']https:\/\/lostdeal-ai\.equal-dune-2306\.chatgpt\.site\/og\.png["']/i);
  assert.match(html, /name=["']twitter:card["'][^>]*content=["']summary_large_image["']/i);
});
