import assert from "node:assert/strict";
import { readFile, readdir, stat } from "node:fs/promises";
import path from "node:path";
import test from "node:test";

import { formatDealCurrency } from "@/lib/deals/format";

const root = process.cwd();

async function source(relativePath: string) {
  return readFile(path.join(root, relativePath), "utf8");
}

async function sourceFiles(relativeDirectory: string): Promise<string[]> {
  const directory = path.join(root, relativeDirectory);
  const entries = await readdir(directory, { withFileTypes: true });
  const files = await Promise.all(entries.map(async (entry) => {
    const relative = path.join(relativeDirectory, entry.name);
    return entry.isDirectory() ? sourceFiles(relative) : [relative];
  }));
  return files.flat().filter((file) => /\.(?:ts|tsx|css)$/.test(file));
}

test("approved LostDeal AI logo derivatives are used and appropriately sized", async () => {
  const [brand, layout, wordmark, icon, social] = await Promise.all([
    source("components/brand-logo.tsx"),
    source("app/layout.tsx"),
    stat(path.join(root, "public/lostdeal-wordmark.webp")),
    stat(path.join(root, "public/lostdeal-icon.png")),
    stat(path.join(root, "public/og.png")),
  ]);
  assert.match(brand, /lostdeal-wordmark\.webp/);
  assert.match(brand, /lostdeal-icon\.png/);
  assert.doesNotMatch(brand, />LD</);
  assert.match(layout, /lostdeal-icon\.png/);
  assert.match(layout, /og\.png/);
  assert.ok(wordmark.size < 50_000);
  assert.ok(icon.size < 100_000);
  assert.ok(social.size < 250_000);
});

test("midnight theme tokens are centralized and legacy light branding is absent", async () => {
  const theme = await source("app/globals.css");
  for (const token of [
    "--background: #070b12",
    "--sidebar-background: #080e18",
    "--surface: #0d1523",
    "--surface-raised: #121c2d",
    "--surface-hover: #162235",
    "--brand-cyan: #22d3ee",
    "--brand-cyan-hover: #06b6d4",
    "--text-primary: #f8fafc",
  ]) assert.match(theme, new RegExp(token.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")));
  assert.match(theme, /prefers-reduced-motion/);

  const files = [...await sourceFiles("app"), ...await sourceFiles("components")];
  const joined = (await Promise.all(files.map(async (file) => `${file}\n${await source(file)}`))).join("\n");
  assert.doesNotMatch(joined, /bg-white|bg-\[#f7f8fb\]|text-\[#0b1739\]|\[#2952cc\]|\[#172554\]|favicon\.svg/);
});

test("shared controls preserve semantic colors and accessible focus styling", async () => {
  const ui = await source("components/ui.tsx");
  assert.match(ui, /high: "[^"]*red/);
  assert.match(ui, /medium: "[^"]*amber/);
  assert.match(ui, /low: "[^"]*slate/);
  assert.match(ui, /completed: "[^"]*emerald/);
  assert.match(ui, /destructive: "[^"]*red/);
  assert.match(ui, /focus-visible:ring-brand/);
  assert.match(ui, /placeholder:text-muted/);
});

test("navigation, mobile account actions, and workspace routes remain available", async () => {
  const shell = await source("components/dashboard-shell.tsx");
  for (const route of ["/dashboard", "/deals", "/upload"]) assert.match(shell, new RegExp(`href: "${route}"`));
  assert.match(shell, /aria-current=\{active \? "page"/);
  assert.match(shell, /aria-label="Log out"/);
  assert.match(shell, /lg:hidden/);
});

test("auth polish preserves server actions, redirects, and tenant-safe onboarding", async () => {
  const [auth, login, signup, onboarding] = await Promise.all([
    source("components/auth-screen.tsx"),
    source("app/(auth)/login/page.tsx"),
    source("app/(auth)/signup/page.tsx"),
    source("app/(auth)/onboarding/page.tsx"),
  ]);
  assert.match(auth, /loginAction/);
  assert.match(auth, /signupAction/);
  assert.match(auth, /useActionState\(action, INITIAL_STATE\)/);
  assert.match(auth, /name="next"/);
  assert.match(auth, /name="email"/);
  assert.match(auth, /name="password"/);
  assert.match(login, /redirectAuthenticatedUser\(\)/);
  assert.match(login, /getSafeNextPath\(next\)/);
  assert.match(signup, /redirectAuthenticatedUser\(\)/);
  assert.match(onboarding, /getAppAuthContext\(\)/);
  assert.match(onboarding, /redirect\("\/login\?next=%2Fonboarding"\)/);
  assert.match(onboarding, /redirect\("\/dashboard"\)/);
});

test("currency formatting stays centralized and cents never render awkwardly", () => {
  assert.equal(formatDealCurrency(300_250), "$300,250");
  assert.equal(formatDealCurrency(300_250.5), "$300,250.50");
  assert.equal(formatDealCurrency(null), "—");
});

test("upload presents four clear steps and preserves sample, demo, privacy, and duplicate guidance", async () => {
  const workflow = await source("components/csv-import-workflow.tsx");
  for (const label of ["Select CSV", "Map Columns", "Review", "Confirm Import"]) assert.match(workflow, new RegExp(label));
  assert.match(workflow, /Download Sample CSV/);
  assert.match(workflow, /Download Demo HVAC CSV/);
  assert.match(workflow, /existing deals are not imported twice/i);
  assert.match(workflow, /AI analysis does not start/i);
  assert.match(workflow, /authorized to process/i);
});

test("copy, transcript, and deletion interactions retain their safety and accessibility contracts", async () => {
  const [copy, transcript, deletion] = await Promise.all([
    source("components/copy-message-button.tsx"),
    source("components/expandable-transcript.tsx"),
    source("components/delete-deal-control.tsx"),
  ]);
  assert.match(copy, /navigator\.clipboard\.writeText\(message\)/);
  assert.doesNotMatch(copy, /fetch\(|\/api\//);
  assert.match(copy, /never sends it/i);
  assert.match(copy, /aria-live="polite"/);
  assert.match(transcript, /aria-expanded=\{expanded\}/);
  assert.match(transcript, /aria-controls=\{contentId\}/);
  assert.match(deletion, /setConfirming\(true\)/);
  assert.match(deletion, /Permanently delete this deal\?/);
  assert.match(deletion, /Yes, Delete Deal/);
  assert.match(deletion, /\/api\/deals\/delete/);
});

test("major loading, error, empty, and tenant-safe not-found states remain present", async () => {
  const [dashboard, deals, detail, notFound, error] = await Promise.all([
    source("app/(dashboard)/dashboard/page.tsx"),
    source("app/(dashboard)/deals/page.tsx"),
    source("app/(dashboard)/deals/[id]/page.tsx"),
    source("app/not-found.tsx"),
    source("app/(dashboard)/error.tsx"),
  ]);
  assert.match(dashboard, /No lost deals yet/);
  assert.match(dashboard, /No scored opportunities yet/);
  assert.match(deals, /No deals match your filters/);
  assert.match(detail, /Ready for Analysis/);
  assert.match(detail, /Analysis in progress/);
  assert.match(detail, /Analysis needs attention/);
  assert.doesNotMatch(notFound, /another workspace|organization_id|tenant/i);
  assert.match(error, /Your data has not been changed/);
});
