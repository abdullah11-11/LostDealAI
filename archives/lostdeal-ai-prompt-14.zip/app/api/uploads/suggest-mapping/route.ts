import { NextResponse } from "next/server";

import { suggestCsvMapping } from "@/lib/csv/ai-mapping";
import { runOpenAiMapping } from "@/lib/csv/ai-mapping-runner";
import { AiMappingRequestSchema } from "@/lib/csv/ai-mapping-schema";
import { mutationIssueResponse, validateMutationRequest } from "@/lib/security/origin";
import { enforceRateLimitOrRespond } from "@/lib/security/rate-limit";
import { getAuthorizedRouteContext } from "@/lib/security/route-auth";

export async function POST(request: Request) {
  const requestIssue = validateMutationRequest(request, "json");
  if (requestIssue) return mutationIssueResponse(requestIssue);
  const authorization = await getAuthorizedRouteContext();
  if (authorization.response) return authorization.response;
  const { identity } = authorization.context;
  const limited = await enforceRateLimitOrRespond(identity.id, "upload_ai_mapping");
  if (limited) return limited;

  try {
    const parsed = AiMappingRequestSchema.safeParse(await request.json());
    if (!parsed.success) {
      return NextResponse.json(
        { error: "The AI mapping request is invalid." },
        { status: 400, headers: { "Cache-Control": "private, no-store" } },
      );
    }
    const suggestions = await suggestCsvMapping(parsed.data, runOpenAiMapping);
    return NextResponse.json(
      { suggestions },
      { headers: { "Cache-Control": "private, no-store" } },
    );
  } catch {
    return NextResponse.json(
      { error: "AI suggestions are unavailable right now. You can continue mapping manually." },
      { status: 503, headers: { "Cache-Control": "private, no-store" } },
    );
  }
}
