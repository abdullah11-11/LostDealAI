# LostDeal AI commercial launch gap register

Updated: **2026-09-02**
States: `DONE`, `PENDING`, `OWNER ACTION REQUIRED`, `POST-V1`.

LostDeal AI is **not commercially launch-ready** while required items remain pending.

## Core product and packaging

| Item | State | Evidence / next step |
|---|---|---|
| Prompt 14 automated QA | DONE | Comprehensive pre-commercial QA checkpoint completed |
| Owner core-product live QA | DONE | Owner approved the V1 behavior before commercial work |
| Frozen V1 behavior preserved | DONE | Prompt 15.1 changes packaging/entitlements only |
| Pricing direction | DONE | Trial $0/14 days, Starter $15/month, Pro $45/month, Business Coming Soon |
| Final entitlement packaging | DONE | Central catalog differentiates current core, future Pro gates, and inactive Business |
| Seller structure decision | DONE | Pakistan-based individual / sole trader |
| Preferred MoR decision | DONE | Paddle preferred; Lemon Squeezy fallback |
| Paddle account approval | PENDING | Provider must approve seller, identity, product/domain, risk, and payout setup |

## Monetization and billing

| Item | State | Evidence / next step |
|---|---|---|
| Prompt 15 subscription/usage schema | DONE | Owner reports the Prompt 15 migration applied |
| Prompt 15.1 limit mirror | OWNER ACTION REQUIRED | Apply `20260902000000_prompt15_1_plan_limits.sql`, then run updated commercial SQL checks |
| Usage reservations/idempotency/concurrency | DONE | Existing server/RLS authority preserved; SHADOW mode remains active |
| Auto Convert | PENDING | Prompt 15.2; Pro entitlement exists but capability does not |
| Deep Recovery Analysis | PENDING | Prompt 15.3; Pro entitlement exists but capability does not |
| Checkout | PENDING | Prompt 16 only after Paddle approval and prerequisite feature milestones |
| Subscription synchronization | PENDING | Verified provider webhooks; redirects never grant access |
| Webhook signature/replay protection | PENDING | Prompt 16 raw-body verification and idempotency matrix |
| Billing portal, invoices, cancellations | PENDING | Provider-hosted lifecycle flow and policy approval |
| Upgrade/downgrade and past-due behavior | PENDING | Prompt 16 design and sandbox QA |
| Business connected plan | POST-V1 | Not purchasable; no active usage schedule or connected-data capability |

## Account and communications

| Item | State | Evidence / next step |
|---|---|---|
| Plan & Usage UI | DONE | Read-only catalog-derived price/status plus three current metrics only |
| Forgot/reset password code | DONE | Enumeration-safe recovery and server-side throttling |
| Production SMTP | PENDING | Configure verified sender, templates, SPF/DKIM/DMARC, redirects, and live test |
| Production email confirmation | PENDING | Same SMTP/domain requirement |
| Workspace/account deletion | PENDING | Define retention/cascade/legal policy and implement |

## Production operations

| Item | State | Evidence / next step |
|---|---|---|
| Custom domain | PENDING | Select and configure domain/TLS and callbacks |
| Monitoring and structured alerts | PENDING | Choose service and test alerts without sensitive payloads |
| Uptime checks | PENDING | Public, auth, and critical runtime health checks |
| OpenAI budget alerts | PENDING | Configure provider budgets and usage alerts |
| Backup/restore procedure | PENDING | Define retention and execute a restore drill |
| Support process | PENDING | Publish customer-facing channel and response expectations |
| Product analytics | PENDING | Approve privacy-respecting events and consent posture |

## Legal

| Item | State | Evidence / next step |
|---|---|---|
| Seller legal structure decision | DONE | Pakistan-based individual / sole trader; obtain appropriate local advice |
| Privacy Policy | PENDING | Legal review for customer data, Supabase, OpenAI, hosting, email, retention, and rights |
| Terms of Service | PENDING | Legal review before accepting payment |
| Cancellation/refund policy | PENDING | Align provider settings and applicable customer rules |
| Subprocessor disclosures | PENDING | Document Supabase, OpenAI, hosting, email, and future Paddle |

## Final commercial QA

| Item | State | Evidence / next step |
|---|---|---|
| Prompt 15.1 packaging QA | DONE | Targeted catalog, escalation, SHADOW, regression, build, audit, and scan gates |
| Prompt 15.2 Auto Convert QA | PENDING | Must be complete before Prompt 16 readiness |
| Prompt 15.3 Deep Analysis QA | PENDING | Must be complete before Prompt 16 readiness |
| Paddle sandbox QA | PENDING | Checkout/webhook/lifecycle/security matrix in Prompt 16 |
| Production SMTP recovery test | PENDING | Owner receives and uses a real reset email |
| Commercial production smoke test | PENDING | Domain, legal, billing, email, monitoring, backup, support |
| Final commercial release archive | PENDING | Separate final archive after all commercial QA |

## Post-V1 boundary

Connected CRM/service-system ingestion, continuous synchronization, scheduled processing, weekly Recovery Briefs, multi-member/team packaging, and other connected Business capabilities are `POST-V1`. They must not be sold as current capabilities.
