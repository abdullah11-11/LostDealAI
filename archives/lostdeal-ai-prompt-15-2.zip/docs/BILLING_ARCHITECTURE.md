# LostDeal AI billing and entitlement architecture

Prompt 15.2 adds the server-gated Auto Convert capability on top of the Prompt 15.1 packaging. There is still no payment SDK, checkout, payment webhook, provider secret, card storage, or paid-plan activation.

## Server-authoritative flow

```text
CUSTOMER → FUTURE PROVIDER CHECKOUT → PADDLE
         → VERIFIED IDEMPOTENT WEBHOOK
         → ORGANIZATION SUBSCRIPTION STATE
         → CENTRAL PLAN CATALOG
         → SERVER USAGE RESERVATION / FEATURE GATE
```

- Paddle is the preferred future Merchant of Record, subject to approval; Lemon Squeezy is the fallback.
- A successful redirect never grants access. Only a verified provider API result/webhook may synchronize paid state.
- The browser cannot choose a plan, price, usage limit, period, enforcement mode, or usage authority.
- Provider events must be raw-body signature verified, time-window checked, and atomically deduplicated before effects.
- LostDeal AI stores no card number, CVV, or raw payment credential. Checkout and payment-method changes remain provider-hosted.

## Central catalog

`lib/billing/plans.ts` is the shared application entitlement source of truth. It defines:

- `INTERNAL`: hidden, non-purchasable, unlimited, owner/internal only.
- `TRIAL`: $0 / 14 days; 50 imports, 10 Standard Analyses, 3 AI Mapping requests, and a future 25-row Auto Convert preview without live commercial access today.
- `STARTER`: $15/month; 250 imports, 30 Standard Analyses, 3 AI Mapping requests, and 0 Auto Convert rows; complete Smart Mapping remains usable.
- `PRO`: $45/month; 1,500 imports, 250 Standard Analyses, 30 AI Mapping requests, and 1,500 Auto Convert rows; commercial provider execution waits for Prompt 16.
- `BUSINESS`: Coming Soon, non-purchasable, no active usage schedule, and connected data false. It remains only for architecture compatibility.

Feature flags cover Standard Analysis, Smart Import, AI Smart Mapping, Auto Convert, Deep Analysis, normalized CSV export, Deal Intelligence, current batch analysis, and future connected data. Auto Convert is implemented and independently server-gated in Prompt 15.2; Deep Analysis remains a future entitlement for Prompt 15.3.

## Database limit mirror

The already-applied Prompt 15 migration remains immutable. It created organization subscriptions, usage events, RLS/grants, trial bootstrap, owner `INTERNAL` backfill, and reservation/commit RPCs.

Because that migration hard-coded preliminary numeric limits in `private.plan_usage_limit`, Prompt 15.1 adds the smallest possible forward migration:

`supabase/migrations/20260902000000_prompt15_1_plan_limits.sql`

It only replaces the private limit function and reasserts its revokes. It creates no table, policy, trigger, grant, or public RPC. Business returns the existing invalid-plan sentinel so it cannot behave like a sellable tier. Apply it after Prompt 15 and run `supabase/tests/prompt15_commercial_checks.sql`.

Prompt 15.2 adds `supabase/migrations/20260902010000_prompt15_2_auto_convert_limit.sql`. It minimally extends the existing metric constraint and generic functions for `AUTO_CONVERT_ROWS`; no table or policy is added. Apply it after Prompt 15.1 and run the same commercial checks.

## Metered usage

- `IMPORTED_DEALS`: actual successfully inserted rows, including partial-batch success.
- `AI_ANALYSES`: one unit for a fresh explicit provider-backed analysis that validates and persists.
- `AI_MAPPING_REQUESTS`: one unit for a fresh explicit AI Smart Mapping result that validates.
- `AUTO_CONVERT_ROWS`: rows actually submitted through completed provider-backed Auto Convert batches, with a one-unit minimum for a successful schema-only provider job.

Auto Convert does not also consume AI Mapping or Deal Analysis units. Deterministic/manual mapping, normalization/download, Recovery Score, dashboard/detail/account/page loads, themes, and outreach consume no usage and make no automatic OpenAI call.

Reservation and commit RPCs remain organization-scoped, idempotent, advisory-lock protected, and authorized by membership plus the 256-bit server-only usage authority. The browser has read-only approved subscription/aggregate usage access and no direct plan or usage DML grants. No `service_role` secret is used in normal runtime.

## Enforcement mode

- `OFF`: no database metering requirement.
- `SHADOW` (required now): records usage when the current limit mirror is available, calculates would-deny results, and preserves existing access while billing is unavailable.
- `ENFORCED`: future fail-closed behavior after provider and customer lifecycle QA.

Keep `BILLING_ENFORCEMENT_MODE=SHADOW`. Only `INTERNAL` may execute provider-backed Auto Convert in this mode; Trial/Pro feature access additionally requires future `ENFORCED` mode and a verified compatible subscription. Do not enable `ENFORCED` until the Prompt 15.2 migration is applied, Prompt 15.3 is complete, Paddle is approved, verified subscription synchronization and upgrade paths exist, customer messaging is ready, and billing sandbox/owner QA passes.

## Future implementation checklist

1. Apply and verify the Prompt 15.2 Auto Convert usage migration while keeping `SHADOW`.
2. Prompt 15.3 implements Deep Recovery Analysis with the same server-authoritative pattern.
3. Paddle approval and exact product/price configuration are confirmed.
4. Prompt 16 adds authenticated checkout creation, signed idempotent webhooks, safe status mapping, hosted portal, cancellation/upgrade flows, and lifecycle tests.
5. No Business checkout or connected-data entitlement is enabled until the post-V1 connected product actually exists.
