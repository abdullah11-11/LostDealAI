# LostDeal AI V1 unit economics

Model date: **2026-09-02**
Decision basis: owner-approved **$15 Starter** and **$45 Pro** monthly prices with the Prompt 15.2 allowances. These are planning ranges, not accounting forecasts or provider quotes.

## Assumptions

- One earlier synthetic Deal Analysis observed 918 input and 263 output tokens (1,181 total). Actual notes/transcripts, retries, model choice, caching, and future model pricing vary.
- Until production p50/p95 telemetry exists, budget **$0.002–$0.020 per successful Standard AI Deal Analysis** and **$0.001–$0.010 per successful AI Smart Mapping request**.
- Auto Convert's deterministic benchmark uses 1,800 source characters per row and 60–180 estimated output tokens per row. At the current `gpt-5.6-luna` standard rates of $0.20/M input and $1.20/M output, measured planning ranges are **$0.02–$0.03 for 100 rows**, **$0.09–$0.16 for 500**, and **$0.27–$0.48 for 1,500**. The server can fall back to the existing analysis model; the same heavy benchmark would be about **$5.00–$8.60** at current `gpt-5.6-sol` rates.
- Recovery Score, deterministic/manual mapping, CSV normalization/download, dashboards, Deal Intelligence page loads, and themes make zero OpenAI calls.
- Paddle's current public pay-as-you-go Merchant-of-Record price is **5% + $0.50 per checkout transaction**. That implies $1.25 on a $15 transaction and $2.75 on a $45 transaction. Refund, dispute, currency, payout, and negotiated fees may differ and require approval/onboarding confirmation. Source: https://www.paddle.com/pricing
- Hosting/database/monitoring is modeled as a broad usage-sensitive range. Imported-deal storage and query activity are represented there rather than given fake per-row precision.
- Human support, acquisition, fixed software, taxes on seller income, refunds, and chargebacks are excluded and must be monitored separately.

## Light, normal, and heavy usage

| Plan | Scenario | Analyses | AI mappings | Auto Convert rows | Estimated AI | Hosting/DB | Paddle fee | Approx. variable cost | Approx. gross margin |
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|
| Starter $15 | Light | 5 | 1 | 0 | $0.01–$0.11 | $1–$2 | $1.25 | $2.26–$3.36 | 78%–85% |
| Starter $15 | Normal | 15 | 2 | 0 | $0.03–$0.32 | $2–$4 | $1.25 | $3.28–$5.57 | 63%–78% |
| Starter $15 | Heavy | 30 | 3 | 0 | $0.06–$0.63 | $4–$8 | $1.25 | $5.31–$9.88 | 34%–65% |
| Pro $45 | Light | 25 | 3 | 100 | $0.07–$0.56 | $2–$4 | $2.75 | $4.82–$7.31 | 84%–89% |
| Pro $45 | Normal | 125 | 15 | 750 | $0.41–$2.89 | $4–$8 | $2.75 | $7.16–$13.64 | 70%–84% |
| Pro $45 | Heavy | 250 | 30 | 1,500 | $0.80–$5.78 | $6–$12 | $2.75 | $9.55–$20.53 | 54%–79% |

Margin is `(price - modeled variable cost) / price`, rounded. The table deliberately uses ranges rather than implying exact provider or infrastructure cost.

## Safety assessment

Both approved plans remain contribution-positive in the modeled legitimate heavy-use case. With the configured cost-efficient Auto Convert model, the full 1,500-row allowance adds less than $0.50 in the benchmark and Pro retains solid modeled headroom. Even the documented expensive-model fallback remains contribution-positive in this simplified model, but it materially reduces margin and should trigger configuration/telemetry review rather than becoming the default. Starter's adverse heavy-use case is thinner at roughly 34% gross margin before support/refunds, but it is not negative; it is acceptable for a self-serve launch only with the approved hard limits, provider-cost telemetry, infrastructure monitoring, and no hidden support commitment.

Before enabling `ENFORCED` billing or checkout:

1. Record p50/p95 input/output tokens and actual provider cost per successful analysis and mapping.
2. Record storage, database, worker, and support cost per active organization.
3. Confirm Paddle's approved commercial terms and Pakistan payout method/fees.
4. Model refunds, disputes, failed payments, currency conversion, and taxes.
5. Record Auto Convert input/output tokens, provider failures, rows per batch, and actual cost per completed row; re-run the heavy case before enabling paid Pro.
6. Re-run the full model after Prompt 15.3 Deep Analysis.

Pricing references checked on 2026-09-02: https://developers.openai.com/api/docs/pricing and https://developers.openai.com/api/docs/models/gpt-5.6-luna. Provider prices can change; benchmark ranges are not a quote or guarantee.

Business has no price or active commercial allowance, so no Business unit-economics claim is made.
