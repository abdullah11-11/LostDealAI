import Link from "next/link";
import { ArrowRight, Check, ShieldCheck } from "lucide-react";
import { BrandLogo } from "@/components/brand-logo";
import { buttonStyles } from "@/components/ui";

const steps = [
  ["01", "Import lost opportunities", "Bring in authorized CSV data with guided mapping, validation, and duplicate protection."],
  ["02", "Understand what happened", "Use grounded analysis to surface loss reasons, buying signals, and practical next actions."],
  ["03", "Prioritize recovery", "Apply a transparent deterministic score to focus your team on the best opportunities first."],
];

const previewDeals = [
  ["Northstar Heating", "Timing", "87/100", "High"],
  ["Harbor Dental", "No follow-up", "74/100", "High"],
  ["Juniper Retail", "Price", "61/100", "Medium"],
];

export default function Home() {
  return (
    <main className="min-h-screen bg-background text-content">
      <header className="border-b border-line bg-sidebar">
        <div className="mx-auto flex h-18 max-w-7xl items-center justify-between px-5 sm:px-8 lg:px-10">
          <BrandLogo size="lg" />
          <nav aria-label="Primary navigation" className="flex items-center gap-2">
            <Link href="/login" className={buttonStyles("ghost", "hidden sm:inline-flex")}>Log in</Link>
            <Link href="/signup" className={buttonStyles()}>Get started <ArrowRight aria-hidden="true" className="size-4" /></Link>
          </nav>
        </div>
      </header>

      <section className="border-b border-line bg-background">
        <div className="mx-auto grid max-w-7xl gap-14 px-5 py-18 sm:px-8 sm:py-24 lg:grid-cols-[1.05fr_0.95fr] lg:items-center lg:px-10 lg:py-28">
          <div>
            <p className="inline-flex rounded-full border border-brand/25 bg-brand/10 px-3 py-1.5 text-xs font-bold tracking-[0.08em] text-brand-content">Recovery intelligence for sales teams</p>
            <h1 className="mt-7 max-w-3xl text-balance text-5xl font-semibold leading-[1.04] tracking-[-0.045em] text-content sm:text-6xl lg:text-7xl">Recover the customers you almost had.</h1>
            <p className="mt-7 max-w-2xl text-pretty text-lg leading-8 text-secondary sm:text-xl">Upload lost sales, understand why they did not close, and identify the opportunities most worth revisiting.</p>
            <div className="mt-9 flex flex-col gap-3 sm:flex-row">
              <Link href="/signup" className={buttonStyles("primary", "h-12 px-6")}>Start recovering deals <ArrowRight aria-hidden="true" className="size-4" /></Link>
              <Link href="/login" className={buttonStyles("outline", "h-12 px-6")}>Open your workspace</Link>
            </div>
            <div className="mt-10 grid max-w-2xl gap-3 text-sm text-secondary sm:grid-cols-3">
              {["Grounded analysis", "Transparent scoring", "Action-ready guidance"].map((item) => <p key={item} className="flex items-center gap-2"><span className="flex size-5 items-center justify-center rounded-full bg-emerald-500/10 text-success-content"><Check aria-hidden="true" className="size-3" /></span>{item}</p>)}
            </div>
          </div>

          <div className="mx-auto w-full max-w-2xl rounded-2xl border border-line-strong bg-panel p-3 sm:p-4">
            <div className="overflow-hidden rounded-xl border border-line bg-sidebar">
              <div className="flex items-center justify-between border-b border-line px-5 py-4">
                <div><p className="text-sm font-bold text-content">Recovery queue</p><p className="mt-0.5 text-xs text-secondary">Illustrative product preview</p></div>
                <span className="rounded-lg border border-line bg-panel-raised px-3 py-2 text-xs font-semibold text-secondary">Ranked by score</span>
              </div>
              <div className="grid grid-cols-3 gap-px border-b border-line bg-line">
                {[["Lost deal value", "$428K"], ["High priority", "8"], ["Average score", "72"]].map(([label, value]) => <div key={label} className="bg-panel px-4 py-4 sm:px-5"><p className="text-[10px] font-bold uppercase tracking-wide text-muted">{label}</p><p className="mt-1 text-2xl font-semibold tracking-tight text-content">{value}</p></div>)}
              </div>
              <div className="p-3 sm:p-4">
                <div className="grid grid-cols-[1fr_auto] px-3 py-2 text-[10px] font-bold uppercase tracking-[0.12em] text-muted sm:grid-cols-[1fr_8rem_6rem]"><span>Opportunity</span><span className="hidden sm:block">Lost reason</span><span>Recovery</span></div>
                <div className="space-y-2">{previewDeals.map(([deal, reason, score, priority]) => <div key={deal} className="grid grid-cols-[1fr_auto] items-center gap-4 rounded-xl border border-line bg-panel px-3 py-3 sm:grid-cols-[1fr_8rem_6rem]"><div className="min-w-0"><p className="truncate text-sm font-bold text-content">{deal}</p><p className="mt-0.5 text-xs text-secondary">{priority} priority</p></div><p className="hidden text-xs font-semibold text-secondary sm:block">{reason}</p><p className="text-right text-sm font-bold text-content">{score}</p></div>)}</div>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className="mx-auto max-w-7xl px-5 py-20 sm:px-8 lg:px-10 lg:py-24">
        <div className="max-w-2xl"><p className="text-sm font-bold tracking-[0.08em] text-brand-content">A clearer recovery workflow</p><h2 className="mt-4 text-3xl font-semibold tracking-tight text-content sm:text-4xl">Turn closed-lost history into the next best conversation.</h2><p className="mt-4 leading-7 text-secondary">Bring the key recovery decisions into one focused workspace, so your team can spend less time reviewing old notes and more time acting.</p></div>
        <div className="mt-12 grid gap-5 lg:grid-cols-3">{steps.map(([number, title, description]) => <article key={number} className="rounded-2xl border border-line bg-panel p-6"><span className="flex size-11 items-center justify-center rounded-xl border border-brand/20 bg-brand/10 text-sm font-black text-brand">{number}</span><h3 className="mt-7 text-xl font-semibold tracking-tight text-content">{title}</h3><p className="mt-3 text-sm leading-7 text-secondary">{description}</p></article>)}</div>
      </section>

      <section className="border-y border-line bg-sidebar"><div className="mx-auto grid max-w-7xl gap-10 px-5 py-16 sm:px-8 lg:grid-cols-[0.85fr_1.15fr] lg:items-center lg:px-10 lg:py-20"><div><ShieldCheck aria-hidden="true" className="size-8 text-brand" /><h2 className="mt-5 text-3xl font-semibold tracking-tight text-content sm:text-4xl">Evidence first. Clear scores. Practical next steps.</h2></div><div className="grid gap-4 sm:grid-cols-2">{[["Grounded findings", "Analysis stays tied to supplied sales evidence."], ["Transparent scoring", "Recovery Score is an inspectable ranking, not a probability."], ["Actionable guidance", "Each analyzed opportunity leads toward a clear next action."], ["Responsible controls", "AI, scoring, outreach, and deletion remain explicit user actions."]].map(([title, description]) => <div key={title} className="rounded-xl border border-line bg-panel p-5"><h3 className="text-sm font-bold text-content">{title}</h3><p className="mt-2 text-sm leading-6 text-secondary">{description}</p></div>)}</div></div></section>

      <section className="mx-auto max-w-4xl px-5 py-20 text-center sm:px-8 lg:py-24"><h2 className="text-3xl font-semibold tracking-tight text-content sm:text-4xl">Your lost pipeline still has useful signals.</h2><p className="mx-auto mt-4 max-w-2xl leading-7 text-secondary">Bring those signals together and make the next recovery decision with more clarity.</p><Link href="/signup" className={buttonStyles("primary", "mt-8 h-12 px-6")}>Start with LostDeal AI <ArrowRight aria-hidden="true" className="size-4" /></Link></section>
      <footer className="border-t border-line bg-sidebar"><div className="mx-auto flex max-w-7xl flex-col gap-4 px-5 py-7 text-sm text-secondary sm:flex-row sm:items-center sm:justify-between sm:px-8 lg:px-10"><BrandLogo /><p>© 2026 LostDeal AI. Recovery intelligence for sales teams.</p></div></footer>
    </main>
  );
}
