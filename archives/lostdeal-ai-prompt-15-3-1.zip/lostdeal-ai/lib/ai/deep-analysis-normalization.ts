import type { TrustedDealSource } from "@/lib/ai/analyze-deal";
import type { DeepAnalysisDetails, DeepDealAnalysis } from "@/lib/ai/deep-analysis-schema";
import { normalizeEvidenceText } from "@/lib/ai/evidence-grounding";
import { DealAnalysisError } from "@/lib/ai/errors";
import { isEvidenceGrounded } from "@/lib/ai/validate-evidence";

export const CANONICAL_NO_DECISION_MAKER = "No supported decision-maker issue identified.";

function invalid(category: ConstructorParameters<typeof DealAnalysisError>[2]): never {
  throw new DealAnalysisError("AI_RESPONSE_INVALID", false, category);
}

function compactText(value: string): string {
  return value.normalize("NFKC").replace(/\s+/g, " ").trim();
}

function semanticText(value: string): string {
  return compactText(value)
    .toLocaleLowerCase("en-US")
    .replace(/[–—-]/g, " ")
    .replace(/[^a-z0-9\s]/g, "")
    .replace(/\s+/g, " ")
    .trim();
}

function isSafeNoDecisionMakerWording(value: string): boolean {
  const normalized = semanticText(value);
  if (!normalized.includes("decision maker")) return false;
  return [
    /^(?:there is )?no supported decision maker (?:issue|blocker|concern|dynamic)s?(?: identified)?$/,
    /^(?:there is )?no (?:source |available )?evidence (?:that )?(?:supports?|identifies?|indicates?|shows?|establishes?) (?:a |any )?decision maker (?:issue|blocker|concern|dynamic)s?$/,
    /^no decision maker (?:issue|blocker|concern|dynamic)s? (?:is|are|was|were) (?:supported|identified|indicated|shown|established) by (?:the )?(?:available )?(?:source|record|evidence|source evidence)$/,
    /^(?:the )?(?:available |current )?(?:source|record|evidence|source evidence) (?:does not|doesnt|do not) (?:support|identify|indicate|show|establish) (?:a |any )?decision maker (?:issue|blocker|concern|dynamic)s?$/,
    /^(?:the )?(?:source|record|evidence) provides no (?:evidence of|support for) (?:a |any )?decision maker (?:issue|blocker|concern|dynamic)s?$/,
    /^(?:there is )?insufficient (?:source |available )?evidence to (?:support|identify|indicate|show|establish|determine) (?:a |any )?decision maker (?:issue|blocker|concern|dynamic)s?$/,
    /^no evidence of (?:a |any )?decision maker (?:issue|blocker|concern|dynamic)s? (?:is|was) (?:present|found|identified|available)$/,
  ].some((pattern) => pattern.test(normalized));
}

function remapIndices(
  indices: readonly number[],
  oldToNew: ReadonlyMap<number, number>,
): number[] {
  const mapped: number[] = [];
  for (const index of indices) {
    const canonical = oldToNew.get(index);
    if (canonical === undefined) invalid("evidence_index_failure");
    if (!mapped.includes(canonical)) mapped.push(canonical);
  }
  return mapped;
}

function normalizeDeepStrings(deep: DeepAnalysisDetails): DeepAnalysisDetails {
  return {
    primary_blocker: {
      ...deep.primary_blocker,
      explanation: compactText(deep.primary_blocker.explanation),
    },
    secondary_blockers: deep.secondary_blockers.map((item) => ({
      ...item,
      explanation: compactText(item.explanation),
    })),
    recovery_thesis: {
      ...deep.recovery_thesis,
      explanation: compactText(deep.recovery_thesis.explanation),
    },
    customer_readiness: {
      ...deep.customer_readiness,
      explanation: compactText(deep.customer_readiness.explanation),
    },
    objection_hierarchy: deep.objection_hierarchy.map((item) => ({
      ...item,
      explanation: compactText(item.explanation),
    })),
    decision_dynamics: {
      ...deep.decision_dynamics,
      explanation: compactText(deep.decision_dynamics.explanation),
    },
    timing_interpretation: {
      ...deep.timing_interpretation,
      explanation: compactText(deep.timing_interpretation.explanation),
    },
    price_value_interpretation: {
      ...deep.price_value_interpretation,
      explanation: compactText(deep.price_value_interpretation.explanation),
    },
    competitor_dynamics: {
      ...deep.competitor_dynamics,
      explanation: compactText(deep.competitor_dynamics.explanation),
    },
    recovery_strategy: {
      ...deep.recovery_strategy,
      objective: compactText(deep.recovery_strategy.objective),
      recommended_angle: compactText(deep.recovery_strategy.recommended_angle),
      lead_with: compactText(deep.recovery_strategy.lead_with),
      avoid_leading_with: compactText(deep.recovery_strategy.avoid_leading_with),
      next_best_step: compactText(deep.recovery_strategy.next_best_step),
    },
    recovery_risk: {
      ...deep.recovery_risk,
      explanation: compactText(deep.recovery_risk.explanation),
    },
    margin_discount_caution: {
      ...deep.margin_discount_caution,
      explanation: compactText(deep.margin_discount_caution.explanation),
    },
    follow_up_strategy: {
      ...deep.follow_up_strategy,
      communication_objective: compactText(deep.follow_up_strategy.communication_objective),
      tone: compactText(deep.follow_up_strategy.tone),
      key_point_to_address: compactText(deep.follow_up_strategy.key_point_to_address),
      key_point_to_avoid: compactText(deep.follow_up_strategy.key_point_to_avoid),
      recommended_sequence: deep.follow_up_strategy.recommended_sequence.map(compactText),
    },
  };
}

function remapDeepEvidence(
  deep: DeepAnalysisDetails,
  oldToNew: ReadonlyMap<number, number>,
): DeepAnalysisDetails {
  const remap = (indices: readonly number[]) => remapIndices(indices, oldToNew);
  return {
    ...deep,
    primary_blocker: { ...deep.primary_blocker, evidence_indices: remap(deep.primary_blocker.evidence_indices) },
    secondary_blockers: deep.secondary_blockers.map((item) => ({ ...item, evidence_indices: remap(item.evidence_indices) })),
    recovery_thesis: { ...deep.recovery_thesis, evidence_indices: remap(deep.recovery_thesis.evidence_indices) },
    customer_readiness: { ...deep.customer_readiness, evidence_indices: remap(deep.customer_readiness.evidence_indices) },
    objection_hierarchy: deep.objection_hierarchy.map((item) => ({ ...item, evidence_indices: remap(item.evidence_indices) })),
    decision_dynamics: { ...deep.decision_dynamics, evidence_indices: remap(deep.decision_dynamics.evidence_indices) },
    timing_interpretation: { ...deep.timing_interpretation, evidence_indices: remap(deep.timing_interpretation.evidence_indices) },
    price_value_interpretation: { ...deep.price_value_interpretation, evidence_indices: remap(deep.price_value_interpretation.evidence_indices) },
    competitor_dynamics: { ...deep.competitor_dynamics, evidence_indices: remap(deep.competitor_dynamics.evidence_indices) },
    recovery_strategy: { ...deep.recovery_strategy, evidence_indices: remap(deep.recovery_strategy.evidence_indices) },
    recovery_risk: { ...deep.recovery_risk, evidence_indices: remap(deep.recovery_risk.evidence_indices) },
    margin_discount_caution: { ...deep.margin_discount_caution, evidence_indices: remap(deep.margin_discount_caution.evidence_indices) },
    follow_up_strategy: { ...deep.follow_up_strategy, evidence_indices: remap(deep.follow_up_strategy.evidence_indices) },
  };
}

export function normalizeDeepAnalysis(
  analysis: DeepDealAnalysis,
  source: TrustedDealSource,
): DeepDealAnalysis {
  const canonicalEvidence: DeepDealAnalysis["evidence"] = [];
  const evidenceIndexByKey = new Map<string, number>();
  const oldToNew = new Map<number, number>();

  analysis.evidence.forEach((evidence, oldIndex) => {
    if (!isEvidenceGrounded(evidence, source)) invalid("evidence_grounding_failure");
    const excerpt = normalizeEvidenceText(evidence.excerpt);
    const key = `${evidence.source}:${excerpt.toLocaleLowerCase("en-US")}`;
    let canonicalIndex = evidenceIndexByKey.get(key);
    if (canonicalIndex === undefined) {
      canonicalIndex = canonicalEvidence.length;
      evidenceIndexByKey.set(key, canonicalIndex);
      canonicalEvidence.push({ ...evidence, excerpt });
    }
    oldToNew.set(oldIndex, canonicalIndex);
  });

  const deep = remapDeepEvidence(normalizeDeepStrings(analysis.deep), oldToNew);
  if (deep.decision_dynamics.evidence_indices.length === 0) {
    if (!isSafeNoDecisionMakerWording(deep.decision_dynamics.explanation)) {
      invalid("unsupported_decision_maker_claim");
    }
    deep.decision_dynamics.explanation = CANONICAL_NO_DECISION_MAKER;
  }

  return {
    ...analysis,
    lost_reason_detail: compactText(analysis.lost_reason_detail),
    evidence: canonicalEvidence,
    positive_signals: analysis.positive_signals.map(compactText),
    negative_signals: analysis.negative_signals.map(compactText),
    recommended_action: compactText(analysis.recommended_action),
    recommended_timing: compactText(analysis.recommended_timing),
    follow_up_message: analysis.follow_up_message === null ? null : compactText(analysis.follow_up_message),
    deep,
  };
}
