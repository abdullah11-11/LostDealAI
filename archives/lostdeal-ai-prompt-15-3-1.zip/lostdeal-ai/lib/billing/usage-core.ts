import type { BillingEnforcementMode } from "@/lib/billing/config";
import {
  isUnlimited,
  type PlanEntitlements,
  type UsageLimit,
  type UsageMetric,
} from "@/lib/billing/plans";

export type UsageDecision = Readonly<{
  allowed: boolean;
  wouldDeny: boolean;
  remaining: number | null;
}>;

export function decideUsage(
  limit: UsageLimit,
  committed: number,
  reserved: number,
  requested: number,
  mode: BillingEnforcementMode,
): UsageDecision {
  if (![committed, reserved].every((value) => Number.isSafeInteger(value) && value >= 0)) {
    return { allowed: mode !== "ENFORCED", wouldDeny: true, remaining: 0 };
  }
  if (!Number.isSafeInteger(requested) || requested < 1) {
    return { allowed: false, wouldDeny: true, remaining: 0 };
  }
  if (isUnlimited(limit)) return { allowed: true, wouldDeny: false, remaining: null };

  const remaining = Math.max(0, limit - committed - reserved);
  const withinLimit = requested <= remaining;
  return {
    allowed: mode === "ENFORCED" ? withinLimit : true,
    wouldDeny: !withinLimit,
    remaining,
  };
}

export function expectedDatabaseLimit(
  entitlements: PlanEntitlements,
  metric: UsageMetric,
): number | null | undefined {
  const limit = entitlements.usage?.[metric];
  if (limit === undefined) return undefined;
  return isUnlimited(limit) ? null : limit;
}

export function utcCalendarMonth(now: Date): { start: string; end: string } {
  const start = new Date(Date.UTC(now.getUTCFullYear(), now.getUTCMonth(), 1));
  const end = new Date(Date.UTC(now.getUTCFullYear(), now.getUTCMonth() + 1, 1));
  return { start: start.toISOString(), end: end.toISOString() };
}
