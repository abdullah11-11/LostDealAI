# LostDeal AI Deep Recovery Analysis

Deep Recovery Analysis is a strict, evidence-grounded superset of Standard Analysis. It is implemented for owner `INTERNAL` use during the current `SHADOW` rollout. Starter remains on full Standard Analysis. Commercial Trial/Pro execution stays inactive until verified billing is implemented and enforcement is intentionally enabled.

## Product contract

One explicit **Run Deep Analysis** action can produce all Standard-compatible core fields plus:

- primary blocker and up to three distinct secondary blockers;
- recovery thesis and qualitative customer readiness;
- bounded objection hierarchy and decision dynamics;
- timing, price/value, and competitor interpretation;
- recovery strategy and recovery risk;
- margin/discount caution;
- a bounded follow-up strategy and one customer-facing draft for human review.

Deep is decision support, not hidden reasoning. It does not store chain-of-thought, calculate Recovery Score, estimate conversion probability, send outreach, or change Prompt 8 weights and thresholds.

## Explicit operations and usage

- Direct Deep on an unanalyzed deal: one provider operation and one `AI_ANALYSES` unit.
- Standard then explicit Deep: two operations and two total units.
- Reusing a valid stored Deep result: zero provider calls and zero new units.
- Explicit Deep re-run: one new operation and one unit.
- Import, Auto Convert, dashboard load, deal-list/detail load, account load, score calculation, plan state change, and downgrade: zero Deep calls.

The existing generic usage ledger remains authoritative. There is no Deep credit, point, token, table, or second metering system. Trial's future preview is capped atomically at two Deep operations inside its existing 10-unit `AI_ANALYSES` allowance.

## Access policy

| Plan/state | Standard | Deep provider execution now |
|---|---|---|
| `INTERNAL`, `SHADOW` | Active | Active |
| Starter | Active | Denied before provider |
| Trial/Pro, `SHADOW` | Entitlements can render | Inactive before provider |
| Verified Trial/Pro, future `ENFORCED` | Active | Eligible according to plan/status/usage |
| Business | Inactive commercial schedule | Inactive |

The server resolves organization identity, same-origin status, deal authorization, rate limit, plan/subscription state, schema readiness, and usage reservation before the provider runner can execute. Browser plan/model input is ignored. Rapid duplicate operations use a UUID idempotency key plus the existing database reservation and deal-processing claim.

Historical Deep output remains stored and viewable after a future downgrade. New Deep runs require eligible access. Paddle downgrade synchronization is intentionally deferred to Prompt 16.

## Validation and safety

- Responses API Structured Outputs with a strict Zod schema.
- `store: false`, low reasoning effort, 4,000-token output ceiling.
- At most eight exact core evidence excerpts; all Deep evidence links reference those excerpts by bounded index.
- Notes/transcript source limit: 60,000 characters, with no silent truncation.
- Unknown keys/enums, oversized arrays, invalid evidence indices, duplicate blocker categories, unsupported numeric claims, malformed output, and ungrounded core evidence are rejected.
- Weak evidence requires `OTHER`, low confidence, no invented blocker hierarchy, and cautious human review.
- Imported prompt injection remains untrusted deal data.
- No organization/user/subscription IDs, auth cookies, API keys, unrelated deals, or Recovery Score are sent.
- Suggested follow-up is never sent automatically and cannot add unsupported guarantees, terms, discounts, APR, reservations, or numeric claims.

Provider failure leaves no corrupted Deep object, marks the explicit attempt retryable through the existing state machine, and leaves any prior validated Standard result stored and visible. A successful validated Deep result replaces compatible core fields, stores its versioned Deep object, then invokes the unchanged deterministic scorer. A scoring failure never invalidates the completed AI analysis.

## Persistence and compatibility

Apply exactly once after Prompt 15.2:

`supabase/migrations/20260902020000_prompt15_3_deep_analysis.sql`

It adds one requested mode to `deals`; mode/schema/deep JSON/timestamp fields to `deal_analyses`; bounded constraints and authenticated column grants; and the two-operation Trial Deep check inside the existing reservation function. It creates no table, policy, service-role path, or payment object.

The original Prompt 15.3 release kept Standard functional before its Deep-only migration. That migration and the Prompt 15.3.1 runtime-hardening migration are now owner-confirmed as applied. The Deep route verifies column readiness. Deal detail still uses compatibility queries for stored results, while every new Standard/Deep analysis or Recovery Score write requires the protected runtime contract and otherwise returns `MIGRATION_REQUIRED` before a provider call or protected mutation.

Old Standard rows remain valid through database defaults and application normalization (`STANDARD`, `standard-1.0`). Deep core fields use the same existing columns, so the locked Recovery Score input contract stays compatible.

## Prompt 15.3.1 runtime hardening

The owner applied `20260902020000_prompt15_3_deep_analysis.sql` and reported the Prompt 15 commercial checks passing. The first real Internal Deep attempt then reached the provider but returned the safe public failure code `AI_RESPONSE_INVALID`; no invalid or partial Deep result was persisted.

The exact defect class was a contract mismatch after Structured Output parsing. The strict schema legitimately allowed harmless representation variants—most notably semantically equivalent no-decision-maker wording and duplicate exact evidence entries—but the post-validator required one byte-exact sentence and treated evidence deduplication as corruption without remapping Deep evidence indexes. Structurally valid, grounded provider output could therefore fail after parsing. The provider's raw customer-bearing response was correctly not retained, so the precise branch taken by that one historical response cannot be reconstructed; both contradictory rejection paths were present deterministically in the shipped code.

Prompt 15.3.1 fixes that boundary without making unsafe output permissive:

- exact source grounding occurs before canonicalization;
- bounded text is Unicode/whitespace normalized and safe unsupported-decision wording is canonicalized to the single stored sentence;
- duplicate exact evidence is deterministically deduplicated while every Deep evidence index is remapped and deduplicated;
- the normalized object is parsed through the strict Zod schema again;
- blocker consistency, evidence bounds, decision-maker, competitor, numeric, sensitive factual, psychological, and prompt-injection protections remain rejecting;
- safe diagnostic categories identify parsing, normalization, grounding, semantic, provider, persistence, and usage-finalization failure classes without storing raw responses, notes, transcripts, provider errors, or secrets.

Standard and Deep remain intentionally different: Standard stores the bounded core contract, while Deep returns the same core plus the versioned strategy object. Both remain on `gpt-5.6-terra`; Auto Convert remains on `gpt-5.6-luna`. Prompt 15.3.1 made no model, prompt-token-limit, price, plan-limit, scoring-formula, or provider-benchmark change, and repeated **zero** paid benchmark calls.

Runtime durability is also hardened. A validated result that requires metering is atomically stored with `analysis_usage_status = 'PENDING'`; an idempotent, analysis-bound finalizer then moves the existing `AI_ANALYSES` reservation and result to committed state. A bounded immediate retry is followed by an explicit customer-visible pending-reconciliation state. Retrying that state commits at most one unit and performs zero additional provider calls. OFF-mode rows remain explicitly legacy/unmetered.

Recovery Score ordering no longer constructs the known PostgREST relationship order. A tenant-checked SQL function applies the same search and filters, globally orders score ascending or descending with nulls last and deal ID tie-breaking, then paginates IDs. The application fetches only those IDs and restores the database order. The Prompt 8 formula remains unchanged, page loads still perform zero score writes, and scoring still performs zero provider calls.

Authenticated Data API clients now retain tenant-scoped read access but no direct insert/update access to AI-derived analysis fields or protected deal analysis state. Narrow RPCs require the existing server-only authority secret, authenticated membership, target organization/deal ownership, an allowlisted operation, and valid state/payload checks. No normal-runtime `service_role` path was added.

The owner has applied this migration exactly once after Prompt 15.3:

`supabase/migrations/20260905070000_prompt15_3_1_runtime_hardening.sql`

Its catalog contract and the updated `supabase/tests/prompt15_commercial_checks.sql` remain the verification source. Existing stored Standard/Deep output remains readable through the compatibility query.

## Prompt 15.3.2 usage reservation runtime hotfix

After Prompt 15.3.1 was applied, owner Standard and Deep attempts both failed before OpenAI. PostgreSQL logged `function date_trunc(unknown, time with time zone) does not exist` inside `public.reserve_organization_usage(text,uuid,text,integer,text)`. The function declared a local `current_time timestamptz := clock_timestamp()` and used `date_trunc('month', current_time)` for `INTERNAL`; PL/pgSQL resolved the ambiguous identifier against SQL `CURRENT_TIME` semantics, producing `time with time zone` instead of `timestamptz`.

Prompt 15.3.2 adds exactly one forward migration:

`supabase/migrations/20260905083511_prompt15_3_2_usage_reservation_runtime_hotfix.sql`

It replaces only that existing function and renames all 11 uses of the local clock to the explicit `runtime_now timestamptz := clock_timestamp()`. The exact signature, table return shape, `SECURITY DEFINER`, empty `search_path`, authority digest, membership check, metric and plan behavior, Trial two-Deep limit, advisory lock, idempotency, expiration, 15-minute reservation, and authenticated-only execution grant remain unchanged. It adds no table, policy, metric, model, plan, price, payment object, service-role path, or private-schema grant.

The earlier automated suites did not catch the defect because they inspected the migration contract and exercised application workflows with deterministic stores; they did not execute the PL/pgSQL function in PostgreSQL. Prompt 15.3.2 adds an exact function-body equivalence guard plus explicit timestamp, signature, security, quota, expiration, duplicate-reservation, and Standard/Deep wiring coverage. Automated implementation made zero live OpenAI calls and zero paid benchmark calls.

Older `permission denied for schema private` log entries were not produced by the intended reservation application calls. Those calls entered the `SECURITY DEFINER` function and reached both `private.is_org_member` and `private.plan_usage_limit` before failing at `date_trunc`. No broad `private` schema permission is required or granted.

The hotfix migration still requires owner/ChatGPT database application, followed by the read-only commercial checks and one owner Standard and one owner Deep test. Fresh logs must be free of both the `date_trunc` runtime error and any private-schema permission error on those exact application paths; usage must show exactly one `AI_ANALYSES` unit per successful operation. Prompt 16 remains NO-GO until that validation passes.

## Server-only model configuration

```dotenv
OPENAI_AUTO_CONVERT_MODEL=gpt-5.6-luna
OPENAI_STANDARD_ANALYSIS_MODEL=gpt-5.6-terra
OPENAI_DEEP_ANALYSIS_MODEL=gpt-5.6-terra
```

`OPENAI_MODEL` retains its existing AI Mapping and Auto Convert fallback behavior. Standard and Deep use it as a compatibility fallback only when it equals the tested cost-safe Terra value; if either dedicated analysis variable is absent and the legacy value is another model, those two analysis modes fall back to Terra rather than silently escalating cost. All four OpenAI variables are server-only and must never use `NEXT_PUBLIC_` or appear in customer UI.
