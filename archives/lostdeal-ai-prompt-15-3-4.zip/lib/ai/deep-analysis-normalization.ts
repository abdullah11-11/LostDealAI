import type { TrustedDealSource } from "@/lib/ai/analyze-deal";
import {
  DEEP_EVIDENCE_INDEX_LIMIT,
  type DeepAnalysisDetails,
  type DeepDealAnalysis,
} from "@/lib/ai/deep-analysis-schema";
import { normalizeEvidenceText } from "@/lib/ai/evidence-grounding";
import {
  DealAnalysisError,
  DeepSemanticValidationError,
  type DeepSemanticFailureClass,
} from "@/lib/ai/errors";
import { isEvidenceGrounded } from "@/lib/ai/validate-evidence";

export const CANONICAL_NO_DECISION_MAKER = "No supported decision-maker issue identified.";

function invalid(category: ConstructorParameters<typeof DealAnalysisError>[2]): never {
  throw new DealAnalysisError("AI_RESPONSE_INVALID", false, category);
}

function semanticInvalid(failureClass: DeepSemanticFailureClass): never {
  throw new DeepSemanticValidationError(failureClass);
}

function compactText(value: string): string {
  return value.normalize("NFKC").replace(/\s+/g, " ").trim();
}

function semanticText(value: string): string {
  return compactText(value)
    .toLocaleLowerCase("en-US")
    .replace(/[–—\/-]/g, " ")
    .replace(/[^a-z0-9\s]/g, "")
    .replace(/\s+/g, " ")
    .trim();
}

export type DeepAbsenceDimension = "timing" | "price_value" | "competitor" | "discount";

const ABSENCE_DIMENSION_PATTERNS: Record<DeepAbsenceDimension, RegExp> = {
  timing: /\b(?:timing|timeframe|schedule|scheduling|date|deadline|urgency|follow ?up|event|trigger)\b/,
  price_value: /\b(?:price|pricing|value|cost|budget|affordability|financing|payment)\b/,
  competitor: /\b(?:competitor|provider|vendor|bid|quote|alternative|company|incumbent|comparison)\b/,
  discount: /\b(?:discount|discounting|price|pricing|value|margin|reduction|concession)\b/,
};

const ABSENCE_CONTEXT_PATTERN = /\b(?:evidence|source|record|information|context|support|supported|identify|identified|state|stated|mention|mentioned|show|shown|available|determine|establish|provided|recorded)\b/;
const CONTRADICTORY_CLAUSE_PATTERN = /\b(?:and|but|however|although|though|yet|whereas|while|because|therefore|thus|instead|despite|even though|caused|chose|selected|preferred)\b/;
const POSITIVE_ASSERTION_PATTERN = /\b(?:customer|buyer|homeowner|client|they|he|she)\b.*\b(?:chose|selected|preferred|bought|purchased|signed|accepted|rejected|decided|went|switched|hired|committed|cancelled|canceled)\b|\b(?:must|should|will|would)\b/;

/**
 * Accept only a small grammar of single-clause, source-scoped absence wording.
 * This is deliberately narrower than general natural-language negation so a
 * positive unsupported assertion cannot be laundered through canonicalization.
 */
export function isSafeDeepAbsenceExplanation(
  dimension: DeepAbsenceDimension,
  value: string,
): boolean {
  const compact = compactText(value).toLocaleLowerCase("en-US");
  const withoutFinalPeriod = compact.endsWith(".") ? compact.slice(0, -1) : compact;
  if (/[,:;!?]/.test(withoutFinalPeriod) || withoutFinalPeriod.includes(".")) return false;

  const normalized = semanticText(withoutFinalPeriod);
  const normalizedConnectors = normalized
    .replace(/\bprice or value\b/g, "price value")
    .replace(/\bprice or discount(?:ing)?\b/g, "price discount")
    .replace(/\bcompetitor or provider\b/g, "competitor provider")
    .replace(/\btiming or scheduling\b/g, "timing scheduling");
  const approvedDiscountCaution = dimension === "discount" && /^(?:a |an )?(?:discount|discounting|price reduction|concession) (?:is|would be) (?:premature|unnecessary|unsupported) (?:because|given|with) (?:the )?(?:(?:absence|lack) of|there is no|no|insufficient) (?:direct |source |available )*(?:price |pricing |discount |value )*(?:evidence|support|information)(?: is available)?$/.test(normalized);
  if (
    !ABSENCE_DIMENSION_PATTERNS[dimension].test(normalized)
    || !ABSENCE_CONTEXT_PATTERN.test(normalized)
    || (CONTRADICTORY_CLAUSE_PATTERN.test(normalized) && !approvedDiscountCaution)
    || (POSITIVE_ASSERTION_PATTERN.test(normalized) && !approvedDiscountCaution)
    || /\bor\b/.test(normalizedConnectors)
  ) return false;

  return approvedDiscountCaution || [
    /^(?:there (?:is|are) )?no\b/,
    /^(?:there (?:is|are) )?insufficient\b/,
    /^(?:the )?(?:source|record|evidence|source evidence|available evidence|information)\b.*\b(?:does not|doesnt|did not|didnt|do not|lacks?|provides no|contains no|shows no|offers no|gives no|is silent)\b/,
    /^(?:the )?(?:source|record|evidence|source evidence|available evidence|information)\b.*\b(?:is|are|was|were) insufficient\b/,
    /\b(?:is|are|was|were) (?:not (?:currently )?(?:a )?supported|unsupported|not identified|not shown|not stated|not mentioned|not established|not evidenced|not evident|not addressed|not cited)\b/,
    /\b(?:does not|doesnt|did not|didnt) (?:appear|seem) to be (?:the |a )?(?:primary |direct |supported )?(?:reason|blocker|issue|factor)\b/,
    /\b(?:cannot|can not) be (?:determined|identified|established|supported|confirmed|assessed|inferred|justified)\b/,
    /\bhas no (?:evidence|support|basis)\b/,
    /^nothing in (?:the )?(?:source|record|evidence)\b/,
    /^(?:the )?customer\b.*\b(?:did not|didnt|does not|doesnt)\b.*\b(?:mention|state|identify|raise|cite|name|discuss|provide|indicate)\b/,
  ].some((pattern) => pattern.test(normalized));
}

type ReasonedDeepItem = {
  reason: string;
  explanation: string;
  evidence_indices: number[];
};

function collapseExactDuplicateReasons<T extends ReasonedDeepItem>(
  items: readonly T[],
  failureClass: "duplicate_secondary_blocker" | "duplicate_objection_reason",
): T[] {
  const canonical: T[] = [];
  const canonicalIndexByReason = new Map<string, number>();

  for (const item of items) {
    const priorIndex = canonicalIndexByReason.get(item.reason);
    if (priorIndex === undefined) {
      canonicalIndexByReason.set(item.reason, canonical.length);
      canonical.push({ ...item, evidence_indices: [...item.evidence_indices] });
      continue;
    }

    const prior = canonical[priorIndex];
    if (semanticText(prior.explanation) !== semanticText(item.explanation)) {
      semanticInvalid(failureClass);
    }
    const evidenceIndices = Array.from(new Set([
      ...prior.evidence_indices,
      ...item.evidence_indices,
    ]));
    if (evidenceIndices.length > DEEP_EVIDENCE_INDEX_LIMIT) semanticInvalid(failureClass);
    canonical[priorIndex] = { ...prior, evidence_indices: evidenceIndices };
  }

  return canonical;
}

function canonicalizeAbsenceInterpretations(deep: DeepAnalysisDetails): DeepAnalysisDetails {
  const normalized = { ...deep };

  if (
    deep.timing_interpretation.evidence_indices.length === 0
    && isSafeDeepAbsenceExplanation("timing", deep.timing_interpretation.explanation)
  ) {
    normalized.timing_interpretation = {
      ...deep.timing_interpretation,
      category: "INSUFFICIENT_EVIDENCE",
    };
  }
  if (
    deep.price_value_interpretation.evidence_indices.length === 0
    && isSafeDeepAbsenceExplanation("price_value", deep.price_value_interpretation.explanation)
  ) {
    normalized.price_value_interpretation = {
      ...deep.price_value_interpretation,
      category: "INSUFFICIENT_EVIDENCE",
    };
  }
  if (
    deep.competitor_dynamics.evidence_indices.length === 0
    && isSafeDeepAbsenceExplanation("competitor", deep.competitor_dynamics.explanation)
  ) {
    normalized.competitor_dynamics = {
      ...deep.competitor_dynamics,
      category: "NO_MEANINGFUL_EVIDENCE",
    };
  }
  if (
    deep.margin_discount_caution.evidence_indices.length === 0
    && isSafeDeepAbsenceExplanation("discount", deep.margin_discount_caution.explanation)
  ) {
    normalized.margin_discount_caution = {
      ...deep.margin_discount_caution,
      assessment: "UNSUPPORTED_BY_EVIDENCE",
    };
  }

  return normalized;
}

function isSafeNoDecisionMakerWording(value: string): boolean {
  const normalized = semanticText(value);
  if (!normalized.includes("decision maker")) return false;
  return [
    /^(?:there is )?no supported decision maker (?:issue|blocker|concern|dynamic)s?(?: identified)?$/,
    /^(?:there is )?no (?:source |available )?evidence (?:that )?(?:supports?|identifies?|indicates?|shows?|establishes?) (?:a |any )?decision maker (?:issue|blocker|concern|dynamic)s?$/,
    /^no decision maker (?:issue|blocker|concern|dynamic)s? (?:is|are|was|were) (?:supported|identified|indicated|shown|established) by (?:the )?(?:available )?(?:source|record|evidence|source evidence)$/,
    /^(?:the )?(?:available |current )?(?:source|record|evidence|source evidence) (?:does not|doesnt|do not) (?:support|identify|indicate|show|establish) (?:a |any )?decision maker (?:issue|blocker|concern|dynamic)s?$/,
    /^(?:the )?(?:source|record|evidence) provides no (?:evidence of|support for) (?:a |any )?decision maker (?:issue|blocker|concern|dynamic)s?$/,
    /^(?:there is )?insufficient (?:source |available )?evidence to (?:support|identify|indicate|show|establish|determine) (?:a |any )?decision maker (?:issue|blocker|concern|dynamic)s?$/,
    /^no evidence of (?:a |any )?decision maker (?:issue|blocker|concern|dynamic)s? (?:is|was) (?:present|found|identified|available)$/,
  ].some((pattern) => pattern.test(normalized));
}

function remapIndices(
  indices: readonly number[],
  oldToNew: ReadonlyMap<number, number>,
): number[] {
  const mapped: number[] = [];
  for (const index of indices) {
    const canonical = oldToNew.get(index);
    if (canonical === undefined) invalid("evidence_index_failure");
    if (!mapped.includes(canonical)) mapped.push(canonical);
  }
  return mapped;
}

function normalizeDeepStrings(deep: DeepAnalysisDetails): DeepAnalysisDetails {
  return {
    primary_blocker: {
      ...deep.primary_blocker,
      explanation: compactText(deep.primary_blocker.explanation),
    },
    secondary_blockers: deep.secondary_blockers.map((item) => ({
      ...item,
      explanation: compactText(item.explanation),
    })),
    recovery_thesis: {
      ...deep.recovery_thesis,
      explanation: compactText(deep.recovery_thesis.explanation),
    },
    customer_readiness: {
      ...deep.customer_readiness,
      explanation: compactText(deep.customer_readiness.explanation),
    },
    objection_hierarchy: deep.objection_hierarchy.map((item) => ({
      ...item,
      explanation: compactText(item.explanation),
    })),
    decision_dynamics: {
      ...deep.decision_dynamics,
      explanation: compactText(deep.decision_dynamics.explanation),
    },
    timing_interpretation: {
      ...deep.timing_interpretation,
      explanation: compactText(deep.timing_interpretation.explanation),
    },
    price_value_interpretation: {
      ...deep.price_value_interpretation,
      explanation: compactText(deep.price_value_interpretation.explanation),
    },
    competitor_dynamics: {
      ...deep.competitor_dynamics,
      explanation: compactText(deep.competitor_dynamics.explanation),
    },
    recovery_strategy: {
      ...deep.recovery_strategy,
      objective: compactText(deep.recovery_strategy.objective),
      recommended_angle: compactText(deep.recovery_strategy.recommended_angle),
      lead_with: compactText(deep.recovery_strategy.lead_with),
      avoid_leading_with: compactText(deep.recovery_strategy.avoid_leading_with),
      next_best_step: compactText(deep.recovery_strategy.next_best_step),
    },
    recovery_risk: {
      ...deep.recovery_risk,
      explanation: compactText(deep.recovery_risk.explanation),
    },
    margin_discount_caution: {
      ...deep.margin_discount_caution,
      explanation: compactText(deep.margin_discount_caution.explanation),
    },
    follow_up_strategy: {
      ...deep.follow_up_strategy,
      communication_objective: compactText(deep.follow_up_strategy.communication_objective),
      tone: compactText(deep.follow_up_strategy.tone),
      key_point_to_address: compactText(deep.follow_up_strategy.key_point_to_address),
      key_point_to_avoid: compactText(deep.follow_up_strategy.key_point_to_avoid),
      recommended_sequence: deep.follow_up_strategy.recommended_sequence.map(compactText),
    },
  };
}

function remapDeepEvidence(
  deep: DeepAnalysisDetails,
  oldToNew: ReadonlyMap<number, number>,
): DeepAnalysisDetails {
  const remap = (indices: readonly number[]) => remapIndices(indices, oldToNew);
  return {
    ...deep,
    primary_blocker: { ...deep.primary_blocker, evidence_indices: remap(deep.primary_blocker.evidence_indices) },
    secondary_blockers: deep.secondary_blockers.map((item) => ({ ...item, evidence_indices: remap(item.evidence_indices) })),
    recovery_thesis: { ...deep.recovery_thesis, evidence_indices: remap(deep.recovery_thesis.evidence_indices) },
    customer_readiness: { ...deep.customer_readiness, evidence_indices: remap(deep.customer_readiness.evidence_indices) },
    objection_hierarchy: deep.objection_hierarchy.map((item) => ({ ...item, evidence_indices: remap(item.evidence_indices) })),
    decision_dynamics: { ...deep.decision_dynamics, evidence_indices: remap(deep.decision_dynamics.evidence_indices) },
    timing_interpretation: { ...deep.timing_interpretation, evidence_indices: remap(deep.timing_interpretation.evidence_indices) },
    price_value_interpretation: { ...deep.price_value_interpretation, evidence_indices: remap(deep.price_value_interpretation.evidence_indices) },
    competitor_dynamics: { ...deep.competitor_dynamics, evidence_indices: remap(deep.competitor_dynamics.evidence_indices) },
    recovery_strategy: { ...deep.recovery_strategy, evidence_indices: remap(deep.recovery_strategy.evidence_indices) },
    recovery_risk: { ...deep.recovery_risk, evidence_indices: remap(deep.recovery_risk.evidence_indices) },
    margin_discount_caution: { ...deep.margin_discount_caution, evidence_indices: remap(deep.margin_discount_caution.evidence_indices) },
    follow_up_strategy: { ...deep.follow_up_strategy, evidence_indices: remap(deep.follow_up_strategy.evidence_indices) },
  };
}

export function normalizeDeepAnalysis(
  analysis: DeepDealAnalysis,
  source: TrustedDealSource,
): DeepDealAnalysis {
  const canonicalEvidence: DeepDealAnalysis["evidence"] = [];
  const evidenceIndexByKey = new Map<string, number>();
  const oldToNew = new Map<number, number>();

  analysis.evidence.forEach((evidence, oldIndex) => {
    if (!isEvidenceGrounded(evidence, source)) invalid("evidence_grounding_failure");
    const excerpt = normalizeEvidenceText(evidence.excerpt);
    const key = `${evidence.source}:${excerpt.toLocaleLowerCase("en-US")}`;
    let canonicalIndex = evidenceIndexByKey.get(key);
    if (canonicalIndex === undefined) {
      canonicalIndex = canonicalEvidence.length;
      evidenceIndexByKey.set(key, canonicalIndex);
      canonicalEvidence.push({ ...evidence, excerpt });
    }
    oldToNew.set(oldIndex, canonicalIndex);
  });

  let deep = remapDeepEvidence(normalizeDeepStrings(analysis.deep), oldToNew);
  if (deep.secondary_blockers.some((item) => item.reason === analysis.lost_reason)) {
    semanticInvalid("primary_secondary_overlap");
  }
  deep = {
    ...deep,
    secondary_blockers: collapseExactDuplicateReasons(
      deep.secondary_blockers,
      "duplicate_secondary_blocker",
    ),
    objection_hierarchy: collapseExactDuplicateReasons(
      deep.objection_hierarchy,
      "duplicate_objection_reason",
    ),
  };
  deep = canonicalizeAbsenceInterpretations(deep);
  if (deep.decision_dynamics.evidence_indices.length === 0) {
    if (!isSafeNoDecisionMakerWording(deep.decision_dynamics.explanation)) {
      invalid("unsupported_decision_maker_claim");
    }
    deep.decision_dynamics.explanation = CANONICAL_NO_DECISION_MAKER;
  }

  return {
    ...analysis,
    lost_reason_detail: compactText(analysis.lost_reason_detail),
    evidence: canonicalEvidence,
    positive_signals: analysis.positive_signals.map(compactText),
    negative_signals: analysis.negative_signals.map(compactText),
    recommended_action: compactText(analysis.recommended_action),
    recommended_timing: compactText(analysis.recommended_timing),
    follow_up_message: analysis.follow_up_message === null ? null : compactText(analysis.follow_up_message),
    deep,
  };
}
