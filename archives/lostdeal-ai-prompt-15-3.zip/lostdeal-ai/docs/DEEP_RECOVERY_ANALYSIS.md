# LostDeal AI Deep Recovery Analysis

Deep Recovery Analysis is a strict, evidence-grounded superset of Standard Analysis. It is implemented for owner `INTERNAL` use during the current `SHADOW` rollout. Starter remains on full Standard Analysis. Commercial Trial/Pro execution stays inactive until verified billing is implemented and enforcement is intentionally enabled.

## Product contract

One explicit **Run Deep Analysis** action can produce all Standard-compatible core fields plus:

- primary blocker and up to three distinct secondary blockers;
- recovery thesis and qualitative customer readiness;
- bounded objection hierarchy and decision dynamics;
- timing, price/value, and competitor interpretation;
- recovery strategy and recovery risk;
- margin/discount caution;
- a bounded follow-up strategy and one customer-facing draft for human review.

Deep is decision support, not hidden reasoning. It does not store chain-of-thought, calculate Recovery Score, estimate conversion probability, send outreach, or change Prompt 8 weights and thresholds.

## Explicit operations and usage

- Direct Deep on an unanalyzed deal: one provider operation and one `AI_ANALYSES` unit.
- Standard then explicit Deep: two operations and two total units.
- Reusing a valid stored Deep result: zero provider calls and zero new units.
- Explicit Deep re-run: one new operation and one unit.
- Import, Auto Convert, dashboard load, deal-list/detail load, account load, score calculation, plan state change, and downgrade: zero Deep calls.

The existing generic usage ledger remains authoritative. There is no Deep credit, point, token, table, or second metering system. Trial's future preview is capped atomically at two Deep operations inside its existing 10-unit `AI_ANALYSES` allowance.

## Access policy

| Plan/state | Standard | Deep provider execution now |
|---|---|---|
| `INTERNAL`, `SHADOW` | Active | Active |
| Starter | Active | Denied before provider |
| Trial/Pro, `SHADOW` | Entitlements can render | Inactive before provider |
| Verified Trial/Pro, future `ENFORCED` | Active | Eligible according to plan/status/usage |
| Business | Inactive commercial schedule | Inactive |

The server resolves organization identity, same-origin status, deal authorization, rate limit, plan/subscription state, schema readiness, and usage reservation before the provider runner can execute. Browser plan/model input is ignored. Rapid duplicate operations use a UUID idempotency key plus the existing database reservation and deal-processing claim.

Historical Deep output remains stored and viewable after a future downgrade. New Deep runs require eligible access. Paddle downgrade synchronization is intentionally deferred to Prompt 16.

## Validation and safety

- Responses API Structured Outputs with a strict Zod schema.
- `store: false`, low reasoning effort, 4,000-token output ceiling.
- At most eight exact core evidence excerpts; all Deep evidence links reference those excerpts by bounded index.
- Notes/transcript source limit: 60,000 characters, with no silent truncation.
- Unknown keys/enums, oversized arrays, invalid evidence indices, duplicate blocker categories, unsupported numeric claims, malformed output, and ungrounded core evidence are rejected.
- Weak evidence requires `OTHER`, low confidence, no invented blocker hierarchy, and cautious human review.
- Imported prompt injection remains untrusted deal data.
- No organization/user/subscription IDs, auth cookies, API keys, unrelated deals, or Recovery Score are sent.
- Suggested follow-up is never sent automatically and cannot add unsupported guarantees, terms, discounts, APR, reservations, or numeric claims.

Provider failure leaves no corrupted Deep object, marks the explicit attempt retryable through the existing state machine, and leaves any prior validated Standard result stored and visible. A successful validated Deep result replaces compatible core fields, stores its versioned Deep object, then invokes the unchanged deterministic scorer. A scoring failure never invalidates the completed AI analysis.

## Persistence and compatibility

Apply exactly once after Prompt 15.2:

`supabase/migrations/20260902020000_prompt15_3_deep_analysis.sql`

It adds one requested mode to `deals`; mode/schema/deep JSON/timestamp fields to `deal_analyses`; bounded constraints and authenticated column grants; and the two-operation Trial Deep check inside the existing reservation function. It creates no table, policy, service-role path, or payment object.

Before the migration is applied, Standard remains functional. Deal detail detects the missing Deep columns, uses the legacy field query, and displays a truthful setup-pending state. The Deep route verifies column readiness and returns `MIGRATION_REQUIRED` before reserving usage or calling OpenAI.

Old Standard rows remain valid through database defaults and application normalization (`STANDARD`, `standard-1.0`). Deep core fields use the same existing columns, so the locked Recovery Score input contract stays compatible.

## Server-only model configuration

```dotenv
OPENAI_AUTO_CONVERT_MODEL=gpt-5.6-luna
OPENAI_STANDARD_ANALYSIS_MODEL=gpt-5.6-terra
OPENAI_DEEP_ANALYSIS_MODEL=gpt-5.6-terra
```

`OPENAI_MODEL` retains its existing AI Mapping and Auto Convert fallback behavior. Standard and Deep use it as a compatibility fallback only when it equals the tested cost-safe Terra value; if either dedicated analysis variable is absent and the legacy value is another model, those two analysis modes fall back to Terra rather than silently escalating cost. All four OpenAI variables are server-only and must never use `NEXT_PUBLIC_` or appear in customer UI.
