# LostDeal AI V1 production security checklist

Use this checklist before expanding access beyond the current owner-only Site.

## Application controls

- [x] Verified server identity uses Supabase `getClaims()`.
- [x] Active organization is resolved server-side; browser organization IDs are never authorization truth.
- [x] RLS remains enabled on all six public application tables.
- [x] Mutation API routes enforce same-origin/Fetch Metadata checks and expected content types.
- [x] Distributed D1 rate limiting protects AI, upload, scoring, and deal-deletion mutations.
- [x] Forgot Password uses the same D1 architecture at 5 attempts per 15 minutes with a SHA-256 hashed normalized-email key; raw email is not stored in limiter telemetry.
- [x] Password update requires a verified Supabase recovery session plus a short-lived HttpOnly, SameSite recovery marker; reset tokens and passwords are never logged.
- [x] Plan entitlements and rollout mode are server-owned. Browser code cannot assign a plan or select `OFF`/`SHADOW`/`ENFORCED`.
- [x] Usage reservation/commit requires a server-only authority secret whose database migration stores only a SHA-256 verifier; direct authenticated browser RPC calls cannot forge usage.
- [x] Paid AI actions reserve organization quota before provider execution; enforced over-limit decisions produce zero provider calls.
- [x] AI authorization, authoritative deal retrieval, and the processing claim occur before OpenAI.
- [x] Manual AI trigger, 25-deal server batch cap, duplicate-call protection, one bounded transient retry, 50,000-character source cap, and token metadata remain active.
- [x] Security headers include CSP, frame denial, MIME sniffing protection, referrer policy, permissions policy, and HTTPS HSTS.
- [x] Authenticated pages and protected API responses are private/no-store.
- [x] CSV bytes are not retained; only structured rows and safe upload metadata are stored.
- [x] Errors and normal logs exclude source text, cookies, JWTs, provider payloads, and secrets.
- [x] Prompt 12 source, public assets, client bundle, and backup are scanned for secrets.
- [ ] Apply `supabase/migrations/20260830000000_prompt12_deal_delete.sql` to every Supabase environment before relying on Deal Delete.
- [ ] Run `supabase/tests/prompt12_security_checks.sql` after the migration.
- [x] Owner applied `supabase/migrations/20260901000000_prompt15_commercial_foundation.sql`.
- [ ] Apply `supabase/migrations/20260902000000_prompt15_1_plan_limits.sql` once to update the private approved-limit mirror.
- [ ] Run the updated `supabase/tests/prompt15_commercial_checks.sql` and a two-tenant authenticated read/RPC test after the forward migration.

## External production configuration

- [ ] Configure a production custom domain and verify HTTPS/HSTS behavior.
- [ ] Set the Supabase Site URL to the production origin.
- [ ] Allowlist only required Supabase redirect URLs.
- [ ] Keep anonymous sign-ins OFF.
- [ ] Keep unused authentication providers OFF.
- [ ] Keep `OPENAI_API_KEY` server-only; never use a `NEXT_PUBLIC_` prefix.
- [ ] Keep `APP_ORIGIN` set to the exact HTTPS production origin and allowlist only the required Supabase callbacks.
- [ ] Keep `BILLING_ENFORCEMENT_MODE=SHADOW` until verified checkout/subscription synchronization and billing QA exist.
- [ ] Keep `BILLING_USAGE_AUTHORITY_SECRET` server-only and synchronized with the migration verifier; never rotate either side independently.
- [ ] Configure custom SMTP, SPF/DKIM/DMARC, and live password-recovery delivery before commercial launch.
- [ ] Keep Supabase service-role/secret keys and database credentials out of client code and Sites source.
- [ ] Verify RLS and least-privilege grants on every public application table after each migration.
- [ ] Set provider-side OpenAI budget limits and usage alerts.
- [ ] Define backup and restore procedures and test restoration.
- [ ] Define privacy-safe logging, monitoring, alerting, and incident-response ownership.
- [ ] Schedule deletion of synthetic security-test accounts and rows.
- [ ] Prepare reviewed privacy policy and terms before commercial launch.

> **Production launch requirement: enable verified email confirmation after custom SMTP/domain is configured.**

Development Confirm Email may intentionally remain off. Do not enable production
confirmation until the sending domain, SMTP delivery, confirmation URL, and
support/recovery path have been tested. Prompt 12 does not change remote
Supabase authentication settings.

## Distributed rate limits

Limits are fixed server-side and keyed by verified user ID plus allowlisted
action. Browser payloads cannot select an action, limit, window, or batch size.
The D1 increment is atomic across workers; old windows are pruned after 24
hours. If the shared backend is unavailable, protected mutations fail closed.

| Action | Limit | Window |
| --- | ---: | ---: |
| Single AI analysis | 8 | 10 minutes |
| Batch AI analysis | 2 | 15 minutes |
| Upload validation | 20 | 10 minutes |
| Upload import | 6 | 10 minutes |
| Single deterministic score | 60 | 10 minutes |
| Batch score / refresh | 40 | 10 minutes |
| Deal deletion | 10 | 10 minutes |
| Forgot password (hashed normalized email) | 5 | 15 minutes |

Blocked requests return `429 Too Many Requests` with a bounded `Retry-After`
value and a generic message. Normal read-only navigation is not rate-limited.

## Security-header compatibility

The CSP denies framing, objects, foreign forms, and non-self scripts. The current
Vinext runtime requires compatible inline script/style allowances; a nonce-based
CSP is a future hardening option once the hosting runtime exposes a stable nonce
pipeline. `connect-src` permits only same-origin requests and Supabase HTTPS.

## Dependency audit record

The final Prompt 12 production audit (`npm audit --omit=dev`) reports zero
known vulnerabilities after updating Next.js and the WebSocket dependency.
The full development-tool audit retains three non-production findings:

- one low-severity local source-map file-read advisory in Babel with no
  published compatible fixed release;
- one high-severity `image-size` parser advisory inherited from Vinext, whose
  only offered resolution is a major beta framework upgrade; and
- the corresponding Vinext aggregate finding.

These packages are not production dependencies. The application no longer
imports or exposes Vinext's image-optimization endpoint, so uploaded CSV data
cannot reach the affected image parsers. Builds process only reviewed repository
source, not untrusted source maps. Re-evaluate the compatible stable Vinext and
Babel releases before the next production milestone; do not use a forced major
upgrade as an audit substitute.

## Known scoped limitations

- Production email confirmation awaits custom SMTP/domain configuration.
- Workspace, organization, and account deletion are not implemented in Prompt 12.
- Formal privacy/legal documents are external launch deliverables.
- Free-text notes/transcripts may contain customer-provided personal data.
- The configured external AI provider processes relevant source only after an explicit Analyze action.
- Monitoring and alert delivery depend on deployment/provider capabilities and operator setup.
- The deal-delete Supabase migration must be applied before that control is production-functional.
