import { AI_CONFIG } from "@/lib/ai/config";
import {
  analyzeDeal,
  type AnalysisModelRunner,
  type CompletedDealAnalysis,
  type TrustedDealSource,
} from "@/lib/ai/analyze-deal";
import { runWithConcurrency } from "@/lib/ai/batch";
import type { DealAnalysis } from "@/lib/ai/deal-analysis-schema";
import { DealAnalysisError, toDealAnalysisError, type AnalysisErrorCode } from "@/lib/ai/errors";

export type SourceDealRow = {
  id: string;
  deal_value: number | string;
  quote_date: string | null;
  service_type: string | null;
  status: string;
  sales_notes: string | null;
  transcript: string | null;
  analysis_status: string;
};

export type AnalysisPersistenceData = DealAnalysis & {
  recovery_score: null;
  recovery_priority: null;
  score_explanation: null;
  model_metadata: CompletedDealAnalysis["metadata"];
};

export type DealAnalysisStore = {
  fetch(dealId: string): Promise<SourceDealRow | null>;
  inspectExisting(dealId: string): Promise<{ valid: boolean; scored: boolean } | null>;
  repairCompleted(dealId: string): Promise<boolean>;
  scoreCompleted(dealId: string): Promise<boolean>;
  reserveUsage?(dealId: string): Promise<{ allowed: boolean; isNew: boolean }>;
  commitUsage?(dealId: string): Promise<void>;
  claim(dealId: string): Promise<boolean>;
  persistAndComplete(dealId: string, data: AnalysisPersistenceData): Promise<boolean>;
  fail(dealId: string, code: AnalysisErrorCode): Promise<void>;
  countPending(): Promise<number>;
  listPending(limit: number): Promise<string[]>;
};

export type SafeAnalysisUsage = {
  model: string;
  input_tokens?: number;
  output_tokens?: number;
  total_tokens?: number;
};

export type SingleDealAnalysisResult =
  | { status: "completed"; fresh: false }
  | { status: "completed"; fresh: true; usage: SafeAnalysisUsage }
  | { status: "processing" }
  | { status: "quota_exceeded" }
  | { status: "not_found" }
  | { status: "failed"; code: AnalysisErrorCode };

export type BatchAnalysisResult = {
  selected: number;
  completed: number;
  failed: number;
  skipped: number;
  remainingPending: number;
};

function trustedSource(deal: SourceDealRow): TrustedDealSource {
  return {
    dealValue: String(deal.deal_value),
    quoteDate: deal.quote_date,
    serviceType: deal.service_type,
    status: deal.status,
    salesNotes: deal.sales_notes,
    transcript: deal.transcript,
  };
}

export function toPersistenceData(result: CompletedDealAnalysis): AnalysisPersistenceData {
  return {
    ...result.analysis,
    recovery_score: null,
    recovery_priority: null,
    score_explanation: null,
    model_metadata: result.metadata,
  };
}

export async function analyzeDealWithStore(
  store: DealAnalysisStore,
  dealId: string,
  runModel: AnalysisModelRunner,
): Promise<SingleDealAnalysisResult> {
  const deal = await store.fetch(dealId);
  if (!deal) return { status: "not_found" };

  let existing: { valid: boolean; scored: boolean } | null;
  try {
    existing = await store.inspectExisting(dealId);
  } catch {
    return { status: "failed", code: "ANALYSIS_FAILED" };
  }
  if (existing?.valid) {
    if (deal.analysis_status !== "completed" && !await store.repairCompleted(dealId)) {
      return { status: "failed", code: "ANALYSIS_FAILED" };
    }
    if (!existing.scored) {
      try {
        await store.scoreCompleted(dealId);
      } catch {
        // Scoring is a separate deterministic stage and must not invalidate analysis.
      }
    }
    return { status: "completed", fresh: false };
  }

  if (deal.analysis_status === "completed") return { status: "completed", fresh: false };
  if (deal.analysis_status === "processing") return { status: "processing" };

  if (store.reserveUsage) {
    try {
      const reservation = await store.reserveUsage(dealId);
      if (!reservation.allowed) return { status: "quota_exceeded" };
      if (!reservation.isNew) return { status: "processing" };
    } catch {
      return { status: "failed", code: "ANALYSIS_FAILED" };
    }
  }

  let claimed = false;
  try {
    claimed = await store.claim(dealId);
  } catch {
    return { status: "failed", code: "ANALYSIS_FAILED" };
  }
  if (!claimed) {
    const latest = await store.fetch(dealId);
    if (!latest) return { status: "not_found" };
    const stored = await store.inspectExisting(dealId).catch(() => null);
    if (stored?.valid) {
      if (latest.analysis_status !== "completed" && !await store.repairCompleted(dealId)) {
        return { status: "failed", code: "ANALYSIS_FAILED" };
      }
      if (!stored.scored) await store.scoreCompleted(dealId).catch(() => false);
      return { status: "completed", fresh: false };
    }
    if (latest.analysis_status === "completed") return { status: "completed", fresh: false };
    return { status: "processing" };
  }

  let result: CompletedDealAnalysis;
  try {
    result = await analyzeDeal(trustedSource(deal), runModel);
    if (!await store.persistAndComplete(dealId, toPersistenceData(result))) {
      throw new DealAnalysisError("ANALYSIS_FAILED");
    }
  } catch (error) {
    const safeError = toDealAnalysisError(error);
    await store.fail(dealId, safeError.code);
    return { status: "failed", code: safeError.code };
  }

  if (store.commitUsage) {
    try {
      await store.commitUsage(dealId);
    } catch {
      // The analysis is already safely persisted. Its reservation remains
      // bounded and cannot be released by the browser.
    }
  }

  try {
    await store.scoreCompleted(dealId);
  } catch {
    // Keep completed AI analysis intact; users can retry deterministic scoring.
  }
  return {
    status: "completed",
    fresh: true,
    usage: {
      model: result.metadata.model,
      ...(result.metadata.input_tokens !== undefined ? { input_tokens: result.metadata.input_tokens } : {}),
      ...(result.metadata.output_tokens !== undefined ? { output_tokens: result.metadata.output_tokens } : {}),
      ...(result.metadata.total_tokens !== undefined ? { total_tokens: result.metadata.total_tokens } : {}),
    },
  };
}

export async function analyzePendingWithStore(
  store: DealAnalysisStore,
  runModel: AnalysisModelRunner,
): Promise<BatchAnalysisResult> {
  const pendingCount = await store.countPending();
  const ids = await store.listPending(AI_CONFIG.batchSizeLimit);
  const results = await runWithConcurrency(ids, (id) => analyzeDealWithStore(store, id, runModel));
  let completed = 0;
  let failed = 0;
  let skipped = 0;
  for (const result of results) {
    if (result.status === "rejected") failed += 1;
    else if (result.value.status === "completed") completed += 1;
    else if (result.value.status === "failed") failed += 1;
    else skipped += 1;
  }
  return {
    selected: ids.length,
    completed,
    failed,
    skipped,
    remainingPending: Math.max(0, pendingCount - ids.length),
  };
}
