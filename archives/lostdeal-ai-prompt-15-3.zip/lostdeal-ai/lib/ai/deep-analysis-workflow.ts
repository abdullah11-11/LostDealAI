import {
  analyzeDeepDeal,
  type CompletedDeepDealAnalysis,
  type DeepAnalysisModelRunner,
} from "@/lib/ai/deep-analysis";
import type { DeepAnalysisDetails } from "@/lib/ai/deep-analysis-schema";
import type { DealAnalysis } from "@/lib/ai/deal-analysis-schema";
import type { SourceDealRow } from "@/lib/ai/analysis-workflow";
import { DealAnalysisError, toDealAnalysisError, type AnalysisErrorCode } from "@/lib/ai/errors";
import type { SafeAnalysisUsage } from "@/lib/ai/analysis-workflow";

export type DeepAnalysisPersistenceData = DealAnalysis & {
  recovery_score: null;
  recovery_priority: null;
  score_explanation: null;
  analysis_mode: "DEEP";
  analysis_schema_version: string;
  deep_analysis: DeepAnalysisDetails;
  deep_analyzed_at: string;
  model_metadata: CompletedDeepDealAnalysis["metadata"];
};

export type DeepAnalysisStore = {
  fetch(dealId: string): Promise<SourceDealRow | null>;
  inspectExisting(dealId: string): Promise<{ deepValid: boolean; scored: boolean } | null>;
  repairCompleted(dealId: string): Promise<boolean>;
  scoreCompleted(dealId: string): Promise<boolean>;
  reserveUsage(dealId: string, operationId: string): Promise<{ allowed: boolean; isNew: boolean }>;
  commitUsage(dealId: string, operationId: string): Promise<void>;
  claim(dealId: string): Promise<boolean>;
  persistAndComplete(dealId: string, data: DeepAnalysisPersistenceData): Promise<boolean>;
  fail(dealId: string, code: AnalysisErrorCode): Promise<void>;
};

export type DeepAnalysisResult =
  | { status: "completed"; fresh: false }
  | { status: "completed"; fresh: true; usage: SafeAnalysisUsage }
  | { status: "processing" }
  | { status: "quota_exceeded" }
  | { status: "not_found" }
  | { status: "failed"; code: AnalysisErrorCode };

function trustedSource(deal: SourceDealRow) {
  return {
    dealValue: String(deal.deal_value),
    quoteDate: deal.quote_date,
    serviceType: deal.service_type,
    status: deal.status,
    salesNotes: deal.sales_notes,
    transcript: deal.transcript,
  };
}

export function toDeepPersistenceData(result: CompletedDeepDealAnalysis): DeepAnalysisPersistenceData {
  const { deep, ...core } = result.analysis;
  return {
    ...core,
    recovery_score: null,
    recovery_priority: null,
    score_explanation: null,
    analysis_mode: "DEEP",
    analysis_schema_version: result.metadata.schema_version,
    deep_analysis: deep,
    deep_analyzed_at: result.metadata.analyzed_at,
    model_metadata: result.metadata,
  };
}

export async function analyzeDeepDealWithStore(
  store: DeepAnalysisStore,
  dealId: string,
  operationId: string,
  rerun: boolean,
  runModel: DeepAnalysisModelRunner,
): Promise<DeepAnalysisResult> {
  const deal = await store.fetch(dealId);
  if (!deal) return { status: "not_found" };

  const existing = await store.inspectExisting(dealId).catch(() => null);
  if (existing?.deepValid && !rerun) {
    if (deal.analysis_status !== "completed" && !await store.repairCompleted(dealId)) {
      return { status: "failed", code: "ANALYSIS_FAILED" };
    }
    if (!existing.scored) await store.scoreCompleted(dealId).catch(() => false);
    return { status: "completed", fresh: false };
  }
  if (deal.analysis_status === "processing") return { status: "processing" };

  try {
    const reservation = await store.reserveUsage(dealId, operationId);
    if (!reservation.allowed) return { status: "quota_exceeded" };
    if (!reservation.isNew) return { status: "processing" };
  } catch {
    return { status: "failed", code: "ANALYSIS_FAILED" };
  }

  let claimed = false;
  try {
    claimed = await store.claim(dealId);
  } catch {
    return { status: "failed", code: "ANALYSIS_FAILED" };
  }
  if (!claimed) {
    const latest = await store.fetch(dealId);
    if (!latest) return { status: "not_found" };
    const stored = await store.inspectExisting(dealId).catch(() => null);
    if (stored?.deepValid && !rerun) return { status: "completed", fresh: false };
    return { status: "processing" };
  }

  let result: CompletedDeepDealAnalysis;
  try {
    result = await analyzeDeepDeal(trustedSource(deal), runModel);
    if (!await store.persistAndComplete(dealId, toDeepPersistenceData(result))) {
      throw new DealAnalysisError("ANALYSIS_FAILED");
    }
  } catch (error) {
    const safeError = toDealAnalysisError(error);
    await store.fail(dealId, safeError.code);
    return { status: "failed", code: safeError.code };
  }

  try {
    await store.commitUsage(dealId, operationId);
  } catch {
    // The validated analysis is already persisted. The reservation remains bounded.
  }
  await store.scoreCompleted(dealId).catch(() => false);

  return {
    status: "completed",
    fresh: true,
    usage: {
      model: result.metadata.model,
      ...(result.metadata.input_tokens !== undefined ? { input_tokens: result.metadata.input_tokens } : {}),
      ...(result.metadata.output_tokens !== undefined ? { output_tokens: result.metadata.output_tokens } : {}),
      ...(result.metadata.total_tokens !== undefined ? { total_tokens: result.metadata.total_tokens } : {}),
    },
  };
}
