import { AI_CONFIG } from "@/lib/ai/config";
import {
  DeepDealAnalysisSchema,
  type DeepAnalysisDetails,
  type DeepAnalysisModelResult,
  type DeepDealAnalysis,
} from "@/lib/ai/deep-analysis-schema";
import {
  enforceFollowUpSafety,
  minimizeDealInput,
  type MinimizedDealInput,
  type TrustedDealSource,
} from "@/lib/ai/analyze-deal";
import type { DealAnalysis } from "@/lib/ai/deal-analysis-schema";
import { DealAnalysisError, toDealAnalysisError } from "@/lib/ai/errors";
import { validateAndGroundEvidence } from "@/lib/ai/validate-evidence";

export type DeepAnalysisModelRunner = (input: MinimizedDealInput) => Promise<DeepAnalysisModelResult>;

export type CompletedDeepDealAnalysis = {
  analysis: DeepDealAnalysis;
  metadata: {
    analysis_mode: "DEEP";
    schema_version: typeof AI_CONFIG.deepSchemaVersion;
    prompt_version: typeof AI_CONFIG.deepPromptVersion;
    model: string;
    response_id: string | null;
    input_tokens?: number;
    output_tokens?: number;
    total_tokens?: number;
    analyzed_at: string;
    source_characters: number;
    source_truncated: false;
  };
};

function coreAnalysis(analysis: DeepDealAnalysis): DealAnalysis {
  return {
    lost_reason: analysis.lost_reason,
    lost_reason_detail: analysis.lost_reason_detail,
    buying_intent_score: analysis.buying_intent_score,
    confidence_score: analysis.confidence_score,
    evidence: analysis.evidence,
    positive_signals: analysis.positive_signals,
    negative_signals: analysis.negative_signals,
    recommended_action: analysis.recommended_action,
    recommended_timing: analysis.recommended_timing,
    recommended_channel: analysis.recommended_channel,
    follow_up_message: analysis.follow_up_message,
  };
}

function normalizedSource(source: TrustedDealSource): string {
  return `${source.salesNotes ?? ""}\n${source.transcript ?? ""}`.toLocaleLowerCase("en-US");
}

function collectStrings(value: unknown, output: string[] = []): string[] {
  if (typeof value === "string") output.push(value);
  else if (Array.isArray(value)) value.forEach((item) => collectStrings(item, output));
  else if (value && typeof value === "object") Object.values(value).forEach((item) => collectStrings(item, output));
  return output;
}

function assertEvidenceIndices(indices: readonly number[], evidenceCount: number): void {
  if (new Set(indices).size !== indices.length || indices.some((index) => index >= evidenceCount)) {
    throw new DealAnalysisError("AI_RESPONSE_INVALID");
  }
}

function assertGroundedDeepDetails(
  deep: DeepAnalysisDetails,
  analysis: DealAnalysis,
  source: TrustedDealSource,
): void {
  if (deep.primary_blocker.reason !== analysis.lost_reason) {
    throw new DealAnalysisError("AI_RESPONSE_INVALID");
  }

  const secondaryReasons = deep.secondary_blockers.map((blocker) => blocker.reason);
  if (
    secondaryReasons.includes(analysis.lost_reason)
    || new Set(secondaryReasons).size !== secondaryReasons.length
  ) throw new DealAnalysisError("AI_RESPONSE_INVALID");

  const objectionReasons = deep.objection_hierarchy.map((objection) => objection.reason);
  if (new Set(objectionReasons).size !== objectionReasons.length) {
    throw new DealAnalysisError("AI_RESPONSE_INVALID");
  }

  const evidenceCollections: readonly (readonly number[])[] = [
    deep.primary_blocker.evidence_indices,
    ...deep.secondary_blockers.map((item) => item.evidence_indices),
    deep.recovery_thesis.evidence_indices,
    deep.customer_readiness.evidence_indices,
    ...deep.objection_hierarchy.map((item) => item.evidence_indices),
    deep.decision_dynamics.evidence_indices,
    deep.timing_interpretation.evidence_indices,
    deep.price_value_interpretation.evidence_indices,
    deep.competitor_dynamics.evidence_indices,
    deep.recovery_strategy.evidence_indices,
    deep.recovery_risk.evidence_indices,
    deep.margin_discount_caution.evidence_indices,
    deep.follow_up_strategy.evidence_indices,
  ];
  evidenceCollections.forEach((indices) => assertEvidenceIndices(indices, analysis.evidence.length));

  const weak = analysis.evidence.length === 0;
  if (weak) {
    const cautiousText = collectStrings(deep).join(" ");
    if (
      analysis.lost_reason !== "OTHER"
      || analysis.confidence_score > 35
      || deep.secondary_blockers.length > 0
      || deep.objection_hierarchy.length > 0
      || !/(insufficient|cannot determine|human review|no supported)/i.test(cautiousText)
    ) throw new DealAnalysisError("AI_RESPONSE_INVALID");
  } else {
    const requiredGrounding = [
      deep.primary_blocker.evidence_indices,
      deep.recovery_thesis.evidence_indices,
      deep.customer_readiness.evidence_indices,
      deep.recovery_strategy.evidence_indices,
      deep.recovery_risk.evidence_indices,
      deep.follow_up_strategy.evidence_indices,
    ];
    if (requiredGrounding.some((indices) => indices.length === 0)) {
      throw new DealAnalysisError("AI_RESPONSE_INVALID");
    }
  }

  if (deep.decision_dynamics.evidence_indices.length === 0) {
    if (deep.decision_dynamics.explanation !== "No supported decision-maker issue identified.") {
      throw new DealAnalysisError("AI_RESPONSE_INVALID");
    }
  }
  if (
    (deep.timing_interpretation.category === "INSUFFICIENT_EVIDENCE")
      !== (deep.timing_interpretation.evidence_indices.length === 0)
  ) throw new DealAnalysisError("AI_RESPONSE_INVALID");
  if (
    (deep.price_value_interpretation.category === "INSUFFICIENT_EVIDENCE")
      !== (deep.price_value_interpretation.evidence_indices.length === 0)
  ) throw new DealAnalysisError("AI_RESPONSE_INVALID");
  if (
    (deep.competitor_dynamics.category === "NO_MEANINGFUL_EVIDENCE")
      !== (deep.competitor_dynamics.evidence_indices.length === 0)
  ) throw new DealAnalysisError("AI_RESPONSE_INVALID");
  if (
    (deep.margin_discount_caution.assessment === "UNSUPPORTED_BY_EVIDENCE")
      !== (deep.margin_discount_caution.evidence_indices.length === 0)
  ) throw new DealAnalysisError("AI_RESPONSE_INVALID");

  const sourceText = normalizedSource(source);
  const deepText = collectStrings(deep).join(" ");
  for (const unsupportedPsychology of ["secretly", "hidden motivation", "was lying", "lied about"]) {
    if (deepText.toLocaleLowerCase("en-US").includes(unsupportedPsychology) && !sourceText.includes(unsupportedPsychology)) {
      throw new DealAnalysisError("AI_RESPONSE_INVALID");
    }
  }
  for (const numericClaim of deepText.match(/(?:\$\s?\d[\d,.]*|\b\d+(?:\.\d+)?%)/g) ?? []) {
    if (!sourceText.includes(numericClaim.toLocaleLowerCase("en-US"))) {
      throw new DealAnalysisError("AI_RESPONSE_INVALID");
    }
  }
}

export async function analyzeDeepDeal(
  source: TrustedDealSource,
  runModel: DeepAnalysisModelRunner,
): Promise<CompletedDeepDealAnalysis> {
  const sourceCharacters = (source.salesNotes?.trim().length ?? 0) + (source.transcript?.trim().length ?? 0);
  if (sourceCharacters > AI_CONFIG.deepSourceCharacterLimit) {
    throw new DealAnalysisError("SOURCE_TOO_LONG");
  }
  const minimized = minimizeDealInput(source, AI_CONFIG.deepSourceCharacterLimit);
  let attempts = 0;

  while (true) {
    try {
      const modelResult = await runModel(minimized.input);
      const parsed = DeepDealAnalysisSchema.safeParse(modelResult.analysis);
      if (!parsed.success) throw new DealAnalysisError("AI_RESPONSE_INVALID");

      const proposedCore = coreAnalysis(parsed.data);
      const groundedCore = validateAndGroundEvidence(proposedCore, {
        salesNotes: minimized.input.sales_notes,
        transcript: minimized.input.transcript,
      });
      if (groundedCore.evidence.length !== proposedCore.evidence.length) {
        throw new DealAnalysisError("AI_RESPONSE_INVALID");
      }
      const safeCore = enforceFollowUpSafety(groundedCore, source);
      assertGroundedDeepDetails(parsed.data.deep, safeCore, source);

      const analyzedAt = new Date().toISOString();
      return {
        analysis: { ...safeCore, deep: parsed.data.deep },
        metadata: {
          analysis_mode: "DEEP",
          schema_version: AI_CONFIG.deepSchemaVersion,
          prompt_version: AI_CONFIG.deepPromptVersion,
          model: modelResult.model,
          response_id: modelResult.responseId,
          ...(modelResult.usage ? {
            input_tokens: modelResult.usage.inputTokens,
            output_tokens: modelResult.usage.outputTokens,
            total_tokens: modelResult.usage.totalTokens,
          } : {}),
          analyzed_at: analyzedAt,
          source_characters: minimized.sourceCharacters,
          source_truncated: false,
        },
      };
    } catch (error) {
      const safeError = toDealAnalysisError(error);
      if (!safeError.retryable || attempts >= AI_CONFIG.maxAutomaticRetries) throw safeError;
      attempts += 1;
    }
  }
}
