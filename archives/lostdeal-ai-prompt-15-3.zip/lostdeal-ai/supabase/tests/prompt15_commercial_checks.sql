-- Read-only catalog checks for the current Prompt 15 commercial foundation.
-- Run after the Prompt 15, Prompt 15.1, Prompt 15.2, and Prompt 15.3 migrations.

select to_regclass('public.organization_subscriptions') is not null as subscriptions_present;
select to_regclass('public.organization_usage_events') is not null as usage_events_present;

select relname, relrowsecurity as rls_enabled
from pg_class
where oid in (
  'public.organization_subscriptions'::regclass,
  'public.organization_usage_events'::regclass
)
order by relname;

select policyname, tablename, cmd, roles
from pg_policies
where schemaname = 'public'
  and tablename in ('organization_subscriptions', 'organization_usage_events')
order by tablename, policyname;

select grantee, table_name, privilege_type
from information_schema.role_table_grants
where table_schema = 'public'
  and table_name in ('organization_subscriptions', 'organization_usage_events')
  and privilege_type in ('INSERT', 'UPDATE', 'DELETE', 'TRUNCATE', 'TRIGGER')
order by table_name, grantee, privilege_type;

select
  has_function_privilege('anon', 'public.reserve_organization_usage(text,uuid,text,integer,text)', 'execute') as anon_can_reserve,
  has_function_privilege('authenticated', 'public.reserve_organization_usage(text,uuid,text,integer,text)', 'execute') as authenticated_can_reserve,
  has_function_privilege('anon', 'public.commit_organization_usage(text,uuid,text,text,uuid,integer)', 'execute') as anon_can_commit,
  has_function_privilege('authenticated', 'public.commit_organization_usage(text,uuid,text,text,uuid,integer)', 'execute') as authenticated_can_commit,
  has_function_privilege('anon', 'public.get_organization_usage(uuid)', 'execute') as anon_can_read_usage,
  has_function_privilege('authenticated', 'public.get_organization_usage(uuid)', 'execute') as authenticated_can_read_usage;

select
  count(*) filter (where subscription.plan_code = 'INTERNAL') as internal_organizations,
  count(*) as subscribed_organizations,
  (select count(*) from public.organizations) as organizations
from public.organization_subscriptions as subscription;

select
  private.plan_usage_limit('TRIAL', 'IMPORTED_DEALS') = 50 as trial_import_limit,
  private.plan_usage_limit('TRIAL', 'AI_ANALYSES') = 10 as trial_analysis_limit,
  private.plan_usage_limit('TRIAL', 'AI_MAPPING_REQUESTS') = 3 as trial_mapping_limit,
  private.plan_usage_limit('TRIAL', 'AUTO_CONVERT_ROWS') = 25 as trial_auto_convert_limit,
  private.plan_usage_limit('STARTER', 'IMPORTED_DEALS') = 250 as starter_import_limit,
  private.plan_usage_limit('STARTER', 'AI_ANALYSES') = 30 as starter_analysis_limit,
  private.plan_usage_limit('STARTER', 'AI_MAPPING_REQUESTS') = 3 as starter_mapping_limit,
  private.plan_usage_limit('STARTER', 'AUTO_CONVERT_ROWS') = 0 as starter_auto_convert_limit,
  private.plan_usage_limit('PRO', 'IMPORTED_DEALS') = 1500 as pro_import_limit,
  private.plan_usage_limit('PRO', 'AI_ANALYSES') = 250 as pro_analysis_limit,
  private.plan_usage_limit('PRO', 'AI_MAPPING_REQUESTS') = 30 as pro_mapping_limit,
  private.plan_usage_limit('PRO', 'AUTO_CONVERT_ROWS') = 1500 as pro_auto_convert_limit,
  private.plan_usage_limit('BUSINESS', 'AI_ANALYSES') = -1 as business_inactive,
  private.plan_usage_limit('BUSINESS', 'AUTO_CONVERT_ROWS') = -1 as business_auto_convert_inactive,
  private.plan_usage_limit('INTERNAL', 'AI_ANALYSES') is null as internal_unlimited,
  private.plan_usage_limit('INTERNAL', 'AUTO_CONVERT_ROWS') is null as internal_auto_convert_unlimited;

select
  exists (
    select 1 from information_schema.columns
    where table_schema = 'public' and table_name = 'deals'
      and column_name = 'requested_analysis_mode' and is_nullable = 'NO'
  ) as requested_analysis_mode_present,
  (
    select count(*) = 4
    from information_schema.columns
    where table_schema = 'public' and table_name = 'deal_analyses'
      and column_name in ('analysis_mode', 'analysis_schema_version', 'deep_analysis', 'deep_analyzed_at')
  ) as deep_analysis_columns_present;

select
  count(*) filter (where conname = 'deals_requested_analysis_mode_valid') = 1 as requested_mode_constraint_present,
  count(*) filter (where conname = 'deal_analyses_analysis_mode_valid') = 1 as analysis_mode_constraint_present,
  count(*) filter (where conname = 'deal_analyses_schema_version_bounded') = 1 as schema_version_constraint_present,
  count(*) filter (where conname = 'deal_analyses_deep_analysis_object') = 1 as deep_object_constraint_present,
  count(*) filter (where conname = 'deal_analyses_deep_timestamp_consistent') = 1 as deep_timestamp_constraint_present,
  count(*) filter (where conname = 'deal_analyses_deep_mode_complete') = 1 as deep_mode_constraint_present
from pg_constraint
where conrelid in ('public.deals'::regclass, 'public.deal_analyses'::regclass);

select
  has_column_privilege('authenticated', 'public.deals', 'requested_analysis_mode', 'update') as authenticated_can_update_requested_mode,
  has_column_privilege('authenticated', 'public.deal_analyses', 'analysis_mode', 'insert,update') as authenticated_can_write_analysis_mode,
  has_column_privilege('authenticated', 'public.deal_analyses', 'analysis_schema_version', 'insert,update') as authenticated_can_write_schema_version,
  has_column_privilege('authenticated', 'public.deal_analyses', 'deep_analysis', 'insert,update') as authenticated_can_write_deep_analysis,
  has_column_privilege('authenticated', 'public.deal_analyses', 'deep_analyzed_at', 'insert,update') as authenticated_can_write_deep_timestamp;

select
  position('target_metric = ''AI_ANALYSES''' in pg_get_functiondef(
    'public.reserve_organization_usage(text,uuid,text,integer,text)'::regprocedure
  )) > 0 as deep_uses_ai_analyses,
  position('idempotency_key like ''deep-analysis:%''' in pg_get_functiondef(
    'public.reserve_organization_usage(text,uuid,text,integer,text)'::regprocedure
  )) > 0 as deep_prefix_checked,
  position('deep_committed_total + deep_reserved_total + target_units <= 2' in pg_get_functiondef(
    'public.reserve_organization_usage(text,uuid,text,integer,text)'::regprocedure
  )) > 0 as trial_two_deep_limit_present;
