# LostDeal AI billing and entitlement architecture

Prompt 15 creates the commercial foundation only. There is no payment SDK, checkout, payment webhook, live provider secret, card storage, or paid-plan activation.

## Future Prompt 16 source-of-truth flow

```text
CUSTOMER
  → PROVIDER CHECKOUT
  → PAYMENT PROVIDER
  → VERIFIED IDEMPOTENT WEBHOOK
  → LOSTDEAL SUBSCRIPTION STATE
  → TYPED ENTITLEMENTS
  → SERVER USAGE RESERVATION / ENFORCEMENT
```

- The provider is authoritative about payment and external subscription lifecycle.
- LostDeal AI maps verified provider state into its smaller internal status model: `trialing`, `active`, `past_due`, `canceled`, or `incomplete`.
- `organization_subscriptions` is the application's server-readable internal subscription state. The frontend is never authoritative.
- A successful checkout redirect alone must never grant paid access. Only a verified provider API result/webhook may synchronize paid state.
- Provider event IDs must be persisted or otherwise atomically deduplicated before effects are applied. Replays must produce the same internal result without duplicate plan changes or usage resets.
- Webhook signatures must be verified against the raw request body with a server-only secret, within the provider's accepted time window. Invalid events fail before database mutation.
- Provider customer/subscription IDs are nullable before integration, unique where present, and excluded from normal client-select grants.
- LostDeal AI stores no card number, CVV, or raw payment credential. Checkout and payment-method updates remain provider-hosted.

## Prompt 15 subscription and plan state

- Plan codes: `INTERNAL`, `TRIAL`, `STARTER`, `PRO`, `BUSINESS`.
- `INTERNAL` is hidden, not purchasable, and bypasses commercial quota denial while still permitting diagnostics.
- Existing organizations are backfilled to `INTERNAL`; a database trigger creates a 14-day `TRIAL` row for future organizations. Prompt 15 runtime mode is `SHADOW`, so this cannot unexpectedly lock current users before checkout exists.
- The typed catalog in `lib/billing/plans.ts` is the application-side entitlement contract. PostgreSQL's private limit function mirrors only the three numeric usage limits; tests compare the two definitions.
- Clients have read-only, organization-scoped access to approved subscription columns. A tenant-authorized aggregate RPC returns exactly three committed usage totals; raw usage events, idempotency keys, and reservation tokens have no client table grant. Clients receive no DML table grants and cannot set plans, statuses, periods, trials, provider IDs, or usage.
- Reservation and commit RPCs require both verified tenant membership and a 256-bit server-only usage-authority secret. The migration contains only its SHA-256 verifier. The authenticated browser role can see the RPC signature but cannot create or commit usage without the server secret; this prevents usage forgery and quota self-denial through direct Data API calls.
- No `service_role` secret is added to normal application runtime.

## Usage model

`organization_usage_events` stores organization-scoped reservations and committed usage for:

- `IMPORTED_DEALS`: committed as the number of rows actually inserted, including successful rows before a later nontransactional batch failure.
- `AI_ANALYSES`: one unit for a fresh explicit provider-backed analysis that is validated and persisted.
- `AI_MAPPING_REQUESTS`: one unit for a fresh explicit provider-backed mapping response that passes validation.

Deterministic/manual mapping, CSV validation/normalization/download, Recovery Score, page loads, themes, and outreach consume no usage.

Server-side `reserve_organization_usage` verifies the usage authority and membership, resolves the authoritative period/plan, takes an organization+metric advisory transaction lock, expires old reservations, deduplicates the idempotency key, and atomically compares committed plus active reserved units against the limit. New reservations expire after 15 minutes. Only a newly created reservation returns its random token.

`commit_organization_usage` requires the organization, metric, idempotency key, and unexposed random reservation token. It may commit no more units than reserved. There is deliberately no client refund/release operation. A provider/system failure leaves the reservation uncommitted; it stops reducing available allowance after 15 minutes. A successful operation commits once. Duplicate completed analyses reuse persisted data before reservation, provider call, or usage.

## Enforcement modes

- `OFF`: no database metering requirement; actions remain allowed.
- `SHADOW` (Prompt 15 deployment): reserve and commit when schema is available, calculate would-deny decisions, but do not block normal behavior if the commercial schema is missing or a quota would be exceeded.
- `ENFORCED`: database unavailability or quota denial fails closed before an expensive provider call.

`BILLING_ENFORCEMENT_MODE` and `BILLING_USAGE_AUTHORITY_SECRET` are server-only environment variables. The browser cannot select or override them. The authority secret must remain synchronized with the verifier in the migration and must never be rotated independently; future rotation requires a reviewed forward migration and coordinated environment cutover. Prompt 16 must not enable `ENFORCED` until the migration, subscription synchronization, checkout, webhook handling, upgrade path, customer messaging, and owner billing QA are complete.

## Prompt 16 checklist

1. Confirm seller legal identity/entity and provider approval.
2. Confirm prices, products, quotas, trial, refund/cancellation policy, and tax/accounting approach.
3. Add provider SDK only if required; prefer direct signed server integration where supported.
4. Add checkout creation behind authenticated organization authorization, same-origin validation, and D1 throttling.
5. Add raw-body signature verification, provider-event idempotency, replay tests, and safe status mapping.
6. Add hosted billing portal and cancellation/upgrade flows.
7. Apply production migrations before dependent runtime deployment.
8. Test failed payments, refunds, cancellation timing, upgrades/downgrades, portal access, invoices, retries, and cross-tenant isolation.
