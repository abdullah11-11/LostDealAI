# LostDeal AI commercial launch gap register

Updated: **2026-09-01**
States: `DONE`, `PENDING`, `OWNER DECISION REQUIRED`, `POST-V1`.

LostDeal AI is **not commercially launch-ready** while any required item below remains `PENDING` or `OWNER DECISION REQUIRED`.

## Core Product

| Item | State | Evidence / next step |
|---|---|---|
| Prompt 14 automated QA | DONE | 185 automated checks passed at the Prompt 14 checkpoint |
| Owner live QA | DONE | Owner approved core V1 live behavior before Prompt 15 |
| Frozen V1 features preserved | DONE | Prompt 15 adds commercial/account foundation only |

## Monetization

| Item | State | Evidence / next step |
|---|---|---|
| Typed plan architecture and entitlements | DONE | INTERNAL/TRIAL/STARTER/PRO/BUSINESS in `lib/billing/plans.ts` |
| Organization subscription/usage schema source | DONE | Prompt 15 forward migration exists with RLS and server RPCs |
| Apply Prompt 15 production migration | PENDING | Owner must apply `20260901000000_prompt15_commercial_foundation.sql` and run its checks |
| Usage reservations, idempotency, concurrency | DONE | Atomic Postgres reservation/commit contract; application integrations and tests |
| Pricing and quotas | OWNER DECISION REQUIRED | Review `PRICING_RECOMMENDATION.md`; Option B recommended |
| Trial model | OWNER DECISION REQUIRED | Approve 14 days + 50 imports + 10 analyses + 3 AI mappings |
| Payment provider selection and seller eligibility | OWNER DECISION REQUIRED | Confirm seller entity fact and secure provider approval |
| Checkout | PENDING | Prompt 16 after approval |
| Subscription synchronization | PENDING | Prompt 16 verified provider webhooks |
| Webhook signature and replay protection | PENDING | Prompt 16 |
| Failed-payment/dunning behavior | PENDING | Configure and test chosen provider |
| Cancellation and refund behavior | PENDING | Approve policy and implement provider flow |
| Upgrade/downgrade | PENDING | Prompt 16 |
| Billing portal and invoices | PENDING | Prompt 16 provider portal |
| Tax/VAT/invoicing strategy | OWNER DECISION REQUIRED | MoR recommended; confirm accounting/legal treatment |

## Account

| Item | State | Evidence / next step |
|---|---|---|
| Forgot/reset password code | DONE | Enumeration-safe Supabase recovery with D1 limit and recovery-session marker |
| Production reset email delivery | PENDING | Configure custom SMTP, redirects, templates, SPF/DKIM/DMARC; owner live test |
| Production email confirmation | PENDING | Same production SMTP/domain requirement |
| Workspace/account deletion | PENDING | Define retention/cascade/legal policy and implement |
| Data export | POST-V1 | Current per-upload normalized CSV exists; full account export is separate |

## Production

| Item | State | Evidence / next step |
|---|---|---|
| Custom domain | PENDING | Select and configure domain/TLS |
| Supabase production redirect URLs | PENDING | Add final domain callback and password-recovery URLs |
| Monitoring and structured error alerts | PENDING | Select service and test alerts without sensitive payloads |
| Uptime checks | PENDING | Add checks for public, auth, and critical runtime health |
| OpenAI budget alerts | PENDING | Configure provider budget/usage alerts |
| Database backup/restore procedure | PENDING | Document retention and execute a restore drill |
| Support contact/process | PENDING | Publish customer-facing channel and response expectations |
| Product analytics | OWNER DECISION REQUIRED | Choose privacy-respecting events and consent posture |

## Legal

| Item | State | Evidence / next step |
|---|---|---|
| Seller legal identity/entity | OWNER DECISION REQUIRED | Confirm individual/sole trader versus incorporated entity and jurisdiction |
| Privacy Policy | PENDING | Legal review for CSV/transcript, Supabase, OpenAI, provider, retention, and rights |
| Terms of Service | PENDING | Legal review before accepting payment |
| Cancellation/refund policy | PENDING | Align owner decision, consumer/business rules, and provider configuration |
| Data-processing/subprocessor disclosures | PENDING | Document Supabase, OpenAI, hosting, email, payment provider |

## Final Commercial QA

| Item | State | Evidence / next step |
|---|---|---|
| Prompt 15 commercial foundation QA | DONE | Source tests, build, audits, and scans recorded in release report |
| Billing sandbox QA | PENDING | Prompt 16 checkout/webhook/lifecycle matrix |
| Production SMTP recovery test | PENDING | Owner receives and uses real reset email |
| Production migration/RLS verification | PENDING | Run catalog checks and two-tenant authenticated test after apply |
| Commercial production smoke test | PENDING | Final domain, legal, checkout, billing, email, monitoring |
| Final release archive | PENDING | Create after commercial QA, separate from Prompt 15 source backup |

## Post-V1 roadmap boundaries

CRM integrations, continuous sync, scheduled reports, automatic outreach, advanced exports, additional AI enrichment, and multi-workspace/member-seat product expansion are `POST-V1`. They must not be sold as current capabilities.
