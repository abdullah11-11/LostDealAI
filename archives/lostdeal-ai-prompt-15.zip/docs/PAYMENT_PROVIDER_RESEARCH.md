# LostDeal AI payment-provider research

Research date: **2026-09-01**
Scope: international recurring SaaS sales where the founder/business may currently operate from Pakistan. Only official provider sources were used. Country-level support never guarantees account approval; the provider must complete its own KYC/KYB, product, risk, and payout review.

## Executive recommendation

**Best choice: Lemon Squeezy, subject to owner identity/entity confirmation and provider approval.** Its official supported-countries page explicitly lists Pakistan for bank payouts; it operates as Merchant of Record (MoR), supports subscriptions, webhooks, a customer portal, tax collection/remittance, and recovery/dunning. This produces the clearest country-level path while keeping early international tax operations manageable.

**Second choice: Paddle, subject to the same verification.** Paddle is also a mature SaaS MoR. Its official country policy says software businesses can use Paddle except in its named unsupported countries, and Pakistan is not on that list. Its verification documentation explicitly distinguishes individuals/sole traders from incorporated businesses. Final onboarding and payout approval are still not guaranteed.

**Owner decision required:** confirm the one legal fact that changes onboarding: **will the seller be Abdullah Waheed as a Pakistan-based individual/sole trader, or an incorporated entity—and, if incorporated, what country and entity type?** Do not begin provider integration until that is confirmed and the chosen provider approves the account.

## Comparison

| Criterion | Lemon Squeezy | Paddle | Stripe | PayPro Global |
|---|---|---|---|---|
| Pakistan / seller eligibility | Pakistan is explicitly listed for bank payouts; seller still undergoes store activation and identity/business review | Pakistan is not on the unsupported-country list; individuals/sole traders and companies follow different verification paths | Pakistan is not listed as a supported merchant country; a genuine supported-country entity/bank setup would be required | Global MoR positioning, but Pakistan and entity eligibility are not stated precisely enough in public docs; sales confirmation required |
| International cards | Supported through hosted checkout, subject to product/country restrictions | Supported through Paddle checkout | Supported for an eligible Stripe merchant | Supported through hosted/embedded commerce services |
| Recurring subscriptions | Yes | Yes | Yes, with Stripe Billing | Yes |
| Checkout | Hosted storefront/checkout | Hosted or integrated checkout | Hosted Checkout and APIs | Hosted/embedded checkout options |
| Webhooks | Subscription, order, and payment events | Subscription lifecycle events; provider recommends webhooks for provisioning | Mature event/webhook platform | Webhooks/IPN and REST APIs |
| Customer portal | Hosted portal for subscriptions and billing | Hosted portal with invoices, payment updates, and cancellation | Stripe-hosted customer portal | Subscription-management capabilities; implementation details require plan/sales validation |
| Failed payments | Recovery/dunning included | Revenue recovery/dunning included | Billing retries/dunning available | Subscription recovery tools promoted |
| Tax / VAT | MoR calculates, collects, files, and remits transaction taxes | MoR handles sales-tax/VAT transaction obligations | Stripe Tax is tooling, not MoR; merchant retains registrations/remittance/filings | MoR handles transaction tax/compliance |
| Public fee | Generally 5% + $0.50 per transaction; additional cases should be confirmed during onboarding | 5% + $0.50 per checkout transaction | Processor fees vary by merchant country; Stripe Billing pay-as-you-go is separately 0.7% of Billing volume | No simple public numeric fee; quote required |
| Payout | Pakistan bank payout is listed; USD payout and local-bank conversion rules apply; threshold/schedule documented | Payout eligibility/method is subject to onboarding and account settings | Requires eligible supported-country merchant/bank setup | Global payout promoted; exact Pakistan method/currency must be confirmed by sales |
| Operational burden | Low-to-moderate; MoR handles transaction tax, invoices, and much payment compliance | Low-to-moderate; MoR handles transaction tax and subscription operations | Highest: LostDeal AI would be merchant and own more tax, filing, invoice, dispute, and entity operations | Low-to-moderate after onboarding, but commercial terms/integration certainty are lower |
| Primary risk | Store/KYC approval and final payout terms | Verification/approval and country/entity review | Direct Pakistan merchant ineligible; supported-entity route must be real, not nominal | Eligibility, fees, and support experience are opaque until sales engagement |

## Merchant of Record recommendation

Use a Merchant of Record for the first commercial version unless the owner already has a verified supported-country company and an accounting/tax operating plan that makes a processor materially better. A payment processor moves money and provides billing tools, but LostDeal AI remains the seller responsible for registrations, tax determination/remittance, compliant invoices, refunds, and related operations. An MoR becomes the transaction seller and takes on much of sales-tax/VAT calculation, collection, remittance, invoicing, and payment compliance.

An MoR does **not** remove all LostDeal AI obligations. The owner still needs valid seller identity/entity information, product compliance, privacy and terms, income-tax/accounting treatment, customer support, contract obligations, data protection, and provider-policy compliance.

## Providers not recommended for Prompt 16 primary integration

- **Stripe direct from Pakistan:** not recommended because Pakistan is absent from Stripe's supported merchant-country list. Reconsider only after confirming a genuine incorporated entity, bank account, and operations in a supported country. Stripe Atlas is a company-formation route, not evidence that the owner's present business is eligible.
- **PayPro Global as first choice:** credible MoR and reasonable fallback, but public documentation does not provide enough precise Pakistan/entity eligibility or numeric pricing to select it ahead of Lemon Squeezy/Paddle without a sales process.

## Official sources

### Lemon Squeezy

- Supported countries and Pakistan payout listing: https://docs.lemonsqueezy.com/help/getting-started/supported-countries
- Store activation / review: https://docs.lemonsqueezy.com/help/getting-started/activate-your-store
- Identity verification: https://docs.lemonsqueezy.com/help/getting-started/verify-your-identity
- Getting paid: https://docs.lemonsqueezy.com/help/getting-started/getting-paid
- Tax forms / non-US sellers: https://docs.lemonsqueezy.com/help/tax-forms
- Merchant of Record: https://docs.lemonsqueezy.com/help/payments/merchant-of-record
- Sales tax and VAT: https://docs.lemonsqueezy.com/help/payments/sales-tax-vat
- Recovery/dunning: https://docs.lemonsqueezy.com/help/online-store/recovery-dunning
- Customer portal: https://docs.lemonsqueezy.com/help/online-store/customer-portal
- Webhook events: https://docs.lemonsqueezy.com/help/webhooks/event-types
- SaaS billing fee statement: https://www.lemonsqueezy.com/blog/saas-billing-software

### Paddle

- Supported/unsupported countries: https://www.paddle.com/help/start/intro-to-paddle/which-countries-are-supported-by-paddle
- Business verification and individual/sole-trader distinction: https://www.paddle.com/help/start/account-verification/what-is-business-verification
- Identity verification: https://www.paddle.com/help/start/account-verification/what-is-identity-verification
- Pricing: https://www.paddle.com/pricing
- Webhook-based provisioning: https://developer.paddle.com/build/subscriptions/provision-access-webhooks
- Customer portal: https://developer.paddle.com/concepts/sell/customer-portal

### Stripe

- Supported merchant countries: https://stripe.com/global
- Stripe Billing pricing: https://stripe.com/billing/pricing
- Customer portal integration: https://docs.stripe.com/customer-management/integrate-customer-portal
- Stripe Tax pricing and merchant responsibilities: https://stripe.com/tax/pricing

### PayPro Global

- Merchant of Record overview: https://payproglobal.com/products/merchant-of-record/
- Developer documentation: https://developers.payproglobal.com/
- Subscription management: https://developers.payproglobal.com/docs/subscriptions/subscription-management/
