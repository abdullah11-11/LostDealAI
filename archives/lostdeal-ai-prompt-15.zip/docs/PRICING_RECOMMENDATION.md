# LostDeal AI V1 pricing recommendation

Research and recommendation date: **2026-09-01**

These are internal decision options, not published prices. LostDeal AI currently has no checkout, paid subscription, or public pricing commitment. Final pricing requires owner approval.

## Packaging principles

- Charge for the current V1 value: lost-deal analysis, Recovery Score prioritization, Smart Import, AI Smart Mapping, Recovery Overview, Deal Intelligence, and follow-up recommendations.
- Keep the three cost-bearing allowances easy to understand: successfully imported deals, explicit AI analyses, and explicit AI Smart Mapping requests.
- Include deterministic mapping, manual mapping, normalized CSV export, Recovery Score, dashboards, and Deal Intelligence in every plan. These actions do not consume AI allowance.
- Do not market CRM integrations, continuous synchronization, automated weekly reports, or other future features as available.
- V1 supports one organization workspace and the current owner-led access model. Multi-workspace and sellable member-seat packaging are not current product capabilities.

## Shared trial proposal

All options use the same **14-day hybrid trial**: 50 imported deals, 10 AI analyses, and 3 AI Smart Mapping requests; one authenticated organization; no payment method initially required. The trial ends at the earlier of its time boundary or an enforced allowance boundary once commercial enforcement is enabled. No anonymous AI access is offered.

## Option A — Conservative

Lower launch friction, with tighter allowances and less room for high-volume evaluation.

| Plan | Monthly | Annual strategy | Imported deals | AI analyses | AI mapping | Organization | Positioning |
|---|---:|---|---:|---:|---:|---:|---|
| Trial | $0 | 14 days only | 50 | 10 | 3 | 1 | Product evaluation |
| Starter | $29 | Consider $290/year after evidence | 250 | 50 | 5 | 1 | Small owner-led teams |
| Pro | $79 | Consider $790/year after evidence | 1,000 | 250 | 20 | 1 | Regular recovery workflow |
| Business | $159 | Consider $1,590/year after evidence | 5,000 | 1,000 | 75 | 1 | High-volume current V1 usage |

Trade-off: easiest entry price, but the smaller Pro allowance may create more upgrade friction and the Business price leaves less support margin.

## Option B — Recommended

Best balance of early adoption, simple value-based packaging, and margin headroom. These allowances are the Prompt 15 entitlement catalog.

| Plan | Monthly | Annual strategy | Imported deals | AI analyses | AI mapping | Organization | Positioning |
|---|---:|---|---:|---:|---:|---:|---|
| Trial | $0 | 14 days only | 50 | 10 | 3 | 1 | Bounded evaluation |
| Starter | $39 | Consider $390/year after evidence | 500 | 100 | 10 | 1 | Owner-led recovery workflow |
| Pro | $99 | Consider $990/year after evidence | 2,000 | 500 | 40 | 1 | Primary plan for consistent teams |
| Business | $199 | Consider $1,990/year after evidence | 10,000 | 2,000 | 150 | 1 | Larger current-V1 workloads and priority support potential |

Why recommended: the prices are still approachable relative to the value of one recovered service-business deal, while the bounded provider-backed actions preserve healthy cost headroom. The plan names and limits stay understandable without artificial feature gating.

## Option C — Higher-value

Higher willingness-to-pay positioning with larger allowances and more room for hands-on support.

| Plan | Monthly | Annual strategy | Imported deals | AI analyses | AI mapping | Organization | Positioning |
|---|---:|---|---:|---:|---:|---:|---|
| Trial | $0 | 14 days only | 50 | 10 | 3 | 1 | Bounded evaluation |
| Starter | $59 | Consider $590/year after evidence | 750 | 150 | 15 | 1 | Higher-touch small businesses |
| Pro | $149 | Consider $1,490/year after evidence | 3,000 | 750 | 60 | 1 | Revenue-recovery operating system |
| Business | $299 | Consider $2,990/year after evidence | 15,000 | 3,000 | 200 | 1 | High-volume customers with support expectations |

Trade-off: strongest support and cost buffer, but higher acquisition friction before LostDeal AI has established references and quantified retention.

## Recommended annual and overage approach

- Launch monthly billing first. Offer annual billing at approximately 10 months of monthly price only after cancellation and support behavior is understood.
- Use a **hard monthly allowance plus upgrade** in V1. Do not implement per-unit overages, surprise invoices, or complex credits.
- Show Used / Monthly allowance and a clear upgrade path only after checkout exists. During Prompt 15, enforcement remains `SHADOW` and no fake checkout is shown.

## Owner decisions required

Before Prompt 16, approve or revise: Option B prices and allowances, the 14-day hybrid trial, hard allowances plus upgrade, monthly-first billing, and whether a future member-seat capability should change packaging. Nothing in this document is public pricing.
