# LostDeal AI V1 unit economics

Model date: **2026-09-01**
Decision basis: Pricing Option B ($39 Starter, $99 Pro, $199 Business). Values are planning ranges, not accounting forecasts or provider quotes.

## Cost assumptions

- A Prompt 7 live analysis observed 918 input and 263 output tokens (1,181 total) on one synthetic deal. Actual notes/transcript size, retries, model choice, cached input, and future pricing vary.
- Budget **$0.002–$0.020 per successful Deal Analysis** and **$0.001–$0.010 per successful AI Smart Mapping request** until production telemetry establishes better percentiles. This range deliberately exceeds the one observed token shape rather than claiming a fixed per-deal cost.
- Recovery Score, deterministic/manual mapping, normalization, downloads, and page loads make zero OpenAI calls.
- Model payment/MoR fees at **5% + $0.50 per transaction**, consistent with current public Lemon Squeezy/Paddle baseline pricing. Additional cross-border, refund, dispute, or product-specific fees require provider confirmation.
- Allocate hosting/database/monitoring at **$1–$12 per active organization/month** depending on record volume and request intensity. Shared fixed costs and human support are not fully variable costs.

Before Prompt 16, validate the configured OpenAI model's then-current official price and capture real p50/p95 tokens. Official API pricing: https://openai.com/api/pricing/

## Usage scenarios

| Plan | Scenario | Analyses | AI mappings | Estimated AI | Hosting/DB | MoR fee | Approx. variable cost | Approx. gross margin |
|---|---|---:|---:|---:|---:|---:|---:|---:|
| Starter $39 | Light | 10 | 1 | $0.02–$0.21 | $1–$3 | $2.45 | $3.47–$5.66 | 85%–91% |
| Starter $39 | Normal | 50 | 5 | $0.11–$1.05 | $2–$5 | $2.45 | $4.56–$8.50 | 78%–88% |
| Starter $39 | Heavy | 100 | 10 | $0.21–$2.10 | $4–$8 | $2.45 | $6.66–$12.55 | 68%–83% |
| Pro $99 | Light | 50 | 4 | $0.10–$1.04 | $2–$4 | $5.45 | $7.55–$10.49 | 89%–92% |
| Pro $99 | Normal | 250 | 20 | $0.52–$5.20 | $4–$8 | $5.45 | $9.97–$18.65 | 81%–90% |
| Pro $99 | Heavy | 500 | 40 | $1.04–$10.40 | $6–$10 | $5.45 | $12.49–$25.85 | 74%–87% |
| Business $199 | Light | 200 | 15 | $0.42–$4.15 | $3–$6 | $10.45 | $13.87–$20.60 | 90%–93% |
| Business $199 | Normal | 1,000 | 75 | $2.08–$20.75 | $6–$10 | $10.45 | $18.53–$41.20 | 79%–91% |
| Business $199 | Heavy | 2,000 | 150 | $4.15–$41.50 | $8–$12 | $10.45 | $22.60–$63.95 | 68%–89% |

Margin is `(price - modeled variable cost) / price`, rounded. Imported deal storage/query load is represented in the hosting/database range. Taxes on LostDeal AI income, refunds, chargebacks, currency conversion, support labor, acquisition, and fixed software are excluded and must be modeled separately before final pricing.

## Trial exposure

The proposed trial maximum of 10 analyses and 3 mappings has estimated provider cost of roughly **$0.02–$0.23**, plus modest hosting/database use. Authentication, D1 throttling, per-organization quota reservations, and no anonymous AI keep exposure bounded.

## Decision

Option B retains positive contribution margin even at the conservative heavy-use bounds, but these are estimates. Do not make margin guarantees. Before public pricing, validate provider approval/fees, real OpenAI token distributions, hosting data, refund assumptions, support burden, and applicable taxes.
