export const PLAN_CODES = ["INTERNAL", "TRIAL", "STARTER", "PRO", "BUSINESS"] as const;

export type PlanCode = (typeof PLAN_CODES)[number];

export const USAGE_METRICS = [
  "IMPORTED_DEALS",
  "AI_ANALYSES",
  "AI_MAPPING_REQUESTS",
] as const;

export type UsageMetric = (typeof USAGE_METRICS)[number];

export const UNLIMITED = Object.freeze({ kind: "UNLIMITED" } as const);
export type Unlimited = typeof UNLIMITED;
export type UsageLimit = number | Unlimited;

export type PlanEntitlements = Readonly<{
  planCode: PlanCode;
  displayName: string;
  purchasable: boolean;
  usage: Readonly<Record<UsageMetric, UsageLimit>>;
  features: Readonly<{
    smartImport: boolean;
    normalizedCsvExport: boolean;
    dealIntelligence: boolean;
    batchAnalysis: boolean;
  }>;
}>;

const CURRENT_FEATURES = Object.freeze({
  smartImport: true,
  normalizedCsvExport: true,
  dealIntelligence: true,
  batchAnalysis: true,
});

export const PLAN_CATALOG: Readonly<Record<PlanCode, PlanEntitlements>> = Object.freeze({
  INTERNAL: Object.freeze({
    planCode: "INTERNAL",
    displayName: "Owner / Internal",
    purchasable: false,
    usage: Object.freeze({
      IMPORTED_DEALS: UNLIMITED,
      AI_ANALYSES: UNLIMITED,
      AI_MAPPING_REQUESTS: UNLIMITED,
    }),
    features: CURRENT_FEATURES,
  }),
  TRIAL: Object.freeze({
    planCode: "TRIAL",
    displayName: "Trial",
    purchasable: false,
    usage: Object.freeze({
      IMPORTED_DEALS: 50,
      AI_ANALYSES: 10,
      AI_MAPPING_REQUESTS: 3,
    }),
    features: CURRENT_FEATURES,
  }),
  STARTER: Object.freeze({
    planCode: "STARTER",
    displayName: "Starter",
    purchasable: true,
    usage: Object.freeze({
      IMPORTED_DEALS: 500,
      AI_ANALYSES: 100,
      AI_MAPPING_REQUESTS: 10,
    }),
    features: CURRENT_FEATURES,
  }),
  PRO: Object.freeze({
    planCode: "PRO",
    displayName: "Pro",
    purchasable: true,
    usage: Object.freeze({
      IMPORTED_DEALS: 2_000,
      AI_ANALYSES: 500,
      AI_MAPPING_REQUESTS: 40,
    }),
    features: CURRENT_FEATURES,
  }),
  BUSINESS: Object.freeze({
    planCode: "BUSINESS",
    displayName: "Business",
    purchasable: true,
    usage: Object.freeze({
      IMPORTED_DEALS: 10_000,
      AI_ANALYSES: 2_000,
      AI_MAPPING_REQUESTS: 150,
    }),
    features: CURRENT_FEATURES,
  }),
});

export function isPlanCode(value: unknown): value is PlanCode {
  return typeof value === "string" && PLAN_CODES.includes(value as PlanCode);
}

export function isUsageMetric(value: unknown): value is UsageMetric {
  return typeof value === "string" && USAGE_METRICS.includes(value as UsageMetric);
}

export function isUnlimited(limit: UsageLimit): limit is Unlimited {
  return limit === UNLIMITED || (typeof limit === "object" && limit.kind === "UNLIMITED");
}

/** Unknown or database-corrupted plan codes fail closed instead of inheriting access. */
export function getEntitlements(planCode: unknown): PlanEntitlements | null {
  return isPlanCode(planCode) ? PLAN_CATALOG[planCode] : null;
}

export function usageLimitFor(planCode: PlanCode, metric: UsageMetric): UsageLimit {
  return PLAN_CATALOG[planCode].usage[metric];
}
