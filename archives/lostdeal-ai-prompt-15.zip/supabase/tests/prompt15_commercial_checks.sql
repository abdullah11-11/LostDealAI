-- Read-only catalog checks for the Prompt 15 commercial migration.
-- Run after 20260901000000_prompt15_commercial_foundation.sql.

select to_regclass('public.organization_subscriptions') is not null as subscriptions_present;
select to_regclass('public.organization_usage_events') is not null as usage_events_present;

select relname, relrowsecurity as rls_enabled
from pg_class
where oid in (
  'public.organization_subscriptions'::regclass,
  'public.organization_usage_events'::regclass
)
order by relname;

select policyname, tablename, cmd, roles
from pg_policies
where schemaname = 'public'
  and tablename in ('organization_subscriptions', 'organization_usage_events')
order by tablename, policyname;

select grantee, table_name, privilege_type
from information_schema.role_table_grants
where table_schema = 'public'
  and table_name in ('organization_subscriptions', 'organization_usage_events')
  and privilege_type in ('INSERT', 'UPDATE', 'DELETE', 'TRUNCATE', 'TRIGGER')
order by table_name, grantee, privilege_type;

select
  has_function_privilege('anon', 'public.reserve_organization_usage(text,uuid,text,integer,text)', 'execute') as anon_can_reserve,
  has_function_privilege('authenticated', 'public.reserve_organization_usage(text,uuid,text,integer,text)', 'execute') as authenticated_can_reserve,
  has_function_privilege('anon', 'public.commit_organization_usage(text,uuid,text,text,uuid,integer)', 'execute') as anon_can_commit,
  has_function_privilege('authenticated', 'public.commit_organization_usage(text,uuid,text,text,uuid,integer)', 'execute') as authenticated_can_commit,
  has_function_privilege('anon', 'public.get_organization_usage(uuid)', 'execute') as anon_can_read_usage,
  has_function_privilege('authenticated', 'public.get_organization_usage(uuid)', 'execute') as authenticated_can_read_usage;

select
  count(*) filter (where subscription.plan_code = 'INTERNAL') as internal_organizations,
  count(*) as subscribed_organizations,
  (select count(*) from public.organizations) as organizations
from public.organization_subscriptions as subscription;

select
  private.plan_usage_limit('TRIAL', 'AI_ANALYSES') = 10 as trial_analysis_limit,
  private.plan_usage_limit('STARTER', 'IMPORTED_DEALS') = 500 as starter_import_limit,
  private.plan_usage_limit('PRO', 'AI_MAPPING_REQUESTS') = 40 as pro_mapping_limit,
  private.plan_usage_limit('BUSINESS', 'AI_ANALYSES') = 2000 as business_analysis_limit,
  private.plan_usage_limit('INTERNAL', 'AI_ANALYSES') is null as internal_unlimited;
