# LostDeal AI

LostDeal AI helps businesses understand why sales opportunities were lost and
identify which deals may be worth recovering.

This repository currently contains **Prompt 1 only**: the Next.js application
and user-interface foundation. Authentication, organizations, Supabase, CSV
processing, OpenAI analysis, and real dashboard data are intentionally not
implemented yet.

## Stack

- Next.js App Router
- TypeScript in strict mode
- Tailwind CSS
- ESLint
- npm

The OpenAI Sites runtime uses Vinext while preserving the standard App Router
file structure and Next.js APIs.

## Routes

- `/`
- `/login`
- `/signup`
- `/dashboard`
- `/deals`
- `/deals/[id]`
- `/upload`

## Commands

```bash
npm run dev
npm run lint
npm run typecheck
npm run build
```

The authentication, dashboard, deals, deal detail, and upload screens are
visual placeholders only. They do not store data or call external services.
