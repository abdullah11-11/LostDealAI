import type { Metadata } from "next";
import Link from "next/link";
import { ArrowUpRight, Banknote, BriefcaseBusiness, CircleDollarSign, Target } from "lucide-react";
import { PageHeader } from "@/components/page-heading";
import { Badge, Card, StatCard, Table, buttonStyles } from "@/components/ui";
import { demoDeals, reasonBreakdown, type RecoveryPriority } from "@/lib/demo-data";

export const metadata: Metadata = { title: "Dashboard" };

const priorityTone: Record<RecoveryPriority, "high" | "medium" | "low"> = {
  HIGH: "high",
  MEDIUM: "medium",
  LOW: "low",
};

export default function DashboardPage() {
  return (
    <div className="mx-auto max-w-7xl">
      <PageHeader
        eyebrow="Overview"
        title="Recovery dashboard"
        description="A demonstration of how LostDeal AI will surface lost-sales patterns and prioritize the next best recovery conversations."
        action={<Link href="/upload" className={buttonStyles("outline")}>Upload lost deals <ArrowUpRight aria-hidden="true" className="size-4" /></Link>}
      />

      <div className="mt-6 flex items-center gap-3 rounded-xl border border-violet-200 bg-violet-50 px-4 py-3">
        <Badge tone="demo">Demo / Sample Data</Badge>
        <p className="text-xs leading-5 text-violet-800">All metrics and customer names on this page are fictional and shown only to demonstrate the interface.</p>
      </div>

      <section aria-label="Recovery metrics" className="mt-6 grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        <StatCard label="Lost Revenue" value="$487,350" context="Total value across lost opportunities" icon={<CircleDollarSign aria-hidden="true" className="size-5" />} status={<Badge tone="demo">Sample</Badge>} />
        <StatCard label="High Recovery Opportunity" value="$168,400" context="Value currently classified as high priority" icon={<Banknote aria-hidden="true" className="size-5" />} status={<Badge tone="high">High</Badge>} />
        <StatCard label="High Priority Deals" value="23" context="Deals requiring immediate attention" icon={<Target aria-hidden="true" className="size-5" />} status={<Badge tone="high">Review now</Badge>} />
        <StatCard label="Total Lost Deals" value="126" context="Imported lost opportunities" icon={<BriefcaseBusiness aria-hidden="true" className="size-5" />} status={<Badge tone="demo">Sample</Badge>} />
      </section>

      <section className="mt-5 grid gap-5 xl:grid-cols-[1.5fr_0.5fr]">
        <Card
          title="Top Recovery Opportunities"
          description="Fictional deals ranked by their demonstration recovery score."
          action={<Link href="/deals" className="text-sm font-bold text-[#2952cc] hover:underline">View all deals</Link>}
          className="overflow-hidden"
        >
          <Table label="Top recovery opportunities" headers={["Customer", "Deal Value", "Lost Reason", "Recovery Score", "Priority"]}>
            {demoDeals.slice(0, 5).map((deal) => (
              <tr key={deal.id} className="transition-colors hover:bg-slate-50">
                <td className="px-5 py-4"><Link href={`/deals/${deal.id}`} className="font-bold text-slate-900 hover:text-[#2952cc]">{deal.customer}</Link></td>
                <td className="whitespace-nowrap px-5 py-4 text-sm font-semibold text-slate-700">{deal.value}</td>
                <td className="whitespace-nowrap px-5 py-4 text-sm text-slate-600">{deal.lostReason}</td>
                <td className="whitespace-nowrap px-5 py-4"><span className="text-sm font-extrabold text-[#0b1739]">{deal.recoveryScore}/100</span></td>
                <td className="px-5 py-4"><Badge tone={priorityTone[deal.priority]}>{deal.priority}</Badge></td>
              </tr>
            ))}
          </Table>
        </Card>

        <Card title="Why You’re Losing Sales" description="Lost-reason mix · Sample data">
          <div className="space-y-5 p-5 sm:p-6">
            {reasonBreakdown.map(({ reason, percentage }) => (
              <div key={reason}>
                <div className="flex items-center justify-between gap-4 text-xs">
                  <span className="font-semibold text-slate-700">{reason}</span>
                  <span className="font-extrabold text-slate-900">{percentage}%</span>
                </div>
                <div className="mt-2 h-2 overflow-hidden rounded-full bg-slate-100" role="img" aria-label={`${reason}: ${percentage} percent`}>
                  <div className="h-full rounded-full bg-[#2952cc]" style={{ width: `${percentage}%` }} />
                </div>
              </div>
            ))}
          </div>
        </Card>
      </section>
    </div>
  );
}
