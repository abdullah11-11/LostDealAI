import type { Metadata } from "next";
import Link from "next/link";
import { ArrowLeft, CalendarClock, CheckCircle2, Mail, MessageSquareText, MinusCircle, Sparkles } from "lucide-react";
import { Badge, Card } from "@/components/ui";
import { demoDeals } from "@/lib/demo-data";

export const metadata: Metadata = { title: "Sample deal analysis" };

export default async function DealPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const decodedId = decodeURIComponent(id);
  const deal = demoDeals.find((item) => item.id === decodedId) ?? demoDeals[0];

  return (
    <div className="mx-auto max-w-7xl">
      <Link href="/deals" className="inline-flex items-center gap-2 text-sm font-semibold text-slate-500 hover:text-slate-900">
        <ArrowLeft aria-hidden="true" className="size-4" /> Back to lost deals
      </Link>

      <div className="mt-6 flex flex-col gap-5 sm:flex-row sm:items-start sm:justify-between">
        <div>
          <div className="flex flex-wrap items-center gap-2"><Badge tone="demo">Sample Analysis</Badge><Badge tone="high">High Priority</Badge></div>
          <h1 className="mt-4 text-3xl font-semibold tracking-[-0.025em] text-[#0b1739] sm:text-4xl">{deal.customer}</h1>
          <p className="mt-2 text-sm text-slate-500">{deal.service} · {deal.value} · Fictional demonstration record</p>
        </div>
        <div className="rounded-2xl border border-blue-200 bg-blue-50 px-5 py-4 sm:text-right">
          <p className="text-[10px] font-extrabold uppercase tracking-[0.12em] text-blue-700">Recovery Score</p>
          <p className="mt-1 text-3xl font-semibold tracking-tight text-[#0b1739]">91<span className="text-base text-slate-500">/100</span></p>
          <p className="mt-1 text-[11px] text-blue-800">A score, not a conversion probability</p>
        </div>
      </div>

      <div className="mt-6 grid gap-4 sm:grid-cols-3">
        <Summary label="Lost Reason" value="Financing" />
        <Summary label="Recommended Timing" value="Within 7 days" icon={<CalendarClock aria-hidden="true" className="size-4" />} />
        <Summary label="Recommended Channel" value="Email, then phone" icon={<Mail aria-hidden="true" className="size-4" />} />
      </div>

      <div className="mt-5 grid gap-5 xl:grid-cols-[1.15fr_0.85fr]">
        <div className="space-y-5">
          <Card title="Evidence" description="AI INTERPRETATION · Grounded in the fictional source notes below">
            <div className="space-y-3 p-5 sm:p-6">
              <EvidenceItem text="The prospect stated that the project remained important but the initial deposit was difficult to approve this quarter." />
              <EvidenceItem text="They asked whether a phased payment plan could be reviewed after the next budget meeting." />
            </div>
          </Card>

          <div className="grid gap-5 md:grid-cols-2">
            <Card title="Buying Signals" description="AI INTERPRETATION">
              <SignalList positive items={["Requested an updated implementation timeline", "Asked to keep the quoted scope reserved", "Named a date for the next budget review"]} />
            </Card>
            <Card title="Negative Signals" description="AI INTERPRETATION">
              <SignalList items={["Deposit exceeded current-quarter budget", "Finance approval is still outstanding", "No confirmed decision date"]} />
            </Card>
          </div>

          <Card title="Original Sales Notes" description="SOURCE DATA · Fictional demonstration content">
            <div className="p-5 text-sm leading-7 text-slate-700 sm:p-6">
              <p className="rounded-xl border border-slate-200 bg-slate-50 p-4">July 18 — David liked the proposal and asked us to hold the installation window. The upfront deposit is the main blocker. Finance meets again next Thursday. He asked whether we could offer a three-stage payment plan.</p>
            </div>
          </Card>

          <Card title="Original Transcript" description="SOURCE DATA · Fictional demonstration content">
            <div className="space-y-3 p-5 text-sm leading-7 sm:p-6">
              <p><span className="font-bold text-slate-900">Sales:</span> If we adjust the payment schedule, would the project still be a priority this quarter?</p>
              <p><span className="font-bold text-slate-900">Customer:</span> Yes, the scope works. I need the deposit to fit the finance team’s limits, and they review budgets next Thursday.</p>
            </div>
          </Card>
        </div>

        <div className="space-y-5">
          <Card title="Recommended Action" description="AI INTERPRETATION">
            <div className="p-5 sm:p-6">
              <div className="flex size-10 items-center justify-center rounded-xl bg-blue-50 text-[#2952cc]"><Sparkles aria-hidden="true" className="size-5" /></div>
              <p className="mt-4 text-sm font-bold text-slate-900">Offer a structured payment option before the finance review.</p>
              <p className="mt-2 text-sm leading-6 text-slate-600">Send a concise three-stage payment proposal, confirm that scope and pricing remain unchanged, and request a 15-minute call after their budget meeting.</p>
            </div>
          </Card>

          <Card title="Suggested Follow-Up" description="AI INTERPRETATION · Draft only">
            <div className="p-5 sm:p-6">
              <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-[0.1em] text-slate-500"><MessageSquareText aria-hidden="true" className="size-4" /> Email draft</div>
              <div className="mt-4 rounded-xl border border-slate-200 bg-slate-50 p-4 text-sm leading-7 text-slate-700">
                Hi David — thanks again for reviewing the proposal. Based on your finance team’s deposit limits, I prepared a three-stage payment option while keeping the agreed scope unchanged. Would it help if I sent that before Thursday’s budget meeting and checked in afterward?
              </div>
              <button type="button" disabled className="mt-4 text-xs font-bold text-slate-400">Copy message · Available after analysis setup</button>
            </div>
          </Card>

          <div className="rounded-2xl border border-violet-200 bg-violet-50 p-5">
            <Badge tone="demo">Demo distinction</Badge>
            <p className="mt-3 text-sm leading-6 text-violet-900"><strong>SOURCE DATA</strong> is the supplied customer record. <strong>AI INTERPRETATION</strong> is the system’s evidence-grounded analysis. This page uses fictional content for both.</p>
          </div>
        </div>
      </div>
    </div>
  );
}

function Summary({ label, value, icon }: { label: string; value: string; icon?: React.ReactNode }) {
  return (
    <article className="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm">
      <div className="flex items-center gap-2 text-[10px] font-extrabold uppercase tracking-[0.1em] text-slate-500">{icon}{label}</div>
      <p className="mt-3 text-lg font-bold text-slate-900">{value}</p>
    </article>
  );
}

function EvidenceItem({ text }: { text: string }) {
  return <div className="flex gap-3 rounded-xl border border-blue-100 bg-blue-50/60 p-4 text-sm leading-6 text-slate-700"><CheckCircle2 aria-hidden="true" className="mt-0.5 size-4 shrink-0 text-[#2952cc]" />{text}</div>;
}

function SignalList({ items, positive = false }: { items: string[]; positive?: boolean }) {
  return (
    <ul className="space-y-3 p-5 sm:p-6">
      {items.map((item) => (
        <li key={item} className="flex gap-3 text-sm leading-6 text-slate-700">
          {positive ? <CheckCircle2 aria-hidden="true" className="mt-0.5 size-4 shrink-0 text-emerald-600" /> : <MinusCircle aria-hidden="true" className="mt-0.5 size-4 shrink-0 text-amber-600" />}
          {item}
        </li>
      ))}
    </ul>
  );
}
