import type { Metadata } from "next";
import Link from "next/link";
import { ArrowUpRight, Search } from "lucide-react";
import { PageHeader } from "@/components/page-heading";
import { Badge, Input, Select, Table, buttonStyles } from "@/components/ui";
import { demoDeals, type RecoveryPriority } from "@/lib/demo-data";

export const metadata: Metadata = { title: "Lost deals" };

const priorityTone: Record<RecoveryPriority, "high" | "medium" | "low"> = {
  HIGH: "high",
  MEDIUM: "medium",
  LOW: "low",
};

export default function DealsPage() {
  return (
    <div className="mx-auto max-w-7xl">
      <PageHeader
        eyebrow="Pipeline"
        title="Lost deals"
        description="Preview how imported opportunities will be searched, filtered, and prioritized after data functionality is connected."
        action={<Link href="/upload" className={buttonStyles()}>Import lost deals <ArrowUpRight aria-hidden="true" className="size-4" /></Link>}
      />

      <section className="mt-8 overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-sm">
        <div className="flex flex-col gap-4 border-b border-slate-200 p-4 sm:p-5 xl:flex-row xl:items-end xl:justify-between">
          <div className="flex items-center gap-3">
            <Badge tone="demo">Demo Data</Badge>
            <p className="text-xs text-slate-500">Fictional opportunities for interface preview</p>
          </div>
          <div className="grid gap-3 sm:grid-cols-3 xl:w-[46rem]">
            <Input id="deal-search" label="Search" type="search" placeholder="Search customers" disabled description="Available after data setup" className="pl-3" />
            <Select id="priority-filter" label="Priority Filter" disabled defaultValue="all">
              <option value="all">All priorities</option>
            </Select>
            <Select id="reason-filter" label="Lost Reason Filter" disabled defaultValue="all">
              <option value="all">All lost reasons</option>
            </Select>
          </div>
        </div>

        <Table className="min-w-[1020px]" label="Lost deals demo data" headers={["Customer", "Deal Value", "Quote Date", "Service", "Lost Reason", "Recovery Score", "Priority"]}>
          {demoDeals.map((deal) => (
            <tr key={deal.id} className="transition-colors hover:bg-slate-50">
              <td className="px-5 py-4"><Link href={`/deals/${deal.id}`} className="font-bold text-slate-900 hover:text-[#2952cc]">{deal.customer}</Link></td>
              <td className="whitespace-nowrap px-5 py-4 text-sm font-semibold text-slate-700">{deal.value}</td>
              <td className="whitespace-nowrap px-5 py-4 text-sm text-slate-600">{deal.quoteDate}</td>
              <td className="whitespace-nowrap px-5 py-4 text-sm text-slate-600">{deal.service}</td>
              <td className="whitespace-nowrap px-5 py-4 text-sm text-slate-600">{deal.lostReason}</td>
              <td className="whitespace-nowrap px-5 py-4 text-sm font-extrabold text-[#0b1739]">{deal.recoveryScore}/100</td>
              <td className="px-5 py-4"><Badge tone={priorityTone[deal.priority]}>{deal.priority}</Badge></td>
            </tr>
          ))}
        </Table>

        <div className="flex items-center justify-between gap-4 border-t border-slate-100 px-5 py-4 text-xs text-slate-500">
          <p>Showing {demoDeals.length} fictional records</p>
          <span className="flex items-center gap-1.5"><Search aria-hidden="true" className="size-3.5" /> Controls are visual placeholders</span>
        </div>
      </section>
    </div>
  );
}
