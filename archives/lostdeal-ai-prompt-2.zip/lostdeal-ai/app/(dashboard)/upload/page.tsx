import type { Metadata } from "next";
import { CheckCircle2, FileSpreadsheet, Info, UploadCloud } from "lucide-react";
import { PageHeader } from "@/components/page-heading";
import { Badge, Button, Card } from "@/components/ui";

export const metadata: Metadata = { title: "Upload lost deals" };

export default function UploadPage() {
  return (
    <div className="mx-auto max-w-6xl">
      <PageHeader
        eyebrow="Import"
        title="Upload Lost Deals"
        description="Upload your lost opportunities with sales notes or transcripts. The import controls below are a visual preview only."
        action={<Badge tone="pending">Import setup pending</Badge>}
      />

      <section className="mt-8 grid gap-5 lg:grid-cols-[1.4fr_0.6fr]">
        <Card>
          <div className="p-5 sm:p-6">
            <div className="flex min-h-[26rem] flex-col items-center justify-center rounded-2xl border-2 border-dashed border-blue-200 bg-blue-50/50 px-6 text-center">
              <span className="flex size-16 items-center justify-center rounded-2xl bg-white text-[#2952cc] shadow-sm"><UploadCloud aria-hidden="true" className="size-7" /></span>
              <h2 className="mt-6 text-xl font-bold text-slate-950">Drag and drop your lost-deals CSV</h2>
              <p className="mt-2 max-w-md text-sm leading-6 text-slate-600">Bring opportunity details together with the sales notes or transcripts that explain what happened.</p>
              <Button type="button" disabled className="mt-6">Choose a CSV file</Button>
              <div className="mt-5 flex flex-wrap justify-center gap-2">
                <Badge tone="neutral">Accepted format: CSV</Badge>
                <Badge tone="pending">Upload disabled in Prompt 2</Badge>
              </div>
            </div>
          </div>
        </Card>

        <aside className="space-y-5">
          <Card title="Prepare your file" description="A future import will guide you through validation and column mapping.">
            <ul className="space-y-4 p-5 sm:p-6">
              {["One lost opportunity per row", "Include sales notes where available", "Add transcript text when relevant", "Keep a deal value or estimate"].map((item) => (
                <li key={item} className="flex gap-3 text-sm leading-6 text-slate-700"><CheckCircle2 aria-hidden="true" className="mt-0.5 size-4 shrink-0 text-emerald-600" />{item}</li>
              ))}
            </ul>
          </Card>

          <Card>
            <div className="p-5 sm:p-6">
              <div className="flex items-start gap-3">
                <span className="flex size-10 shrink-0 items-center justify-center rounded-xl bg-slate-100 text-slate-600"><FileSpreadsheet aria-hidden="true" className="size-5" /></span>
                <div><h2 className="text-sm font-bold text-slate-900">Download Sample CSV</h2><p className="mt-1 text-xs leading-5 text-slate-500">Coming in import setup. No broken download link has been added.</p></div>
              </div>
              <Button type="button" variant="outline" disabled className="mt-5 w-full">Coming in import setup</Button>
            </div>
          </Card>

          <div className="flex gap-3 rounded-2xl border border-blue-200 bg-blue-50 p-5 text-sm leading-6 text-blue-900">
            <Info aria-hidden="true" className="mt-0.5 size-4 shrink-0" />
            No file is read, uploaded, validated, or stored in this UI-only milestone.
          </div>
        </aside>
      </section>
    </div>
  );
}
