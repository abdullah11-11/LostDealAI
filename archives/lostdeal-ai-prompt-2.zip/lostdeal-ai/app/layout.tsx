import type { Metadata } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";

const geistSans = Geist({ variable: "--font-geist-sans", subsets: ["latin"] });
const geistMono = Geist_Mono({ variable: "--font-geist-mono", subsets: ["latin"] });

export const metadata: Metadata = {
  applicationName: "LostDeal AI",
  title: { default: "LostDeal AI — Recover the customers you almost had", template: "%s | LostDeal AI" },
  description: "Analyze lost sales, uncover why deals failed, and identify the opportunities most worth recovering.",
  openGraph: { title: "LostDeal AI", description: "Recover the customers you almost had with clearer lost-deal analysis.", type: "website" },
  twitter: { card: "summary", title: "LostDeal AI", description: "Recover the customers you almost had with clearer lost-deal analysis." },
  icons: { icon: "/favicon.svg", shortcut: "/favicon.svg" },
  other: { "codex-preview": "development" },
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="en"><body className={`${geistSans.variable} ${geistMono.variable} antialiased`}>{children}</body></html>;
}
