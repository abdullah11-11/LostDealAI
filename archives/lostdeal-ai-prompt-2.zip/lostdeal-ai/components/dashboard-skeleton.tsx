import { Skeleton } from "@/components/ui";

export function DashboardSkeleton() {
  return (
    <div className="mx-auto max-w-7xl" aria-label="Loading dashboard">
      <Skeleton className="h-3 w-20" />
      <Skeleton className="mt-4 h-10 w-64 max-w-full" />
      <Skeleton className="mt-3 h-4 w-[34rem] max-w-full" />
      <div className="mt-8 grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        {[1, 2, 3, 4].map((item) => <Skeleton key={item} className="h-44 rounded-2xl border border-slate-200 bg-white" />)}
      </div>
      <div className="mt-5 grid gap-5 xl:grid-cols-[1.45fr_0.55fr]">
        <Skeleton className="h-96 rounded-2xl border border-slate-200 bg-white" />
        <Skeleton className="h-96 rounded-2xl border border-slate-200 bg-white" />
      </div>
    </div>
  );
}
