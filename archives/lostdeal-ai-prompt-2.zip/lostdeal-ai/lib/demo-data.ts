export type RecoveryPriority = "HIGH" | "MEDIUM" | "LOW";

export type DemoDeal = {
  id: string;
  customer: string;
  value: string;
  quoteDate: string;
  service: string;
  lostReason: string;
  recoveryScore: number;
  priority: RecoveryPriority;
};

export const demoDeals: DemoDeal[] = [
  { id: "david-miller", customer: "David Miller", value: "$8,500", quoteDate: "Jul 18, 2026", service: "Commercial HVAC", lostReason: "Financing", recoveryScore: 91, priority: "HIGH" },
  { id: "sarah-jones", customer: "Sarah Jones", value: "$12,200", quoteDate: "Jul 12, 2026", service: "Office Renovation", lostReason: "Timing", recoveryScore: 89, priority: "HIGH" },
  { id: "james-reed", customer: "James Reed", value: "$6,700", quoteDate: "Jul 8, 2026", service: "Managed IT", lostReason: "Decision Maker", recoveryScore: 87, priority: "HIGH" },
  { id: "michael-carter", customer: "Michael Carter", value: "$9,300", quoteDate: "Jun 29, 2026", service: "Solar Installation", lostReason: "Price", recoveryScore: 78, priority: "HIGH" },
  { id: "emily-brooks", customer: "Emily Brooks", value: "$4,800", quoteDate: "Jun 22, 2026", service: "Security System", lostReason: "No Follow-up", recoveryScore: 72, priority: "MEDIUM" },
  { id: "olivia-bennet", customer: "Olivia Bennet", value: "$7,150", quoteDate: "Jun 18, 2026", service: "Facility Cleaning", lostReason: "Competitor", recoveryScore: 64, priority: "MEDIUM" },
];

export const reasonBreakdown = [
  { reason: "Price", percentage: 25 },
  { reason: "Financing", percentage: 18 },
  { reason: "Timing", percentage: 13 },
  { reason: "Competitor", percentage: 12 },
  { reason: "Decision Maker", percentage: 10 },
  { reason: "No Follow-up", percentage: 9 },
  { reason: "Other", percentage: 13 },
] as const;
