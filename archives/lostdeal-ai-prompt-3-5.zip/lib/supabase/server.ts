import "server-only";

import { createServerClient } from "@supabase/ssr";
import { cookies } from "next/headers";

import { getSupabasePublicEnvironment } from "@/lib/supabase/env";

/**
 * Creates an RLS-respecting server client for Server Components, Server
 * Actions, and Route Handlers. Authentication is intentionally not activated
 * in Prompt 3.5; this only prepares cookie-aware session handling for Prompt 4.
 */
export async function createClient() {
  const cookieStore = await cookies();
  const { url, publishableKey } = getSupabasePublicEnvironment();

  return createServerClient(url, publishableKey, {
    cookies: {
      getAll() {
        return cookieStore.getAll();
      },
      setAll(cookiesToSet) {
        try {
          cookiesToSet.forEach(({ name, value, options }) => {
            cookieStore.set(name, value, options);
          });
        } catch {
          // Server Components cannot always write cookies. Prompt 4 will add
          // the request-bound token refresh flow that performs those writes.
        }
      },
    },
  });
}
