import "server-only";

import { DEALS_PAGE_SIZE, DEAL_SORT_COLUMNS, type DealLostReason, type DealPriority } from "@/lib/deals/constants";
import {
  buildSafeDealSearchFilter,
  validateDynamicDealFilters,
  type DealsQueryState,
} from "@/lib/deals/query-state";
import { createClient } from "@/lib/supabase/server";

type ServerSupabaseClient = Awaited<ReturnType<typeof createClient>>;

export type DealAnalysisSummary = {
  lost_reason: DealLostReason;
  recovery_score: number | null;
  recovery_priority: DealPriority | null;
  confidence_score: number;
};

export type DealListItem = {
  id: string;
  external_deal_id: string | null;
  customer_name: string | null;
  deal_value: string;
  quote_date: string | null;
  status: string;
  salesperson: string | null;
  service_type: string | null;
  lead_source: string | null;
  analysis_status: string;
  created_at: string;
  analysis: DealAnalysisSummary | null;
};

export type DealDetail = DealListItem & {
  sales_notes: string | null;
  transcript: string | null;
  analysis_error: string | null;
};

export type DealListData = {
  deals: DealListItem[];
  filteredCount: number;
  organizationCount: number;
  page: number;
  pageCount: number;
  services: string[];
  salespeople: string[];
  state: DealsQueryState;
  error: boolean;
};

const ANALYSIS_FIELDS = "lost_reason,recovery_score,recovery_priority,confidence_score";
const LIST_FIELDS = "id,external_deal_id,customer_name,deal_value,quote_date,status,salesperson,service_type,lead_source,analysis_status,created_at";

function normalizeAnalysis(value: unknown): DealAnalysisSummary | null {
  const candidate = Array.isArray(value) ? value[0] : value;
  if (!candidate || typeof candidate !== "object") return null;
  const row = candidate as Record<string, unknown>;
  if (typeof row.lost_reason !== "string" || typeof row.confidence_score !== "number") return null;
  return {
    lost_reason: row.lost_reason as DealLostReason,
    recovery_score: typeof row.recovery_score === "number" ? row.recovery_score : null,
    recovery_priority: typeof row.recovery_priority === "string" ? row.recovery_priority as DealPriority : null,
    confidence_score: row.confidence_score,
  };
}

function normalizeListRow(value: unknown): DealListItem | null {
  if (!value || typeof value !== "object") return null;
  const row = value as Record<string, unknown>;
  if (
    typeof row.id !== "string" ||
    typeof row.deal_value !== "number" && typeof row.deal_value !== "string" ||
    typeof row.analysis_status !== "string" ||
    typeof row.created_at !== "string"
  ) return null;
  const nullableString = (field: string) => typeof row[field] === "string" ? row[field] as string : null;
  return {
    id: row.id,
    external_deal_id: nullableString("external_deal_id"),
    customer_name: nullableString("customer_name"),
    deal_value: String(row.deal_value),
    quote_date: nullableString("quote_date"),
    status: nullableString("status") ?? "lost",
    salesperson: nullableString("salesperson"),
    service_type: nullableString("service_type"),
    lead_source: nullableString("lead_source"),
    analysis_status: row.analysis_status,
    created_at: row.created_at,
    analysis: normalizeAnalysis(row.deal_analyses),
  };
}

function distinctOptions(values: Array<string | null>): string[] {
  return Array.from(new Set(values.map((value) => value?.trim()).filter((value): value is string => Boolean(value))))
    .sort((left, right) => left.localeCompare(right, "en-US"));
}

export async function getDealListData(
  supabase: ServerSupabaseClient,
  organizationId: string,
  requestedState: DealsQueryState,
): Promise<DealListData> {
  const [{ data: optionRows, error: optionError }, { count: organizationCount, error: countError }] = await Promise.all([
    supabase
      .from("deals")
      .select("service_type,salesperson")
      .eq("organization_id", organizationId)
      .range(0, 1_999),
    supabase
      .from("deals")
      .select("id", { count: "exact", head: true })
      .eq("organization_id", organizationId),
  ]);

  if (optionError || countError) {
    return {
      deals: [], filteredCount: 0, organizationCount: 0, page: 1, pageCount: 1,
      services: [], salespeople: [], state: requestedState, error: true,
    };
  }

  const services = distinctOptions((optionRows ?? []).map((row) => row.service_type));
  const salespeople = distinctOptions((optionRows ?? []).map((row) => row.salesperson));
  const state = validateDynamicDealFilters(requestedState, services, salespeople);
  const hasAnalysisFilter = Boolean(state.priority || state.reason);
  const selection = `${LIST_FIELDS},deal_analyses${hasAnalysisFilter ? "!inner" : ""}(${ANALYSIS_FIELDS})`;

  let countQuery = supabase
    .from("deals")
    .select(selection, { count: "exact", head: true })
    .eq("organization_id", organizationId);

  const searchFilter = buildSafeDealSearchFilter(state.q);
  if (searchFilter) countQuery = countQuery.or(searchFilter);
  if (state.analysis) countQuery = countQuery.eq("analysis_status", state.analysis);
  if (state.priority) countQuery = countQuery.eq("deal_analyses.recovery_priority", state.priority);
  if (state.reason) countQuery = countQuery.eq("deal_analyses.lost_reason", state.reason);
  if (state.service) countQuery = countQuery.eq("service_type", state.service);
  if (state.salesperson) countQuery = countQuery.eq("salesperson", state.salesperson);

  const { count, error: filteredCountError } = await countQuery;
  if (filteredCountError) {
    return {
      deals: [], filteredCount: 0, organizationCount: organizationCount ?? 0,
      page: state.page, pageCount: 1, services, salespeople, state, error: true,
    };
  }

  const filteredCount = count ?? 0;
  const pageCount = Math.max(1, Math.ceil(filteredCount / DEALS_PAGE_SIZE));
  const effectivePage = Math.min(state.page, pageCount);
  const from = (effectivePage - 1) * DEALS_PAGE_SIZE;
  const to = from + DEALS_PAGE_SIZE - 1;
  const primaryColumn = DEAL_SORT_COLUMNS[state.sort];

  let query = supabase
    .from("deals")
    .select(selection)
    .eq("organization_id", organizationId);
  if (searchFilter) query = query.or(searchFilter);
  if (state.analysis) query = query.eq("analysis_status", state.analysis);
  if (state.priority) query = query.eq("deal_analyses.recovery_priority", state.priority);
  if (state.reason) query = query.eq("deal_analyses.lost_reason", state.reason);
  if (state.service) query = query.eq("service_type", state.service);
  if (state.salesperson) query = query.eq("salesperson", state.salesperson);
  query = query
    .order(primaryColumn, { ascending: state.direction === "asc", nullsFirst: false })
    .order("id", { ascending: true })
    .range(from, to);

  const { data, error } = await query;
  if (error) {
    return {
      deals: [], filteredCount: 0, organizationCount: organizationCount ?? 0,
      page: state.page, pageCount: 1, services, salespeople, state, error: true,
    };
  }

  return {
    deals: (data ?? []).map(normalizeListRow).filter((deal): deal is DealListItem => Boolean(deal)),
    filteredCount,
    organizationCount: organizationCount ?? 0,
    page: effectivePage,
    pageCount,
    services,
    salespeople,
    state: { ...state, page: effectivePage },
    error: false,
  };
}

export async function getDealDetail(
  supabase: ServerSupabaseClient,
  organizationId: string,
  dealId: string,
): Promise<{ deal: DealDetail | null; error: boolean }> {
  const { data, error } = await supabase
    .from("deals")
    .select(`${LIST_FIELDS},sales_notes,transcript,analysis_error,deal_analyses(${ANALYSIS_FIELDS})`)
    .eq("organization_id", organizationId)
    .eq("id", dealId)
    .maybeSingle();

  if (error) return { deal: null, error: true };
  const normalized = normalizeListRow(data);
  if (!normalized || !data || typeof data !== "object") return { deal: null, error: false };
  const detail = data as Record<string, unknown>;
  return {
    deal: {
      ...normalized,
      sales_notes: typeof detail.sales_notes === "string" ? detail.sales_notes : null,
      transcript: typeof detail.transcript === "string" ? detail.transcript : null,
      analysis_error: typeof detail.analysis_error === "string" ? detail.analysis_error : null,
    },
    error: false,
  };
}
