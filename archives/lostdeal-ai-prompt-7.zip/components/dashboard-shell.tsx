"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { BarChart3, Building2, ChevronRight, CircleUserRound, LogOut, UploadCloud } from "lucide-react";
import { logoutAction } from "@/app/actions/auth";
import { BrandLogo } from "@/components/brand-logo";
import { Badge } from "@/components/ui";

const nav = [
  { href: "/dashboard", label: "Overview", icon: BarChart3 },
  { href: "/deals", label: "Deals", icon: Building2 },
  { href: "/upload", label: "Upload Deals", icon: UploadCloud },
];

function sectionForPath(pathname: string) {
  if (pathname.startsWith("/deals/")) return "Deal analysis";
  if (pathname === "/deals") return "Lost deals";
  if (pathname === "/upload") return "Upload deals";
  return "Recovery overview";
}

function NavLinks({ mobile = false }: { mobile?: boolean }) {
  const pathname = usePathname();
  return (
    <nav aria-label="Dashboard navigation" className={mobile ? "flex gap-1.5" : "space-y-1.5"}>
      {nav.map(({ href, label, icon: Icon }) => {
        const active = pathname === href || (href === "/deals" && pathname.startsWith("/deals/"));
        return (
          <Link
            key={href}
            href={href}
            aria-current={active ? "page" : undefined}
            className={`flex shrink-0 items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-semibold transition-colors focus-visible:outline-none focus-visible:ring-4 focus-visible:ring-blue-100 ${active ? "bg-blue-50 text-[#2952cc]" : "text-slate-600 hover:bg-slate-50 hover:text-slate-950"}`}
          >
            <Icon aria-hidden="true" className="size-4" />
            {label}
          </Link>
        );
      })}
    </nav>
  );
}

function initialsFor(name: string): string {
  const parts = name.trim().split(/\s+/).filter(Boolean);
  return parts.slice(0, 2).map((part) => part[0]?.toUpperCase()).join("") || "U";
}

export function DashboardShell({
  children,
  organizationName,
  userName,
}: {
  children: React.ReactNode;
  organizationName: string;
  userName: string;
}) {
  const pathname = usePathname();
  const initials = initialsFor(userName);
  return (
    <div className="min-h-screen bg-[#f7f8fb]">
      <aside className="fixed inset-y-0 left-0 z-30 hidden w-64 border-r border-slate-200 bg-white lg:flex lg:flex-col">
        <div className="flex h-18 items-center border-b border-slate-200 px-5"><BrandLogo /></div>
        <div className="flex-1 px-3 py-5">
          <p className="mb-3 px-3 text-[10px] font-bold uppercase tracking-[0.16em] text-slate-400">Workspace</p>
          <NavLinks />
        </div>
        <div className="border-t border-slate-200 p-3">
          <div className="rounded-xl border border-slate-200 bg-slate-50 p-3">
            <div className="flex items-start gap-3">
              <span className="flex size-9 shrink-0 items-center justify-center rounded-lg bg-white text-slate-500 shadow-sm">
                <CircleUserRound aria-hidden="true" className="size-4" />
              </span>
              <div className="min-w-0 flex-1">
                <p className="truncate text-xs font-bold text-slate-800">{organizationName}</p>
                <p className="mt-0.5 truncate text-[11px] text-slate-500">{userName}</p>
              </div>
            </div>
            <form action={logoutAction}>
              <button type="submit" className="mt-3 flex w-full items-center gap-2 rounded-lg px-2 py-2 text-left text-xs font-semibold text-slate-600 transition hover:bg-white hover:text-slate-950 focus-visible:outline-none focus-visible:ring-4 focus-visible:ring-blue-100">
                <LogOut aria-hidden="true" className="size-3.5" /> Log out
              </button>
            </form>
          </div>
        </div>
      </aside>

      <div className="lg:pl-64">
        <header className="sticky top-0 z-20 border-b border-slate-200 bg-white/95 backdrop-blur">
          <div className="flex h-18 items-center justify-between gap-3 px-4 sm:px-6 lg:px-8">
            <div className="lg:hidden"><BrandLogo compact /></div>
            <div className="hidden lg:block">
              <p className="text-xs font-semibold text-slate-400">LostDeal AI / {organizationName}</p>
              <p className="mt-0.5 text-sm font-bold text-slate-800">{sectionForPath(pathname)}</p>
            </div>
            <div className="flex items-center gap-2">
              {pathname === "/dashboard" && <Badge tone="demo" className="hidden sm:inline-flex">Sample data</Badge>}
              <span
                className="flex size-9 items-center justify-center rounded-xl border border-slate-200 bg-slate-50 text-xs font-extrabold text-slate-600 lg:hidden"
                title={`${organizationName} · ${userName}`}
                aria-label={`${organizationName}, signed in as ${userName}`}
              >
                {initials}
              </span>
              <Link href="/upload" className="inline-flex h-9 items-center gap-2 rounded-xl bg-[#172554] px-3.5 text-sm font-bold text-white transition hover:bg-[#1e3a8a] focus-visible:outline-none focus-visible:ring-4 focus-visible:ring-blue-100">
                Import deals <ChevronRight aria-hidden="true" className="size-3.5" />
              </Link>
            </div>
          </div>
          <div className="overflow-x-auto border-t border-slate-100 px-3 py-2 lg:hidden"><NavLinks mobile /></div>
        </header>
        <main className="px-4 py-6 sm:px-6 sm:py-8 lg:px-8 lg:py-10">{children}</main>
      </div>
    </div>
  );
}
