# LostDeal AI

LostDeal AI helps businesses understand why sales opportunities were lost and
identify which deals may be worth recovering.

The current V1 application includes authenticated organization workspaces,
Supabase RLS, CSV import, real deal browsing, grounded OpenAI deal analysis,
and deterministic Recovery Scoring v1.0.

## Stack

- Next.js App Router
- TypeScript in strict mode
- Tailwind CSS
- ESLint
- npm

The OpenAI Sites runtime uses Vinext while preserving the standard App Router
file structure and Next.js APIs.

## Routes

- `/`
- `/login`
- `/signup`
- `/dashboard`
- `/deals`
- `/deals/[id]`
- `/upload`

## Commands

```bash
npm run dev
npm run lint
npm run typecheck
npm run build
npm run test:scoring
npm run test:ai
npm run test:deals
```

## Server configuration

Copy `.env.example` to `.env.local` and configure the Supabase values.
`OPENAI_API_KEY` is required as a server-only secret for LostDeal AI analysis;
never prefix it with `NEXT_PUBLIC_`, return it from an API route, or commit it.
`OPENAI_MODEL` selects the server-side analysis model.

Recovery Score is calculated only by deterministic TypeScript code from stored
analysis fields and quote recency. Score calculation, backfill, and refresh make
no OpenAI request. Scores are persisted under the authenticated user's normal
organization-scoped RLS access.
