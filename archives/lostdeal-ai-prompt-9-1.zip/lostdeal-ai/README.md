# LostDeal AI

LostDeal AI helps businesses understand why sales opportunities were lost and
identify which deals may be worth recovering.

The current V1 application includes authenticated organization workspaces,
Supabase RLS, CSV import, real deal browsing, grounded OpenAI deal analysis,
deterministic Recovery Scoring v1.0, and a real organization-scoped recovery
dashboard.

## Stack

- Next.js App Router
- TypeScript in strict mode
- Tailwind CSS
- ESLint
- npm

The OpenAI Sites runtime uses Vinext while preserving the standard App Router
file structure and Next.js APIs.

## Routes

- `/`
- `/login`
- `/signup`
- `/dashboard`
- `/deals`
- `/deals/[id]`
- `/upload`

## Commands

```bash
npm run dev
npm run lint
npm run typecheck
npm run build
npm run test:scoring
npm run test:dashboard
npm run test:ai
npm run test:deals
```

## Server configuration

Copy `.env.example` to `.env.local` and configure the Supabase values.
`OPENAI_API_KEY` is required as a server-only secret for LostDeal AI analysis;
never prefix it with `NEXT_PUBLIC_`, return it from an API route, or commit it.
`OPENAI_MODEL` selects the server-side analysis model.

Recovery Score is calculated only by deterministic TypeScript code from stored
analysis fields and quote recency. Score calculation, backfill, and refresh make
no OpenAI request. Scores are persisted under the authenticated user's normal
organization-scoped RLS access.

## Recovery dashboard

`/dashboard` reads lightweight persisted `deals`, `deal_analyses`, and `uploads`
fields for the authenticated user's active organization. Normal dashboard loads
are read-only: they do not call OpenAI and do not calculate or refresh Recovery
Scores. Totals are processed server-side across every tenant-accessible deal in
controlled pages; the browser does not aggregate workspace records.

Top Recovery Opportunities are derived server-side from that same lightweight
tenant deal set, so the ranking and KPI universes stay aligned without a second
relationship-ordering query. Recent Imports and Top Recovery Opportunities have
section-level failure handling; only a critical tenant deals/metrics failure can
produce the full Overview error state. Persisted analysis metadata is normalized
defensively, including older analyses without scoring timestamps.

- **Total Lost Deal Value** is the combined quoted value of every imported lost
  deal in the current workspace.
- **High Priority Deal Value** is the combined deal value of scored deals whose
  persisted priority is `HIGH`. High Priority Deal Value is not predicted
  recovered revenue.
- **Average Recovery Score** averages only valid persisted, non-null scores.
- **Analysis Coverage** counts completed deals that have a valid related
  analysis, divided by all workspace deals.
- **Scoring Coverage** distinguishes scored analyses from completed valid
  analyses whose Recovery Score is still null.

Recovery Score is a deterministic prioritization indicator, not a probability
or guarantee. Refreshing or backfilling scores remains an explicit user action.
