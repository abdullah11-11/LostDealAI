import type { Metadata } from "next";
import { redirect } from "next/navigation";
import { Building2, CheckCircle2 } from "lucide-react";

import { BrandLogo } from "@/components/brand-logo";
import { OnboardingForm } from "@/components/onboarding-form";
import { getAppAuthContext } from "@/lib/auth/server";

export const metadata: Metadata = { title: "Set up your workspace" };
export const dynamic = "force-dynamic";

export default async function OnboardingPage() {
  const context = await getAppAuthContext();
  if (!context.identity) redirect("/login?next=%2Fonboarding");
  if (context.organization) redirect("/dashboard");

  return (
    <main className="min-h-screen bg-[#f7f8fb]">
      <header className="border-b border-slate-200 bg-white px-5 py-5 sm:px-8">
        <div className="mx-auto flex max-w-6xl items-center justify-between gap-4">
          <BrandLogo />
          <p className="truncate text-xs font-semibold text-slate-500">Signed in as {context.identity.email}</p>
        </div>
      </header>
      <div className="mx-auto grid max-w-6xl gap-10 px-5 py-10 lg:grid-cols-[0.85fr_1.15fr] lg:items-center lg:px-8 lg:py-16">
        <section>
          <span className="flex size-12 items-center justify-center rounded-2xl bg-blue-50 text-[#2952cc]">
            <Building2 aria-hidden="true" className="size-6" />
          </span>
          <p className="mt-7 text-xs font-bold uppercase tracking-[0.16em] text-[#2952cc]">Workspace setup</p>
          <h1 className="mt-3 text-4xl font-semibold tracking-[-0.035em] text-[#0b1739] sm:text-5xl">Set up your workspace</h1>
          <p className="mt-5 max-w-xl text-base leading-8 text-slate-600">Tell us about your business so LostDeal AI can organize your lost opportunities.</p>
          <ul className="mt-8 space-y-3 text-sm text-slate-600">
            {["Your data stays separated by organization", "You become the workspace owner", "You can start with sample data before importing deals"].map((item) => (
              <li key={item} className="flex items-center gap-3">
                <CheckCircle2 aria-hidden="true" className="size-4 text-emerald-600" /> {item}
              </li>
            ))}
          </ul>
        </section>
        <section className="rounded-3xl border border-slate-200 bg-white p-6 shadow-sm sm:p-8">
          <h2 className="text-xl font-bold text-[#0b1739]">Business details</h2>
          <p className="mt-2 text-sm leading-6 text-slate-500">This creates your first LostDeal AI organization.</p>
          <OnboardingForm needsFullName={!context.profileFullName} />
        </section>
      </div>
    </main>
  );
}
