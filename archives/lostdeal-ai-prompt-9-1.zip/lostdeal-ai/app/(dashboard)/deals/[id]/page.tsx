import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import {
  AlertCircle,
  ArrowLeft,
  Bot,
  Calculator,
  CheckCircle2,
  Clock3,
  Database,
  FileText,
  LoaderCircle,
  MessageSquareText,
} from "lucide-react";

import { AnalyzeDealButton } from "@/components/analyze-deal-button";
import { CalculateRecoveryScoreButton } from "@/components/calculate-recovery-score-button";
import { DealPriorityBadge, DealStatusBadge } from "@/components/deal-status";
import { Badge, Card, buttonStyles } from "@/components/ui";
import { getSafeNextPath } from "@/lib/auth/validation";
import { requireOrganization } from "@/lib/auth/server";
import { formatDealCurrency, formatDealDate, formatDealTimestamp, humanizeDealEnum } from "@/lib/deals/format";
import { getDealDetail, type DealDetail } from "@/lib/deals/server";
import { createClient } from "@/lib/supabase/server";

export const metadata: Metadata = { title: "Deal details" };
export const dynamic = "force-dynamic";

const UUID_PATTERN = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;

export default async function DealPage({
  params,
  searchParams,
}: {
  params: Promise<{ id: string }>;
  searchParams: Promise<Record<string, string | string[] | undefined>>;
}) {
  const [{ id }, query] = await Promise.all([params, searchParams]);
  const decodedId = decodeURIComponent(id);
  if (!UUID_PATTERN.test(decodedId)) notFound();

  const context = await requireOrganization(`/deals/${encodeURIComponent(decodedId)}`);
  const supabase = await createClient();
  const result = await getDealDetail(supabase, context.organization.id, decodedId);
  if (!result.error && !result.deal) notFound();

  const rawFrom = typeof query.from === "string" ? query.from : null;
  const safeFrom = getSafeNextPath(rawFrom);
  const backHref = safeFrom === "/deals" || safeFrom.startsWith("/deals?") ? safeFrom : "/deals";

  if (result.error || !result.deal) {
    return (
      <div className="mx-auto max-w-3xl">
        <Link href={backHref} className="inline-flex items-center gap-2 text-sm font-semibold text-slate-500 hover:text-slate-900"><ArrowLeft aria-hidden="true" className="size-4" />Back to Deals</Link>
        <div role="alert" className="mt-8 rounded-2xl border border-red-200 bg-white p-8 text-center shadow-sm">
          <AlertCircle aria-hidden="true" className="mx-auto size-9 text-red-600" />
          <h1 className="mt-4 text-xl font-bold text-slate-950">This deal could not be loaded</h1>
          <p className="mt-2 text-sm leading-6 text-slate-500">Your data has not changed. Try again shortly.</p>
          <Link href={`/deals/${decodedId}?from=${encodeURIComponent(backHref)}`} className={buttonStyles("outline", "mt-6")}>Try again</Link>
        </div>
      </div>
    );
  }

  const deal = result.deal;
  return (
    <div className="mx-auto max-w-7xl">
      <Link href={backHref} className="inline-flex items-center gap-2 text-sm font-semibold text-slate-500 hover:text-slate-900 focus-visible:outline-none focus-visible:ring-4 focus-visible:ring-blue-100">
        <ArrowLeft aria-hidden="true" className="size-4" /> Back to Deals
      </Link>

      <header className="mt-6 flex flex-col gap-5 lg:flex-row lg:items-start lg:justify-between">
        <div>
          <div className="flex flex-wrap items-center gap-2">
            <DealStatusBadge status={deal.analysis_status} />
            {deal.external_deal_id && <Badge tone="neutral">{deal.external_deal_id}</Badge>}
          </div>
          <h1 className="mt-4 text-3xl font-semibold tracking-[-0.025em] text-[#0b1739] sm:text-4xl">{deal.customer_name || "Unnamed customer"}</h1>
          <p className="mt-2 text-sm text-slate-500">{deal.service_type || "Service not provided"} · {formatDealCurrency(deal.deal_value)} · {formatDealDate(deal.quote_date)}</p>
        </div>
        <div className="rounded-2xl border border-slate-200 bg-white px-5 py-4 shadow-sm lg:min-w-56 lg:text-right">
          <p className="text-[10px] font-extrabold uppercase tracking-[0.12em] text-slate-500">Deal value</p>
          <p className="mt-1 text-3xl font-semibold tracking-tight text-[#0b1739]">{formatDealCurrency(deal.deal_value)}</p>
          <p className="mt-1 text-[11px] text-slate-500">Imported source value</p>
        </div>
      </header>

      <div className="mt-7"><RecoveryScorePanel deal={deal} /></div>

      <div className="mt-5 grid gap-5 xl:grid-cols-[1.15fr_0.85fr]">
        <div className="space-y-5">
          <Card title="Source Data" description="Imported business information · Not AI-generated" action={<Badge tone="neutral">Source</Badge>}>
            <dl className="grid gap-px bg-slate-100 sm:grid-cols-2">
              <DataField label="Customer Name" value={deal.customer_name || "Unnamed customer"} />
              <DataField label="External Deal ID" value={deal.external_deal_id || "—"} />
              <DataField label="Deal Value" value={formatDealCurrency(deal.deal_value)} />
              <DataField label="Quote Date" value={formatDealDate(deal.quote_date)} />
              <DataField label="Status" value={humanizeDealEnum(deal.status)} />
              <DataField label="Salesperson" value={deal.salesperson || "—"} />
              <DataField label="Service Type" value={deal.service_type || "—"} />
              <DataField label="Lead Source" value={deal.lead_source || "—"} />
              <DataField label="Imported Date" value={formatDealTimestamp(deal.created_at)} wide />
            </dl>
          </Card>

          <Card title="Sales Notes" description="Complete imported source text" action={<FileText aria-hidden="true" className="size-5 text-slate-400" />}>
            <div className="p-5 sm:p-6">
              {deal.sales_notes ? (
                <p className="whitespace-pre-wrap break-words rounded-xl border border-slate-200 bg-slate-50 p-4 text-sm leading-7 text-slate-700">{deal.sales_notes}</p>
              ) : (
                <p className="text-sm text-slate-500">No sales notes provided.</p>
              )}
            </div>
          </Card>

          <Card title="Transcript" description="Complete imported conversation text" action={<MessageSquareText aria-hidden="true" className="size-5 text-slate-400" />}>
            <div className="p-5 sm:p-6">
              {deal.transcript ? (
                <details className="group rounded-xl border border-slate-200 bg-slate-50" open={deal.transcript.length <= 1_200}>
                  <summary className="cursor-pointer px-4 py-3 text-sm font-bold text-slate-800 focus-visible:outline-none focus-visible:ring-4 focus-visible:ring-blue-100">
                    <span className="group-open:hidden">Expand full transcript</span>
                    <span className="hidden group-open:inline">Collapse transcript</span>
                  </summary>
                  <p className="max-h-[34rem] overflow-y-auto whitespace-pre-wrap break-words border-t border-slate-200 p-4 text-sm leading-7 text-slate-700">{deal.transcript}</p>
                </details>
              ) : (
                <p className="text-sm text-slate-500">No transcript provided.</p>
              )}
            </div>
          </Card>
        </div>

        <aside className="space-y-5">
          <DealAnalysisPanel deal={deal} />
          <div className="rounded-2xl border border-blue-200 bg-blue-50 p-5">
            <div className="flex items-center gap-2 text-sm font-bold text-blue-950"><Database aria-hidden="true" className="size-4" />Source and analysis stay separate</div>
            <p className="mt-2 text-sm leading-6 text-blue-900"><strong>Source Data</strong> is exactly what was imported. <strong>LostDeal AI Analysis</strong> is generated interpretation. <strong>Recovery Score</strong> is a separate deterministic ranking calculated from stored analysis signals and quote recency.</p>
          </div>
        </aside>
      </div>
    </div>
  );
}

function RecoveryScorePanel({ deal }: { deal: DealDetail }) {
  if (deal.analysis_status !== "completed" || !deal.analysis) return null;
  const analysis = deal.analysis;
  if (analysis.recovery_score === null || !analysis.recovery_priority) {
    return (
      <Card title="Recovery Score" description="Deterministic prioritization · Separate from AI analysis" action={<Calculator aria-hidden="true" className="size-5 text-[#2952cc]" />}>
        <div className="flex flex-col gap-5 p-5 sm:flex-row sm:items-center sm:justify-between sm:p-6">
          <div>
            <p className="text-2xl font-semibold tracking-tight text-[#0b1739]">Not scored yet</p>
            <p className="mt-2 max-w-2xl text-sm leading-6 text-slate-600">Calculate a deterministic opportunity-ranking score from the completed analysis and quote recency. This makes no OpenAI call.</p>
            <p className="mt-2 text-xs leading-5 text-slate-500">Recovery Score is a prioritization indicator, not a probability or guarantee of conversion.</p>
          </div>
          <CalculateRecoveryScoreButton dealId={deal.id} />
        </div>
      </Card>
    );
  }

  const scoring = analysis.scoring_metadata;
  return (
    <Card title="Recovery Score" description="Deterministic prioritization · Separate from AI analysis" action={<DealPriorityBadge priority={analysis.recovery_priority} />}>
      <div className="p-5 sm:p-6">
        <div className="grid gap-6 lg:grid-cols-[0.42fr_1fr] lg:items-center">
          <div>
            <p aria-label={`Recovery Score ${analysis.recovery_score} out of 100`} className="text-5xl font-semibold tracking-[-0.045em] text-[#0b1739]">{analysis.recovery_score}<span className="text-2xl text-slate-400">/100</span></p>
            <div className="mt-3"><DealPriorityBadge priority={analysis.recovery_priority} /></div>
            <p className="mt-3 text-xs leading-5 text-slate-500">A deterministic prioritization score, not a probability of conversion.</p>
          </div>

          {scoring ? (
            <dl className="grid gap-3 sm:grid-cols-2 xl:grid-cols-4">
              <ScoreFactor label="Buying Intent" value={`${scoring.buying_intent_score}/100`} detail={`Weight ${Math.round(scoring.buying_intent_weight * 100)}% · ${scoring.buying_intent_contribution.toFixed(1)} points`} />
              <ScoreFactor label="Loss Reason Recoverability" value={humanizeDealEnum(scoring.reason)} detail={`${scoring.reason_recoverability}/100 · Weight ${Math.round(scoring.reason_weight * 100)}%`} />
              <ScoreFactor label="Recency" value={`${scoring.recency_score}/100`} detail={`Weight ${Math.round(scoring.recency_weight * 100)}%${scoring.quote_age_days === null ? " · Date missing" : scoring.quote_age_days < 0 ? " · Future date neutralized" : ` · ${scoring.quote_age_days} days old`}`} />
              <ScoreFactor label="Analysis Confidence" value={`${scoring.confidence_score}/100`} detail={`Multiplier ${scoring.confidence_multiplier.toFixed(3)}`} />
            </dl>
          ) : (
            <p className="rounded-xl border border-slate-200 bg-slate-50 p-4 text-sm leading-6 text-slate-600">The stored score is available, but its detailed versioned breakdown is not.</p>
          )}
        </div>

        {scoring && (
          <details className="group mt-6 rounded-xl border border-slate-200 bg-slate-50">
            <summary className="cursor-pointer px-4 py-3 text-sm font-bold text-slate-900 focus-visible:outline-none focus-visible:ring-4 focus-visible:ring-blue-100">How this score was calculated</summary>
            <div className="space-y-4 border-t border-slate-200 p-4">
              <p className="text-sm leading-6 text-slate-700">{analysis.score_explanation || "This score was calculated from the persisted versioned scoring inputs."}</p>
              {scoring.applied_caps.length > 0 ? (
                <div>
                  <p className="text-xs font-extrabold uppercase tracking-[0.1em] text-slate-500">Safety caps</p>
                  <ul className="mt-2 space-y-2 text-sm leading-6 text-slate-700">
                    {scoring.applied_caps.map((cap) => (
                      <li key={cap.code} className="flex gap-2"><span aria-hidden="true" className="mt-2 size-1.5 shrink-0 rounded-full bg-amber-500" /><span>{cap.limitedScore ? `Score limited to ${cap.maximum}` : `Maximum ${cap.maximum} considered`} because {cap.explanation}.</span></li>
                    ))}
                  </ul>
                </div>
              ) : <p className="text-sm text-slate-600">No limiting caps applied.</p>}
              <p className="text-xs leading-5 text-slate-500">LostDeal Recovery Scoring v{scoring.version} · As of {formatDealDate(scoring.as_of_date)} · Calculated {formatDealTimestamp(scoring.calculated_at)}</p>
            </div>
          </details>
        )}

        <p className="mt-5 border-t border-slate-100 pt-4 text-xs leading-5 text-slate-500">Recovery Score is a prioritization indicator based on deal signals, loss reason, recency and analysis confidence. It is not a prediction or guarantee of conversion.</p>
      </div>
    </Card>
  );
}

function ScoreFactor({ label, value, detail }: { label: string; value: string; detail: string }) {
  return (
    <div className="rounded-xl border border-slate-200 bg-white p-4">
      <dt className="text-[10px] font-extrabold uppercase tracking-[0.1em] text-slate-500">{label}</dt>
      <dd className="mt-2 text-sm font-bold text-slate-950">{value}</dd>
      <dd className="mt-1 text-xs leading-5 text-slate-500">{detail}</dd>
    </div>
  );
}

function DataField({ label, value, wide = false }: { label: string; value: string; wide?: boolean }) {
  return (
    <div className={`bg-white px-5 py-4 sm:px-6 ${wide ? "sm:col-span-2" : ""}`}>
      <dt className="text-[10px] font-extrabold uppercase tracking-[0.1em] text-slate-500">{label}</dt>
      <dd className="mt-2 break-words text-sm font-semibold text-slate-800">{value}</dd>
    </div>
  );
}

function DealAnalysisPanel({ deal }: { deal: DealDetail }) {
  if (deal.analysis_status === "processing") {
    return (
      <Card title="LostDeal AI Analysis" description="Generated interpretation · Separate from source data">
        <div className="p-5 sm:p-6"><AnalysisState icon={<LoaderCircle aria-hidden="true" className="size-6 animate-spin" />} title="Analysis in progress" description="LostDeal AI is processing this deal. No completion timing is estimated." tone="blue" /></div>
      </Card>
    );
  }

  if (deal.analysis_status === "failed") {
    return (
      <Card title="LostDeal AI Analysis" description="Generated interpretation · Separate from source data">
        <div className="p-5 sm:p-6">
          <AnalysisState icon={<AlertCircle aria-hidden="true" className="size-6" />} title="Analysis failed" description="We couldn't analyze this deal right now. Please try again." tone="red" />
          <div className="mt-5 border-t border-slate-100 pt-5"><AnalyzeDealButton dealId={deal.id} retry /></div>
        </div>
      </Card>
    );
  }

  if (deal.analysis_status === "completed" && deal.analysis) {
    return (
      <Card title="LostDeal AI Analysis" description="AI-generated interpretation · Review before acting">
        <div className="space-y-6 p-5 sm:p-6">
          <div className="flex size-11 items-center justify-center rounded-xl bg-emerald-50 text-emerald-700"><CheckCircle2 aria-hidden="true" className="size-6" /></div>
          <div>
            <h2 className="text-lg font-bold text-slate-950">Analysis completed</h2>
            <p className="mt-1 text-sm leading-6 text-slate-600">The result is grounded in the imported notes and transcript shown on this page.</p>
          </div>
          <dl className="grid gap-3 sm:grid-cols-2">
            <AnalysisValue label="Lost Reason" value={humanizeDealEnum(deal.analysis.lost_reason)} />
            <AnalysisValue label="Buying Intent" value={`${deal.analysis.buying_intent_score}/100`} />
            <AnalysisValue label="Confidence" value={`${deal.analysis.confidence_score}/100`} />
          </dl>

          <AnalysisSection title="Why it was lost">
            <p className="text-sm leading-6 text-slate-700">{deal.analysis.lost_reason_detail || "No additional detail was provided."}</p>
          </AnalysisSection>

          <AnalysisSection title="Evidence">
            {deal.analysis.evidence.length ? (
              <div className="space-y-3">
                {deal.analysis.evidence.map((evidence, index) => (
                  <blockquote key={`${evidence.source}-${index}`} className="rounded-xl border border-slate-200 bg-slate-50 p-4">
                    <p className="text-[10px] font-extrabold uppercase tracking-[0.1em] text-slate-500">{humanizeDealEnum(evidence.source)}</p>
                    <p className="mt-2 text-sm leading-6 text-slate-700">“{evidence.excerpt}”</p>
                  </blockquote>
                ))}
              </div>
            ) : <p className="text-sm text-slate-500">No trustworthy quoted evidence was available.</p>}
          </AnalysisSection>

          <div className="grid gap-5 sm:grid-cols-2 xl:grid-cols-1">
            <AnalysisList title="Positive Signals" items={deal.analysis.positive_signals} empty="No positive signals identified." />
            <AnalysisList title="Negative Signals" items={deal.analysis.negative_signals} empty="No negative signals identified." />
          </div>

          <AnalysisSection title="Recommended Action"><p className="text-sm leading-6 text-slate-700">{deal.analysis.recommended_action || "Human review recommended."}</p></AnalysisSection>
          <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-1">
            <AnalysisValue label="Recommended Timing" value={deal.analysis.recommended_timing || "Human review recommended"} />
            <AnalysisValue label="Recommended Channel" value={humanizeDealEnum(deal.analysis.recommended_channel)} />
          </div>
          <AnalysisSection title="Suggested Follow-Up">
            <p className="whitespace-pre-wrap text-sm leading-6 text-slate-700">{deal.analysis.follow_up_message || "No follow-up recommended."}</p>
          </AnalysisSection>
        </div>
      </Card>
    );
  }

  return (
    <Card title="LostDeal AI Analysis" description="Generated interpretation · Separate from source data">
      <div className="p-5 sm:p-6">
        <AnalysisState icon={<Clock3 aria-hidden="true" className="size-6" />} title="Analysis pending" description="LostDeal AI will analyze the sales notes or transcript to identify why this opportunity was lost and recommend the next action." tone="blue" />
        <div className="mt-5 border-t border-slate-100 pt-5"><AnalyzeDealButton dealId={deal.id} /></div>
      </div>
    </Card>
  );
}

function AnalysisState({
  icon,
  title,
  description,
  tone,
}: {
  icon: React.ReactNode;
  title: string;
  description: string;
  tone: "blue" | "red";
}) {
  return (
    <div>
      <div className={`flex size-11 items-center justify-center rounded-xl ${tone === "red" ? "bg-red-50 text-red-700" : "bg-blue-50 text-[#2952cc]"}`}>{icon}</div>
      <div className="mt-4 flex items-center gap-2"><Bot aria-hidden="true" className="size-4 text-slate-400" /><h2 className="text-lg font-bold text-slate-950">{title}</h2></div>
      <p className="mt-2 text-sm leading-6 text-slate-600">{description}</p>
    </div>
  );
}

function AnalysisValue({ label, value }: { label: string; value: string }) {
  return <div className="rounded-xl border border-slate-200 bg-slate-50 p-4"><dt className="text-[10px] font-extrabold uppercase tracking-[0.1em] text-slate-500">{label}</dt><dd className="mt-2 text-sm font-bold text-slate-900">{value}</dd></div>;
}

function AnalysisSection({ title, children }: { title: string; children: React.ReactNode }) {
  return <section className="border-t border-slate-100 pt-5"><h3 className="text-sm font-bold text-slate-950">{title}</h3><div className="mt-3">{children}</div></section>;
}

function AnalysisList({ title, items, empty }: { title: string; items: string[]; empty: string }) {
  return (
    <section className="rounded-xl border border-slate-200 bg-slate-50 p-4">
      <h3 className="text-sm font-bold text-slate-950">{title}</h3>
      {items.length ? <ul className="mt-3 space-y-2 text-sm leading-6 text-slate-700">{items.map((item, index) => <li key={`${item}-${index}`} className="flex gap-2"><span aria-hidden="true" className="mt-2 size-1.5 shrink-0 rounded-full bg-[#2952cc]" />{item}</li>)}</ul> : <p className="mt-3 text-sm text-slate-500">{empty}</p>}
    </section>
  );
}
