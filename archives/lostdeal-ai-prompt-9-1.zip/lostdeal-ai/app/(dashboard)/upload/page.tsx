import type { Metadata } from "next";

import { CsvImportWorkflow, type RecentImport } from "@/components/csv-import-workflow";
import { PageHeader } from "@/components/page-heading";
import { Badge } from "@/components/ui";
import { requireOrganization } from "@/lib/auth/server";
import { createClient } from "@/lib/supabase/server";

export const metadata: Metadata = { title: "Upload lost deals" };
export const dynamic = "force-dynamic";

export default async function UploadPage() {
  const context = await requireOrganization("/upload");
  const supabase = await createClient();
  const { data, error } = await supabase
    .from("uploads")
    .select("id, filename, created_at, valid_rows, status")
    .eq("organization_id", context.organization.id)
    .order("created_at", { ascending: false })
    .limit(6);

  const recentImports: RecentImport[] = error
    ? []
    : (data ?? []).map((upload) => ({
        id: upload.id,
        filename: upload.filename,
        createdAt: upload.created_at,
        rowsImported: upload.valid_rows,
        status: upload.status as RecentImport["status"],
      }));

  return (
    <div className="mx-auto max-w-6xl">
      <PageHeader
        eyebrow="Import"
        title="Upload Lost Deals"
        description="Map, validate, review, and securely import lost opportunities from CSV. Valid rows are stored for your workspace; invalid rows are never silently included."
        action={<Badge tone="completed">CSV import active</Badge>}
      />
      <div className="mt-8">
        <CsvImportWorkflow
          organizationName={context.organization.name}
          recentImports={recentImports}
          recentImportsUnavailable={Boolean(error)}
        />
      </div>
    </div>
  );
}
