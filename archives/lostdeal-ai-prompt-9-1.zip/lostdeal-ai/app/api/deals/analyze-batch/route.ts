import { NextResponse } from "next/server";

import { analyzePendingDeals } from "@/lib/ai/deal-analysis-service";
import { getActiveOrganization, getVerifiedIdentity } from "@/lib/auth/server";
import { createClient } from "@/lib/supabase/server";

export async function POST() {
  try {
    const supabase = await createClient();
    const identity = await getVerifiedIdentity(supabase);
    if (!identity) return NextResponse.json({ error: "Your session has expired. Log in and try again." }, { status: 401 });
    const organization = await getActiveOrganization(supabase, identity.id);
    if (!organization) return NextResponse.json({ error: "Complete workspace setup before analyzing deals." }, { status: 403 });

    const result = await analyzePendingDeals(supabase, organization.id);
    return NextResponse.json({ success: true, result });
  } catch {
    return NextResponse.json({ error: "Pending deals could not be analyzed right now. Please try again." }, { status: 503 });
  }
}
