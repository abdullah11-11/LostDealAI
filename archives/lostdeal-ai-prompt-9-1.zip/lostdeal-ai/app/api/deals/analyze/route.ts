import { NextResponse } from "next/server";

import { getActiveOrganization, getVerifiedIdentity } from "@/lib/auth/server";
import { analyzeAuthorizedDeal } from "@/lib/ai/deal-analysis-service";
import { createClient } from "@/lib/supabase/server";

const UUID_PATTERN = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;

export async function POST(request: Request) {
  try {
    const supabase = await createClient();
    const identity = await getVerifiedIdentity(supabase);
    if (!identity) return NextResponse.json({ error: "Your session has expired. Log in and try again." }, { status: 401 });
    const organization = await getActiveOrganization(supabase, identity.id);
    if (!organization) return NextResponse.json({ error: "Complete workspace setup before analyzing deals." }, { status: 403 });

    const body = await request.json().catch(() => null) as { deal_id?: unknown } | null;
    if (!body || typeof body.deal_id !== "string" || !UUID_PATTERN.test(body.deal_id)) {
      return NextResponse.json({ error: "A valid deal is required." }, { status: 400 });
    }

    const result = await analyzeAuthorizedDeal(supabase, organization.id, body.deal_id);
    if (result.status === "not_found") return NextResponse.json({ error: "Deal not found." }, { status: 404 });
    if (result.status === "processing") {
      return NextResponse.json({ status: "processing", message: "Analysis is already in progress." }, { status: 409 });
    }
    if (result.status === "failed") {
      const status = result.code === "SOURCE_TOO_LONG" || result.code === "INSUFFICIENT_SOURCE" ? 422 : 503;
      return NextResponse.json({
        status: "failed",
        code: result.code,
        error: "We couldn't analyze this deal right now. Please try again.",
      }, { status });
    }
    return NextResponse.json({
      status: "completed",
      fresh: result.fresh,
      ...(result.fresh ? { usage: result.usage } : {}),
    });
  } catch {
    return NextResponse.json({ error: "We couldn't analyze this deal right now. Please try again." }, { status: 500 });
  }
}
