import { NextResponse } from "next/server";

import { getActiveOrganization, getVerifiedIdentity } from "@/lib/auth/server";
import { scoreOrganizationAnalyses } from "@/lib/scoring/score-service";
import { createClient } from "@/lib/supabase/server";

const UUID_PATTERN = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;

export async function POST(request: Request) {
  try {
    const supabase = await createClient();
    const identity = await getVerifiedIdentity(supabase);
    if (!identity) return NextResponse.json({ error: "Your session has expired. Log in and try again." }, { status: 401 });
    const organization = await getActiveOrganization(supabase, identity.id);
    if (!organization) return NextResponse.json({ error: "Complete workspace setup before scoring deals." }, { status: 403 });

    const body = await request.json().catch(() => null) as { mode?: unknown; cursor?: unknown } | null;
    if (!body || (body.mode !== "unscored" && body.mode !== "refresh")) {
      return NextResponse.json({ error: "A valid scoring operation is required." }, { status: 400 });
    }
    const cursor = body.cursor === null || body.cursor === undefined ? null : body.cursor;
    if (cursor !== null && (typeof cursor !== "string" || !UUID_PATTERN.test(cursor))) {
      return NextResponse.json({ error: "The scoring cursor is invalid." }, { status: 400 });
    }

    const result = await scoreOrganizationAnalyses(supabase, organization.id, body.mode, cursor);
    return NextResponse.json({ success: true, result });
  } catch {
    return NextResponse.json({ error: "Recovery Scores could not be calculated right now." }, { status: 503 });
  }
}

