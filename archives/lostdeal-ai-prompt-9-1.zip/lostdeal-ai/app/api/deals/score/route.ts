import { NextResponse } from "next/server";

import { getActiveOrganization, getVerifiedIdentity } from "@/lib/auth/server";
import { scoreAuthorizedDeal } from "@/lib/scoring/score-service";
import { createClient } from "@/lib/supabase/server";

const UUID_PATTERN = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;

export async function POST(request: Request) {
  try {
    const supabase = await createClient();
    const identity = await getVerifiedIdentity(supabase);
    if (!identity) return NextResponse.json({ error: "Your session has expired. Log in and try again." }, { status: 401 });
    const organization = await getActiveOrganization(supabase, identity.id);
    if (!organization) return NextResponse.json({ error: "Complete workspace setup before scoring deals." }, { status: 403 });

    const body = await request.json().catch(() => null) as { deal_id?: unknown } | null;
    if (!body || typeof body.deal_id !== "string" || !UUID_PATTERN.test(body.deal_id)) {
      return NextResponse.json({ error: "A valid deal is required." }, { status: 400 });
    }

    const result = await scoreAuthorizedDeal(supabase, organization.id, body.deal_id);
    if (result.status === "not_found") return NextResponse.json({ error: "Deal not found." }, { status: 404 });
    if (result.status === "not_scorable") {
      return NextResponse.json({ error: "Only completed analyses can be scored." }, { status: 422 });
    }
    if (result.status === "failed") {
      return NextResponse.json({ error: "We couldn't calculate the Recovery Score right now." }, { status: 503 });
    }
    return NextResponse.json({ success: true, score: result.score, priority: result.priority });
  } catch {
    return NextResponse.json({ error: "We couldn't calculate the Recovery Score right now." }, { status: 500 });
  }
}

