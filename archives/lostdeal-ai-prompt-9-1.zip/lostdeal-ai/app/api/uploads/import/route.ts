import { NextResponse } from "next/server";

import { getActiveOrganization, getVerifiedIdentity } from "@/lib/auth/server";
import { DEAL_IMPORT_BATCH_SIZE } from "@/lib/csv/constants";
import { CsvImportError, validateCsvFormData } from "@/lib/csv/server";
import { createClient } from "@/lib/supabase/server";

function friendlyImportFailure(error: { code?: string; message?: string } | null): string {
  if (error?.code === "23505") {
    return "A deal ID was imported by another request. Review the CSV and try again.";
  }
  return "The database could not finish this import. No completion was reported.";
}

export async function POST(request: Request) {
  let uploadId: string | null = null;
  let insertedCount = 0;
  let importClient: Awaited<ReturnType<typeof createClient>> | null = null;

  try {
    const supabase = await createClient();
    importClient = supabase;
    const identity = await getVerifiedIdentity(supabase);
    if (!identity) {
      return NextResponse.json({ error: "Your session has expired. Log in and try again." }, { status: 401 });
    }
    const organization = await getActiveOrganization(supabase, identity.id);
    if (!organization) {
      return NextResponse.json({ error: "Complete workspace setup before importing deals." }, { status: 403 });
    }

    const result = await validateCsvFormData(await request.formData(), supabase, organization.id);
    const { validation } = result;
    if (!validation.validRows.length) {
      throw new CsvImportError("All rows are invalid. Correct the CSV before importing.", 422);
    }

    uploadId = crypto.randomUUID();
    const { error: pendingError } = await supabase.from("uploads").insert({
      id: uploadId,
      organization_id: organization.id,
      filename: result.filename,
      total_rows: validation.totalRows,
      valid_rows: validation.validRows.length,
      invalid_rows: validation.invalidRows.length,
      status: "pending",
      created_by: identity.id,
    });
    if (pendingError) {
      return NextResponse.json(
        { error: "LostDeal AI could not create the import record. Please try again." },
        { status: 503 },
      );
    }

    const { error: processingError } = await supabase
      .from("uploads")
      .update({ status: "processing" })
      .eq("id", uploadId)
      .eq("organization_id", organization.id);
    if (processingError) {
      await supabase
        .from("uploads")
        .update({ status: "failed", valid_rows: 0 })
        .eq("id", uploadId)
        .eq("organization_id", organization.id);
      return NextResponse.json(
        { error: "The import could not start. Its status was recorded as failed." },
        { status: 503 },
      );
    }

    for (let offset = 0; offset < validation.validRows.length; offset += DEAL_IMPORT_BATCH_SIZE) {
      const batch = validation.validRows.slice(offset, offset + DEAL_IMPORT_BATCH_SIZE).map((row) => ({
        id: crypto.randomUUID(),
        organization_id: organization.id,
        upload_id: uploadId,
        external_deal_id: row.external_deal_id,
        customer_name: row.customer_name,
        deal_value: row.deal_value,
        quote_date: row.quote_date,
        status: "lost",
        salesperson: row.salesperson,
        service_type: row.service_type,
        lead_source: row.lead_source,
        sales_notes: row.sales_notes,
        transcript: row.transcript,
        analysis_status: "pending",
        analysis_error: null,
      }));

      const { error: insertError } = await supabase.from("deals").insert(batch);
      if (insertError) {
        await supabase
          .from("uploads")
          .update({ status: "failed", valid_rows: insertedCount })
          .eq("id", uploadId)
          .eq("organization_id", organization.id);
        return NextResponse.json(
          {
            error: `${friendlyImportFailure(insertError)} ${insertedCount} of ${validation.validRows.length} deals were inserted before the failure.`,
            uploadId,
            insertedCount,
            status: "failed",
          },
          { status: insertError.code === "23505" ? 409 : 503 },
        );
      }
      insertedCount += batch.length;
    }

    const { error: completedError } = await supabase
      .from("uploads")
      .update({ status: "completed" })
      .eq("id", uploadId)
      .eq("organization_id", organization.id);
    if (completedError) {
      await supabase
        .from("uploads")
        .update({ status: "failed", valid_rows: insertedCount })
        .eq("id", uploadId)
        .eq("organization_id", organization.id);
      return NextResponse.json(
        {
          error: `${insertedCount} deals were inserted, but final status verification failed. The import is marked failed for review.`,
          uploadId,
          insertedCount,
          status: "failed",
        },
        { status: 503 },
      );
    }

    return NextResponse.json({
      success: true,
      uploadId,
      filename: result.filename,
      organizationName: organization.name,
      totalRows: validation.totalRows,
      insertedCount,
      invalidRows: validation.invalidRows.length,
      status: "completed",
      createdAt: new Date().toISOString(),
    });
  } catch (error) {
    if (uploadId && importClient) {
      await importClient
        .from("uploads")
        .update({ status: "failed", valid_rows: insertedCount })
        .eq("id", uploadId);
    }
    if (error instanceof CsvImportError) {
      return NextResponse.json({ error: error.message }, { status: error.status });
    }
    return NextResponse.json(
      {
        error: uploadId
          ? `The import failed after ${insertedCount} deals. Its status was recorded for review.`
          : "LostDeal AI could not import this CSV. Please try again.",
      },
      { status: 500 },
    );
  }
}
