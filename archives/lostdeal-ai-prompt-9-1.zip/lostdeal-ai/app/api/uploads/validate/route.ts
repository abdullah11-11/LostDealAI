import { NextResponse } from "next/server";

import { getActiveOrganization, getVerifiedIdentity } from "@/lib/auth/server";
import {
  CsvImportError,
  toCsvValidationResponse,
  validateCsvFormData,
} from "@/lib/csv/server";
import { createClient } from "@/lib/supabase/server";

export async function POST(request: Request) {
  try {
    const supabase = await createClient();
    const identity = await getVerifiedIdentity(supabase);
    if (!identity) {
      return NextResponse.json({ error: "Your session has expired. Log in and try again." }, { status: 401 });
    }
    const organization = await getActiveOrganization(supabase, identity.id);
    if (!organization) {
      return NextResponse.json({ error: "Complete workspace setup before importing deals." }, { status: 403 });
    }

    const result = await validateCsvFormData(await request.formData(), supabase, organization.id);
    return NextResponse.json({ validation: toCsvValidationResponse(result) });
  } catch (error) {
    if (error instanceof CsvImportError) {
      return NextResponse.json({ error: error.message }, { status: error.status });
    }
    return NextResponse.json(
      { error: "LostDeal AI could not validate this CSV. Please try again." },
      { status: 500 },
    );
  }
}

