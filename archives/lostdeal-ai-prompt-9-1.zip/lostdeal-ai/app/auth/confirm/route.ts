import type { EmailOtpType } from "@supabase/supabase-js";
import { type NextRequest, NextResponse } from "next/server";

import { getActiveOrganization, getVerifiedIdentity } from "@/lib/auth/server";
import { createClient } from "@/lib/supabase/server";

const EMAIL_OTP_TYPES = new Set<EmailOtpType>([
  "email",
  "signup",
  "invite",
  "magiclink",
  "recovery",
  "email_change",
]);

export async function GET(request: NextRequest) {
  const tokenHash = request.nextUrl.searchParams.get("token_hash");
  const requestedType = request.nextUrl.searchParams.get("type");

  if (!tokenHash || !requestedType || !EMAIL_OTP_TYPES.has(requestedType as EmailOtpType)) {
    return NextResponse.redirect(new URL("/auth/error", request.url));
  }

  const supabase = await createClient();
  const { error } = await supabase.auth.verifyOtp({
    token_hash: tokenHash,
    type: requestedType as EmailOtpType,
  });

  if (error) return NextResponse.redirect(new URL("/auth/error", request.url));

  const identity = await getVerifiedIdentity(supabase);
  if (!identity) return NextResponse.redirect(new URL("/auth/error", request.url));

  try {
    const organization = await getActiveOrganization(supabase, identity.id);
    return NextResponse.redirect(new URL(organization ? "/dashboard" : "/onboarding", request.url));
  } catch {
    return NextResponse.redirect(new URL("/auth/error", request.url));
  }
}
