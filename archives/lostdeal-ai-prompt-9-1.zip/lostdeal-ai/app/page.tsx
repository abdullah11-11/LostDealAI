import Link from "next/link";
import { BrandLogo } from "@/components/brand-logo";

const steps = [
  ["01", "Bring in lost opportunities", "Start with the sales records your team already has. The real import flow arrives in a later milestone."],
  ["02", "Understand what went wrong", "Organize the evidence, buying signals, and likely reasons behind each lost sale."],
  ["03", "Focus recovery effort", "See the opportunities most worth revisiting and the next action your team should take."],
];

const previewDeals = [
  ["Deal #1042", "Timing", "87/100", "bg-emerald-500"],
  ["Deal #1037", "No follow-up", "74/100", "bg-amber-500"],
  ["Deal #1019", "Price", "61/100", "bg-slate-400"],
];

export default function Home() {
  return (
    <main className="min-h-screen bg-[#f7f8fb] text-slate-950">
      <header className="border-b border-slate-200 bg-white">
        <div className="mx-auto flex h-18 max-w-7xl items-center justify-between px-5 sm:px-8 lg:px-10">
          <BrandLogo />
          <nav aria-label="Primary navigation" className="flex items-center gap-2">
            <Link href="/login" className="hidden rounded-lg px-3 py-2 text-sm font-semibold text-slate-600 hover:text-slate-950 sm:inline-flex">Log in</Link>
            <Link href="/signup" className="inline-flex h-10 items-center rounded-lg bg-[#172554] px-4 text-sm font-bold text-white hover:bg-[#1e3a8a]">Get started <span className="ml-2">→</span></Link>
          </nav>
        </div>
      </header>

      <section className="relative overflow-hidden border-b border-slate-200 bg-white">
        <div className="pointer-events-none absolute -right-44 -top-48 size-[40rem] rounded-full bg-blue-50" />
        <div className="relative mx-auto grid max-w-7xl gap-14 px-5 py-20 sm:px-8 sm:py-24 lg:grid-cols-[1.05fr_0.95fr] lg:items-center lg:px-10 lg:py-28">
          <div>
            <p className="inline-flex rounded-full border border-blue-200 bg-blue-50 px-3 py-1.5 text-xs font-bold uppercase tracking-[0.14em] text-blue-800">Recovery intelligence for sales teams</p>
            <h1 className="mt-7 max-w-3xl text-balance text-5xl font-semibold leading-[1.04] tracking-[-0.045em] text-[#0b1739] sm:text-6xl lg:text-7xl">Recover the customers you almost had.</h1>
            <p className="mt-7 max-w-2xl text-pretty text-lg leading-8 text-slate-600 sm:text-xl">Upload lost sales, uncover why they didn&apos;t close, and discover which opportunities are most worth recovering.</p>
            <div className="mt-9 flex flex-col gap-3 sm:flex-row">
              <Link href="/upload" className="inline-flex h-12 items-center justify-center rounded-xl bg-[#2952cc] px-6 text-sm font-bold text-white shadow-[0_12px_30px_rgba(41,82,204,0.22)] hover:bg-[#2347b3]">Analyze My Lost Deals <span className="ml-2">→</span></Link>
              <Link href="/dashboard" className="inline-flex h-12 items-center justify-center rounded-xl border border-slate-300 bg-white px-6 text-sm font-bold text-slate-800 hover:bg-slate-50">Preview the dashboard</Link>
            </div>
            <div className="mt-10 grid max-w-2xl gap-3 text-sm text-slate-600 sm:grid-cols-3">
              {["Lost-reason clarity", "Evidence-led scores", "Next-step guidance"].map((item) => <p key={item} className="flex items-center gap-2"><span className="flex size-5 items-center justify-center rounded-full bg-emerald-50 text-xs font-black text-emerald-700">✓</span>{item}</p>)}
            </div>
          </div>

          <div className="relative mx-auto w-full max-w-2xl">
            <div className="absolute -inset-5 rounded-[2rem] border border-blue-100 bg-blue-50/70" />
            <div className="relative overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-[0_32px_80px_rgba(15,23,42,0.14)]">
              <div className="flex items-center justify-between border-b border-slate-200 px-5 py-4"><div><p className="text-sm font-bold text-slate-900">Recovery queue</p><p className="mt-0.5 text-xs text-slate-500">Illustrative product preview</p></div><span className="rounded-lg bg-slate-100 px-3 py-2 text-xs font-semibold text-slate-600">Ranked by score</span></div>
              <div className="grid grid-cols-3 gap-px border-b border-slate-200 bg-slate-200">
                {[["Open opportunities", "24"], ["High priority", "8"], ["Average score", "72"]].map(([label, value]) => <div key={label} className="bg-slate-50 px-4 py-4 sm:px-5"><p className="text-[10px] font-bold uppercase tracking-wide text-slate-500">{label}</p><p className="mt-1 text-2xl font-semibold tracking-tight text-[#0b1739]">{value}</p></div>)}
              </div>
              <div className="p-3 sm:p-4">
                <div className="grid grid-cols-[1fr_auto] px-3 py-2 text-[10px] font-bold uppercase tracking-[0.12em] text-slate-400 sm:grid-cols-[1fr_8rem_6rem]"><span>Opportunity</span><span className="hidden sm:block">Lost reason</span><span>Recovery</span></div>
                <div className="space-y-2">{previewDeals.map(([deal, reason, score, tone]) => <div key={deal} className="grid grid-cols-[1fr_auto] items-center gap-4 rounded-xl border border-slate-200 px-3 py-3 sm:grid-cols-[1fr_8rem_6rem]"><div><p className="text-sm font-bold text-slate-800">{deal}</p><p className="mt-0.5 text-xs text-slate-500">Evidence ready for review</p></div><p className="hidden text-xs font-semibold text-slate-600 sm:block">{reason}</p><p className="flex items-center justify-end gap-2 text-sm font-bold text-slate-800"><span className={`size-2 rounded-full ${tone}`} />{score}</p></div>)}</div>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className="mx-auto max-w-7xl px-5 py-20 sm:px-8 lg:px-10 lg:py-24">
        <div className="max-w-2xl"><p className="text-sm font-bold uppercase tracking-[0.16em] text-[#2952cc]">A clearer recovery workflow</p><h2 className="mt-4 text-3xl font-semibold tracking-tight text-[#0b1739] sm:text-4xl">Turn closed-lost history into the next best conversation.</h2><p className="mt-4 leading-7 text-slate-600">Bring the key recovery decisions into one focused workspace, so your team can spend less time reviewing old notes and more time acting.</p></div>
        <div className="mt-12 grid gap-5 lg:grid-cols-3">{steps.map(([number, title, description]) => <article key={number} className="rounded-2xl border border-slate-200 bg-white p-6 shadow-sm"><div className="flex items-center justify-between"><span className="flex size-11 items-center justify-center rounded-xl bg-blue-50 text-sm font-black text-[#2952cc]">{number}</span><span className="size-2 rounded-full bg-blue-200" /></div><h3 className="mt-7 text-xl font-semibold tracking-tight text-slate-900">{title}</h3><p className="mt-3 text-sm leading-7 text-slate-600">{description}</p></article>)}</div>
      </section>

      <section className="border-y border-slate-200 bg-[#0b1739] text-white"><div className="mx-auto grid max-w-7xl gap-10 px-5 py-16 sm:px-8 lg:grid-cols-[0.9fr_1.1fr] lg:items-center lg:px-10 lg:py-20"><div><p className="text-sm font-bold uppercase tracking-[0.16em] text-blue-300">Designed for responsible analysis</p><h2 className="mt-4 text-3xl font-semibold tracking-tight sm:text-4xl">Evidence first. Clear scores. Practical next steps.</h2></div><div className="grid gap-4 sm:grid-cols-2">{[["Grounded findings", "Conclusions stay tied to supplied sales evidence."], ["Transparent scoring", "Recovery and intent are scores out of 100, not guarantees."], ["Actionable guidance", "Each opportunity leads toward a clear next action."], ["Focused prioritization", "Ranked deals show where recovery effort belongs."]].map(([title, description]) => <div key={title} className="rounded-xl border border-white/10 bg-white/[0.06] p-5"><span className="block size-2 rounded-full bg-blue-300" /><h3 className="mt-4 text-sm font-bold">{title}</h3><p className="mt-2 text-sm leading-6 text-slate-300">{description}</p></div>)}</div></div></section>

      <section className="mx-auto max-w-4xl px-5 py-20 text-center sm:px-8 lg:py-24"><h2 className="text-3xl font-semibold tracking-tight text-[#0b1739] sm:text-4xl">Your lost pipeline still has useful signals.</h2><p className="mx-auto mt-4 max-w-2xl leading-7 text-slate-600">Bring those signals together and make the next recovery decision with more clarity.</p><Link href="/signup" className="mt-8 inline-flex h-12 items-center rounded-xl bg-[#2952cc] px-6 text-sm font-bold text-white hover:bg-[#2347b3]">Start with LostDeal AI <span className="ml-2">→</span></Link></section>
      <footer className="border-t border-slate-200 bg-white"><div className="mx-auto flex max-w-7xl flex-col gap-4 px-5 py-7 text-sm text-slate-500 sm:flex-row sm:items-center sm:justify-between sm:px-8 lg:px-10"><BrandLogo /><p>© 2026 LostDeal AI. Product interface preview.</p></div></footer>
    </main>
  );
}
