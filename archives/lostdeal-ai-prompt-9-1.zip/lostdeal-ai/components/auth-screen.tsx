"use client";

import { useActionState } from "react";
import Link from "next/link";
import { ArrowLeft, BarChart3, LockKeyhole } from "lucide-react";

import { loginAction, signupAction } from "@/app/actions/auth";
import { BrandLogo } from "@/components/brand-logo";
import { Badge, Button, Input } from "@/components/ui";
import type { FormActionState } from "@/lib/auth/validation";

const INITIAL_STATE: FormActionState = {};

export function AuthScreen({
  mode,
  nextPath,
}: {
  mode: "login" | "signup";
  nextPath?: string;
}) {
  const login = mode === "login";
  const action = login ? loginAction : signupAction;
  const [state, formAction, pending] = useActionState(action, INITIAL_STATE);

  return (
    <main className="grid min-h-screen bg-white lg:grid-cols-[0.9fr_1.1fr]">
      <section className="relative hidden overflow-hidden bg-[#0b1739] px-12 py-10 text-white lg:flex lg:flex-col lg:justify-between">
        <div className="absolute -right-24 top-24 size-80 rounded-full border border-white/10" />
        <BrandLogo inverted />
        <div className="relative max-w-lg pb-10">
          <div className="flex size-12 items-center justify-center rounded-2xl border border-white/10 bg-white/[0.07] text-blue-300">
            <BarChart3 aria-hidden="true" className="size-6" />
          </div>
          <p className="mt-8 text-sm font-bold uppercase tracking-[0.18em] text-blue-300">Lost opportunity intelligence</p>
          <h1 className="mt-5 text-5xl font-semibold leading-tight tracking-[-0.04em]">Every lost deal can teach your team what to do next.</h1>
          <p className="mt-6 max-w-md leading-7 text-slate-300">Secure access keeps every workspace and its recovery opportunities separate.</p>
        </div>
        <p className="text-xs text-slate-400">LostDeal AI · Secure workspace access</p>
      </section>

      <section className="flex min-h-screen flex-col px-5 py-6 sm:px-10 lg:px-16">
        <div className="flex items-center justify-between lg:justify-end">
          <div className="lg:hidden"><BrandLogo /></div>
          <Link href="/" className="inline-flex items-center gap-2 rounded-lg px-3 py-2 text-sm font-semibold text-slate-500 hover:bg-slate-50 hover:text-slate-900">
            <ArrowLeft aria-hidden="true" className="size-4" /> Back to home
          </Link>
        </div>

        <div className="mx-auto flex w-full max-w-md flex-1 flex-col justify-center py-12">
          <Badge tone="neutral">Secure account access</Badge>
          <p className="mt-7 text-sm font-bold uppercase tracking-[0.15em] text-[#2952cc]">{login ? "Welcome back" : "Create your workspace"}</p>
          <h1 className="mt-3 text-3xl font-semibold tracking-tight text-[#0b1739]">{login ? "Log in to LostDeal AI" : "Start with LostDeal AI"}</h1>
          <p className="mt-3 text-sm leading-6 text-slate-500">
            {login
              ? "Continue to your organization’s recovery workspace."
              : "Create your account, then tell us a little about your business."}
          </p>

          {state.formError && (
            <div role="alert" className="mt-6 rounded-xl border border-red-200 bg-red-50 px-4 py-3 text-sm leading-6 text-red-700">
              {state.formError}
            </div>
          )}

          <form action={formAction} className="mt-8 space-y-5" aria-label={login ? "Log in" : "Create account"}>
            {login && <input type="hidden" name="next" value={nextPath ?? "/dashboard"} />}
            {!login && (
              <Input
                id="fullName"
                name="fullName"
                label="Full name"
                type="text"
                placeholder="Your name"
                autoComplete="name"
                maxLength={100}
                required
                disabled={pending}
                error={state.fieldErrors?.fullName}
              />
            )}
            <Input
              id="email"
              name="email"
              label="Business email"
              type="email"
              placeholder="you@company.com"
              autoComplete="email"
              inputMode="email"
              maxLength={254}
              required
              disabled={pending}
              error={state.fieldErrors?.email}
            />
            <Input
              id="password"
              name="password"
              label="Password"
              type="password"
              placeholder="••••••••"
              autoComplete={login ? "current-password" : "new-password"}
              minLength={login ? undefined : 8}
              maxLength={128}
              required
              disabled={pending}
              description={login ? undefined : "Use at least 8 characters."}
              error={state.fieldErrors?.password}
            />
            <Button type="submit" loading={pending} className="h-11 w-full">
              {pending ? (login ? "Logging in…" : "Creating account…") : (login ? "Log In" : "Create Account")}
            </Button>
          </form>

          <p className="mt-4 flex gap-2 rounded-xl border border-blue-200 bg-blue-50 px-4 py-3 text-xs leading-5 text-blue-900">
            <LockKeyhole aria-hidden="true" className="mt-0.5 size-4 shrink-0" />
            Your password is handled securely by Supabase Auth and is never stored in LostDeal AI business tables.
          </p>
          <p className="mt-7 text-center text-sm text-slate-500">
            {login ? "New to LostDeal AI?" : "Already have an account?"}{" "}
            <Link href={login ? "/signup" : "/login"} className="font-bold text-[#2952cc] hover:underline">{login ? "Create account" : "Log in"}</Link>
          </p>
        </div>
      </section>
    </main>
  );
}
