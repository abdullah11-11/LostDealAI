import Link from "next/link";

export function BrandLogo({ compact = false, inverted = false }: { compact?: boolean; inverted?: boolean }) {
  return <Link href="/" aria-label="LostDeal AI home" className="inline-flex items-center gap-2.5 rounded-md focus-visible:outline-2 focus-visible:outline-offset-4 focus-visible:outline-blue-500"><span className={`flex size-9 items-center justify-center rounded-xl text-[11px] font-black shadow-sm ${inverted ? "bg-white text-[#172554]" : "bg-[#172554] text-white"}`}>LD</span>{!compact && <span className={`text-[15px] font-extrabold tracking-tight ${inverted ? "text-white" : "text-[#0b1739]"}`}>LostDeal <span className={inverted ? "text-blue-300" : "text-[#2952cc]"}>AI</span></span>}</Link>;
}
