"use client";

import Link from "next/link";
import { useRef, useState } from "react";
import {
  AlertCircle,
  ArrowLeft,
  ArrowRight,
  Check,
  CheckCircle2,
  Download,
  FileCheck2,
  FileSpreadsheet,
  Info,
  RefreshCw,
  UploadCloud,
  X,
} from "lucide-react";

import { Badge, Button, Card, Select, Table, buttonStyles } from "@/components/ui";
import {
  CANONICAL_FIELDS,
  FIELD_DETAILS,
  MAX_CSV_FILE_BYTES,
  MAX_CSV_ROWS,
  type CanonicalField,
} from "@/lib/csv/constants";
import {
  autoMapColumns,
  validateColumnMapping,
  type ColumnMapping,
} from "@/lib/csv/mapping";
import {
  parseCsvText,
  validateCsvFileMetadata,
  validateParsedCsvShape,
  type ParsedCsv,
} from "@/lib/csv/validation";

export type RecentImport = {
  id: string;
  filename: string;
  createdAt: string;
  rowsImported: number;
  status: "pending" | "processing" | "completed" | "failed";
};

type ValidationSummary = {
  totalRows: number;
  validRows: number;
  invalidRows: number;
  blankRows: number;
  malformedRows: number;
  invalid: Array<{
    rowNumber: number;
    customer: string | null;
    externalDealId: string | null;
    errors: string[];
  }>;
  preview: Array<{
    rowNumber: number;
    customer_name: string | null;
    deal_value: string;
    quote_date: string | null;
    service_type: string | null;
    salesperson: string | null;
    context: string;
  }>;
};

type ImportResult = {
  uploadId: string;
  filename: string;
  organizationName: string;
  insertedCount: number;
  invalidRows: number;
  createdAt: string;
};

type Stage = "select" | "mapping" | "review" | "success";

const STEP_LABELS: Array<{ key: Exclude<Stage, "success">; label: string }> = [
  { key: "select", label: "Select file" },
  { key: "mapping", label: "Map columns" },
  { key: "review", label: "Review & import" },
];

function stageIndex(stage: Stage): number {
  if (stage === "success") return 3;
  return STEP_LABELS.findIndex((step) => step.key === stage);
}

function formatBytes(bytes: number): string {
  if (bytes < 1024) return `${bytes} bytes`;
  return `${(bytes / 1024).toFixed(bytes < 1024 * 100 ? 1 : 0)} KB`;
}

function formatCurrency(value: string): string {
  return new Intl.NumberFormat("en-US", { style: "currency", currency: "USD" }).format(Number(value));
}

function formatDate(value: string): string {
  return new Intl.DateTimeFormat("en-US", {
    dateStyle: "medium",
    timeZone: "UTC",
  }).format(new Date(value));
}

function statusTone(status: RecentImport["status"]): "pending" | "completed" | "failed" {
  if (status === "completed") return "completed";
  if (status === "failed") return "failed";
  return "pending";
}

async function responseJson(response: Response): Promise<Record<string, unknown>> {
  try {
    return (await response.json()) as Record<string, unknown>;
  } catch {
    return {};
  }
}

export function CsvImportWorkflow({
  organizationName,
  recentImports,
  recentImportsUnavailable,
}: {
  organizationName: string;
  recentImports: RecentImport[];
  recentImportsUnavailable?: boolean;
}) {
  const inputRef = useRef<HTMLInputElement>(null);
  const [stage, setStage] = useState<Stage>("select");
  const [file, setFile] = useState<File | null>(null);
  const [parsed, setParsed] = useState<ParsedCsv | null>(null);
  const [mapping, setMapping] = useState<ColumnMapping | null>(null);
  const [validation, setValidation] = useState<ValidationSummary | null>(null);
  const [result, setResult] = useState<ImportResult | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [mappingError, setMappingError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const [dragging, setDragging] = useState(false);
  const [imports, setImports] = useState(recentImports);

  const currentStep = stageIndex(stage);

  function resetImport() {
    setStage("select");
    setFile(null);
    setParsed(null);
    setMapping(null);
    setValidation(null);
    setResult(null);
    setError(null);
    setMappingError(null);
    if (inputRef.current) inputRef.current.value = "";
  }

  async function selectFile(selectedFile: File | null) {
    setError(null);
    setMappingError(null);
    setValidation(null);
    if (!selectedFile) {
      setError("Choose a CSV file to continue.");
      return;
    }

    const metadataError = validateCsvFileMetadata(selectedFile);
    if (metadataError) {
      setError(metadataError);
      return;
    }

    try {
      const csv = parseCsvText(await selectedFile.text());
      const shapeError = validateParsedCsvShape(csv);
      if (shapeError) {
        setError(shapeError);
        return;
      }
      setFile(selectedFile);
      setParsed(csv);
      setMapping(autoMapColumns(csv.headers));
      setStage("mapping");
    } catch {
      setError("LostDeal AI could not read this CSV. Confirm it is valid UTF-8 text and try again.");
    }
  }

  function updateMapping(field: CanonicalField, rawValue: string) {
    if (!mapping) return;
    const nextIndex = rawValue === "" ? null : Number(rawValue);
    if (nextIndex !== null) {
      const duplicate = CANONICAL_FIELDS.find(
        (candidate) => candidate !== field && mapping[candidate] === nextIndex,
      );
      if (duplicate) {
        setMappingError(
          `${parsed?.headers[nextIndex] ?? "That column"} is already mapped to ${FIELD_DETAILS[duplicate].label}. Choose a different CSV column.`,
        );
        return;
      }
    }
    setMapping({ ...mapping, [field]: nextIndex });
    setMappingError(null);
  }

  async function reviewFile() {
    if (!file || !parsed || !mapping) return;
    const errors = validateColumnMapping(mapping, parsed.headers.length);
    if (errors.length) {
      setMappingError(errors.join(" "));
      return;
    }

    setBusy(true);
    setError(null);
    setMappingError(null);
    const formData = new FormData();
    formData.append("file", file);
    formData.append("mapping", JSON.stringify(mapping));

    try {
      const response = await fetch("/api/uploads/validate", { method: "POST", body: formData });
      const body = await responseJson(response);
      if (!response.ok || !body.validation) {
        throw new Error(typeof body.error === "string" ? body.error : "CSV validation failed.");
      }
      setValidation(body.validation as ValidationSummary);
      setStage("review");
    } catch (requestError) {
      setError(requestError instanceof Error ? requestError.message : "CSV validation failed.");
    } finally {
      setBusy(false);
    }
  }

  async function importDeals() {
    if (!file || !mapping || !validation?.validRows || busy) return;
    setBusy(true);
    setError(null);
    const formData = new FormData();
    formData.append("file", file);
    formData.append("mapping", JSON.stringify(mapping));

    try {
      const response = await fetch("/api/uploads/import", { method: "POST", body: formData });
      const body = await responseJson(response);
      if (!response.ok || !body.success) {
        throw new Error(typeof body.error === "string" ? body.error : "The import could not be completed.");
      }
      const nextResult = body as unknown as ImportResult;
      setResult(nextResult);
      setImports((current) => [
        {
          id: nextResult.uploadId,
          filename: nextResult.filename,
          createdAt: nextResult.createdAt,
          rowsImported: nextResult.insertedCount,
          status: "completed" as const,
        },
        ...current,
      ].slice(0, 6));
      setStage("success");
    } catch (requestError) {
      setError(requestError instanceof Error ? requestError.message : "The import could not be completed.");
    } finally {
      setBusy(false);
    }
  }

  return (
    <div>
      <ol aria-label="CSV import progress" className="grid gap-2 sm:grid-cols-3">
        {STEP_LABELS.map((step, index) => {
          const complete = currentStep > index;
          const active = currentStep === index;
          return (
            <li
              key={step.key}
              aria-current={active ? "step" : undefined}
              className={`flex items-center gap-3 rounded-xl border px-4 py-3 text-sm font-bold ${active ? "border-blue-300 bg-blue-50 text-blue-800" : complete ? "border-emerald-200 bg-emerald-50 text-emerald-800" : "border-slate-200 bg-white text-slate-500"}`}
            >
              <span className={`flex size-7 shrink-0 items-center justify-center rounded-full text-xs ${active ? "bg-[#2952cc] text-white" : complete ? "bg-emerald-600 text-white" : "bg-slate-100 text-slate-500"}`}>
                {complete ? <Check aria-hidden="true" className="size-3.5" /> : index + 1}
              </span>
              {step.label}
            </li>
          );
        })}
      </ol>

      <div aria-live="polite" className="mt-5 min-h-0">
        {error && (
          <div role="alert" className="flex gap-3 rounded-xl border border-red-200 bg-red-50 px-4 py-3 text-sm leading-6 text-red-700">
            <AlertCircle aria-hidden="true" className="mt-1 size-4 shrink-0" />
            <span>{error}</span>
          </div>
        )}
      </div>

      {stage === "select" && (
        <section className="mt-5 grid gap-5 lg:grid-cols-[1.35fr_0.65fr]">
          <Card>
            <div className="p-5 sm:p-6">
              <div
                onDragEnter={(event) => { event.preventDefault(); setDragging(true); }}
                onDragOver={(event) => { event.preventDefault(); setDragging(true); }}
                onDragLeave={(event) => { event.preventDefault(); setDragging(false); }}
                onDrop={(event) => {
                  event.preventDefault();
                  setDragging(false);
                  void selectFile(event.dataTransfer.files.item(0));
                }}
                className={`flex min-h-[25rem] flex-col items-center justify-center rounded-2xl border-2 border-dashed px-6 text-center transition ${dragging ? "border-[#2952cc] bg-blue-100" : "border-blue-200 bg-blue-50/50"}`}
              >
                <span className="flex size-16 items-center justify-center rounded-2xl bg-white text-[#2952cc] shadow-sm">
                  <UploadCloud aria-hidden="true" className="size-7" />
                </span>
                <h2 className="mt-6 text-xl font-bold text-slate-950">Drop your lost-deals CSV here</h2>
                <p className="mt-2 max-w-lg text-sm leading-6 text-slate-600">
                  Upload a CSV containing lost sales opportunities, sales notes, or conversation transcripts.
                </p>
                <input
                  ref={inputRef}
                  id="csv-file"
                  type="file"
                  accept=".csv,text/csv"
                  className="sr-only"
                  onChange={(event) => void selectFile(event.target.files?.item(0) ?? null)}
                />
                <label htmlFor="csv-file" className={buttonStyles("primary", "mt-6")}>Choose CSV</label>
                <div className="mt-5 flex flex-wrap justify-center gap-2">
                  <Badge tone="neutral">CSV only</Badge>
                  <Badge tone="neutral">Maximum {MAX_CSV_FILE_BYTES / 1024 / 1024} MB</Badge>
                  <Badge tone="neutral">Maximum {MAX_CSV_ROWS.toLocaleString()} deals</Badge>
                </div>
              </div>
            </div>
          </Card>

          <aside className="space-y-5">
            <Card title="Prepare your file" description="Only deal context is needed—no contact details required.">
              <ul className="space-y-4 p-5 sm:p-6">
                {[
                  "One lost opportunity per row",
                  "Include a deal value for every row",
                  "Add sales notes or a transcript",
                  "Use ISO dates such as 2026-08-14",
                ].map((item) => (
                  <li key={item} className="flex gap-3 text-sm leading-6 text-slate-700">
                    <CheckCircle2 aria-hidden="true" className="mt-0.5 size-4 shrink-0 text-emerald-600" />
                    {item}
                  </li>
                ))}
              </ul>
            </Card>
            <Card>
              <div className="p-5 sm:p-6">
                <div className="flex items-start gap-3">
                  <span className="flex size-10 shrink-0 items-center justify-center rounded-xl bg-slate-100 text-slate-600"><FileSpreadsheet aria-hidden="true" className="size-5" /></span>
                  <div>
                    <h2 className="text-sm font-bold text-slate-900">Need a starting point?</h2>
                    <p className="mt-1 text-xs leading-5 text-slate-500">Download 10 explicitly synthetic HVAC examples.</p>
                  </div>
                </div>
                <a href="/sample-lost-deals.csv" download className={buttonStyles("outline", "mt-5 w-full")}>
                  <Download aria-hidden="true" className="size-4" /> Download Sample CSV
                </a>
              </div>
            </Card>
            <div className="flex gap-3 rounded-2xl border border-blue-200 bg-blue-50 p-5 text-sm leading-6 text-blue-900">
              <Info aria-hidden="true" className="mt-0.5 size-4 shrink-0" />
              Uploaded values are treated as plain text. LostDeal AI never executes spreadsheet formulas.
            </div>
          </aside>
        </section>
      )}

      {stage === "mapping" && file && parsed && mapping && (
        <section className="mt-5">
          <Card
            title="Map your columns"
            description="Tell LostDeal AI which columns in your CSV correspond to each field. Deterministic suggestions are selected where names match."
            action={<Badge tone="completed">{parsed.rows.length.toLocaleString()} rows detected</Badge>}
          >
            <div className="border-b border-slate-100 px-5 py-4 sm:px-6">
              <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
                <div className="min-w-0">
                  <p className="truncate text-sm font-bold text-slate-900">{file.name}</p>
                  <p className="mt-1 text-xs text-slate-500">{formatBytes(file.size)} · {parsed.headers.length} columns · {parsed.blankRows} blank rows ignored</p>
                </div>
                <Button type="button" variant="ghost" onClick={resetImport}><X aria-hidden="true" className="size-4" />Choose another file</Button>
              </div>
            </div>
            <div className="grid gap-x-5 gap-y-6 p-5 sm:grid-cols-2 sm:p-6">
              {CANONICAL_FIELDS.map((field) => (
                <Select
                  key={field}
                  id={`mapping-${field}`}
                  label={`${FIELD_DETAILS[field].label}${FIELD_DETAILS[field].required ? " *" : ""}`}
                  description={FIELD_DETAILS[field].description}
                  value={mapping[field] ?? ""}
                  onChange={(event) => updateMapping(field, event.target.value)}
                >
                  <option value="">Not mapped</option>
                  {parsed.headers.map((header, index) => (
                    <option key={`${header}-${index}`} value={index}>{header || `Column ${index + 1}`}</option>
                  ))}
                </Select>
              ))}
            </div>
            {mappingError && (
              <div role="alert" className="mx-5 mb-5 flex gap-3 rounded-xl border border-red-200 bg-red-50 px-4 py-3 text-sm leading-6 text-red-700 sm:mx-6 sm:mb-6">
                <AlertCircle aria-hidden="true" className="mt-1 size-4 shrink-0" />{mappingError}
              </div>
            )}
            <div className="flex flex-col-reverse gap-3 border-t border-slate-100 px-5 py-5 sm:flex-row sm:justify-between sm:px-6">
              <Button type="button" variant="outline" onClick={resetImport}><ArrowLeft aria-hidden="true" className="size-4" />Back</Button>
              <Button type="button" loading={busy} onClick={() => void reviewFile()}>
                {busy ? "Validating on server…" : "Validate & review"}<ArrowRight aria-hidden="true" className="size-4" />
              </Button>
            </div>
          </Card>
        </section>
      )}

      {stage === "review" && file && parsed && mapping && validation && (
        <section className="mt-5 space-y-5">
          <div className="grid gap-4 sm:grid-cols-3">
            {[
              { label: "Total rows", value: validation.totalRows, color: "text-slate-950" },
              { label: "Valid", value: validation.validRows, color: "text-emerald-700" },
              { label: "Invalid", value: validation.invalidRows, color: "text-red-700" },
            ].map((item) => (
              <Card key={item.label}>
                <div className="p-5">
                  <p className="text-xs font-bold uppercase tracking-[0.12em] text-slate-500">{item.label}</p>
                  <p className={`mt-3 text-3xl font-semibold tracking-tight ${item.color}`}>{item.value.toLocaleString()}</p>
                </div>
              </Card>
            ))}
          </div>

          {validation.invalidRows > 0 && (
            <Card
              title="Invalid row review"
              description={`${validation.invalidRows.toLocaleString()} invalid ${validation.invalidRows === 1 ? "row will" : "rows will"} be skipped. Correct the source file and restart if you want to include them.`}
              action={<Badge tone="failed">Skipped</Badge>}
            >
              <div className="max-h-80 divide-y divide-slate-100 overflow-y-auto">
                {validation.invalid.map((row) => (
                  <div key={row.rowNumber} className="grid gap-2 px-5 py-4 sm:grid-cols-[7rem_1fr_2fr] sm:px-6">
                    <p className="text-sm font-bold text-slate-900">Row {row.rowNumber}</p>
                    <p className="text-sm text-slate-600">{row.customer || row.externalDealId || "Unnamed deal"}</p>
                    <ul className="space-y-1 text-sm text-red-700">
                      {row.errors.map((rowError) => <li key={rowError}>{rowError}</li>)}
                    </ul>
                  </div>
                ))}
              </div>
            </Card>
          )}

          <Card
            title="Normalized preview"
            description={`First ${validation.preview.length} valid ${validation.preview.length === 1 ? "row" : "rows"}. Full transcripts are intentionally not shown.`}
          >
            {validation.preview.length ? (
              <Table label="Normalized deal preview" headers={["Customer", "Deal value", "Quote date", "Service", "Salesperson", "Notes / transcript"]}>
                {validation.preview.map((row) => (
                  <tr key={row.rowNumber} className="text-sm text-slate-700">
                    <td className="px-5 py-4 font-bold text-slate-900">{row.customer_name || "Unnamed deal"}</td>
                    <td className="px-5 py-4">{formatCurrency(row.deal_value)}</td>
                    <td className="px-5 py-4">{row.quote_date || "—"}</td>
                    <td className="px-5 py-4">{row.service_type || "—"}</td>
                    <td className="px-5 py-4">{row.salesperson || "—"}</td>
                    <td className="max-w-xs px-5 py-4 text-xs leading-5 text-slate-500">{row.context}</td>
                  </tr>
                ))}
              </Table>
            ) : (
              <div className="p-6 text-sm text-slate-600">No valid rows are available to preview.</div>
            )}
          </Card>

          <Card>
            <div className="p-5 sm:p-6">
              <div className="flex flex-col gap-5 lg:flex-row lg:items-center lg:justify-between">
                <div>
                  <Badge tone="pending">Final confirmation</Badge>
                  <h2 className="mt-3 text-lg font-bold text-slate-950">Import into {organizationName}</h2>
                  <p className="mt-1 text-sm leading-6 text-slate-600">
                    <span className="font-semibold text-slate-900">{validation.validRows.toLocaleString()} valid deals</span> will be imported from {file.name}. {validation.invalidRows.toLocaleString()} invalid {validation.invalidRows === 1 ? "row" : "rows"} will be skipped.
                  </p>
                  <p className="mt-2 text-xs leading-5 text-slate-500">The server will reparse and revalidate the original file before any insert. AI analysis will not start.</p>
                </div>
                <div className="flex flex-col-reverse gap-3 sm:flex-row lg:shrink-0">
                  <Button type="button" variant="outline" disabled={busy} onClick={() => { setStage("mapping"); setError(null); }}><ArrowLeft aria-hidden="true" className="size-4" />Back to mapping</Button>
                  <Button type="button" loading={busy} disabled={!validation.validRows} onClick={() => void importDeals()}>
                    <UploadCloud aria-hidden="true" className="size-4" />
                    {busy ? "Importing…" : `Import ${validation.validRows.toLocaleString()} ${validation.validRows === 1 ? "Deal" : "Deals"}`}
                  </Button>
                </div>
              </div>
              {!validation.validRows && (
                <p role="alert" className="mt-4 text-sm font-semibold text-red-700">All rows are invalid. Correct the CSV before importing.</p>
              )}
            </div>
          </Card>
        </section>
      )}

      {stage === "success" && result && (
        <section className="mt-5">
          <Card>
            <div className="flex min-h-[28rem] flex-col items-center justify-center p-6 text-center sm:p-10">
              <span className="flex size-20 items-center justify-center rounded-full bg-emerald-50 text-emerald-600">
                <FileCheck2 aria-hidden="true" className="size-9" />
              </span>
              <Badge tone="completed" className="mt-6">Import completed</Badge>
              <h2 className="mt-4 text-2xl font-bold tracking-tight text-slate-950">Deals imported successfully</h2>
              <p className="mt-3 max-w-xl text-sm leading-6 text-slate-600">
                {result.insertedCount.toLocaleString()} lost {result.insertedCount === 1 ? "deal is" : "deals are"} ready for analysis in {result.organizationName}. No AI analysis has started.
              </p>
              {result.invalidRows > 0 && <p className="mt-2 text-sm text-slate-500">{result.invalidRows.toLocaleString()} invalid {result.invalidRows === 1 ? "row was" : "rows were"} skipped as confirmed.</p>}
              <div className="mt-7 flex flex-col gap-3 sm:flex-row">
                <Link href="/deals" className={buttonStyles("secondary")}>View Deals <ArrowRight aria-hidden="true" className="size-4" /></Link>
                <Button type="button" variant="outline" onClick={resetImport}><RefreshCw aria-hidden="true" className="size-4" />Import Another File</Button>
              </div>
            </div>
          </Card>
        </section>
      )}

      <section className="mt-8">
        <Card title="Recent imports" description={`Real CSV imports for ${organizationName}.`}>
          {imports.length ? (
            <div className="divide-y divide-slate-100">
              {imports.map((item) => (
                <div key={item.id} className="flex flex-col gap-3 px-5 py-4 sm:flex-row sm:items-center sm:justify-between sm:px-6">
                  <div className="min-w-0">
                    <p className="truncate text-sm font-bold text-slate-900">{item.filename}</p>
                    <p className="mt-1 text-xs text-slate-500">{formatDate(item.createdAt)} · {item.rowsImported.toLocaleString()} rows imported</p>
                  </div>
                  <Badge tone={statusTone(item.status)}>{item.status}</Badge>
                </div>
              ))}
            </div>
          ) : recentImportsUnavailable ? (
            <div className="flex min-h-40 flex-col items-center justify-center px-6 py-8 text-center">
              <AlertCircle aria-hidden="true" className="size-7 text-amber-500" />
              <p className="mt-3 text-sm font-bold text-slate-800">Recent imports are temporarily unavailable</p>
              <p className="mt-1 text-xs leading-5 text-slate-500">Your import workflow still works. Refresh this page to try loading history again.</p>
            </div>
          ) : (
            <div className="flex min-h-40 flex-col items-center justify-center px-6 py-8 text-center">
              <FileSpreadsheet aria-hidden="true" className="size-7 text-slate-300" />
              <p className="mt-3 text-sm font-bold text-slate-800">No imports yet</p>
              <p className="mt-1 text-xs leading-5 text-slate-500">Your completed and failed CSV imports will appear here.</p>
            </div>
          )}
        </Card>
      </section>
    </div>
  );
}
