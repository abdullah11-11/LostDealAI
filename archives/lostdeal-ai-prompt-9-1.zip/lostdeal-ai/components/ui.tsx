import type {
  ButtonHTMLAttributes,
  InputHTMLAttributes,
  ReactNode,
  SelectHTMLAttributes,
  TableHTMLAttributes,
  TextareaHTMLAttributes,
} from "react";
import { LoaderCircle } from "lucide-react";

function cn(...classes: Array<string | false | null | undefined>) {
  return classes.filter(Boolean).join(" ");
}

type ButtonVariant = "primary" | "secondary" | "outline" | "ghost" | "destructive";

const buttonVariants: Record<ButtonVariant, string> = {
  primary: "bg-[#2952cc] text-white shadow-sm hover:bg-[#2347b3]",
  secondary: "bg-[#172554] text-white shadow-sm hover:bg-[#1e3a8a]",
  outline: "border border-slate-300 bg-white text-slate-700 hover:bg-slate-50 hover:text-slate-950",
  ghost: "text-slate-600 hover:bg-slate-100 hover:text-slate-950",
  destructive: "bg-red-600 text-white shadow-sm hover:bg-red-700",
};

export function buttonStyles(variant: ButtonVariant = "primary", className?: string) {
  return cn(
    "inline-flex h-10 items-center justify-center gap-2 rounded-xl px-4 text-sm font-bold transition-colors focus-visible:outline-none focus-visible:ring-4 focus-visible:ring-blue-100 disabled:cursor-not-allowed disabled:opacity-50",
    buttonVariants[variant],
    className,
  );
}

export function Button({
  variant = "primary",
  loading = false,
  className,
  children,
  disabled,
  ...props
}: ButtonHTMLAttributes<HTMLButtonElement> & { variant?: ButtonVariant; loading?: boolean }) {
  return (
    <button
      className={buttonStyles(variant, className)}
      disabled={disabled || loading}
      aria-busy={loading || undefined}
      {...props}
    >
      {loading && <LoaderCircle aria-hidden="true" className="size-4 animate-spin" />}
      {children}
    </button>
  );
}

export function Card({
  title,
  description,
  action,
  children,
  className,
}: {
  title?: string;
  description?: string;
  action?: ReactNode;
  children: ReactNode;
  className?: string;
}) {
  return (
    <article className={cn("rounded-2xl border border-slate-200 bg-white shadow-sm", className)}>
      {(title || description || action) && (
        <div className="flex flex-col gap-3 border-b border-slate-100 px-5 py-5 sm:flex-row sm:items-start sm:justify-between sm:px-6">
          <div>
            {title && <h2 className="text-base font-bold text-slate-950">{title}</h2>}
            {description && <p className="mt-1 text-sm leading-6 text-slate-500">{description}</p>}
          </div>
          {action}
        </div>
      )}
      {children}
    </article>
  );
}

type BadgeTone = "high" | "medium" | "low" | "pending" | "completed" | "failed" | "demo" | "neutral";

const badgeTones: Record<BadgeTone, string> = {
  high: "border-red-200 bg-red-50 text-red-700",
  medium: "border-amber-200 bg-amber-50 text-amber-700",
  low: "border-slate-200 bg-slate-100 text-slate-600",
  pending: "border-blue-200 bg-blue-50 text-blue-700",
  completed: "border-emerald-200 bg-emerald-50 text-emerald-700",
  failed: "border-red-200 bg-red-50 text-red-700",
  demo: "border-violet-200 bg-violet-50 text-violet-700",
  neutral: "border-slate-200 bg-white text-slate-600",
};

export function Badge({ tone = "neutral", children, className }: { tone?: BadgeTone; children: ReactNode; className?: string }) {
  return (
    <span className={cn("inline-flex w-fit items-center rounded-full border px-2.5 py-1 text-[10px] font-extrabold uppercase tracking-[0.08em]", badgeTones[tone], className)}>
      {children}
    </span>
  );
}

function FieldFrame({
  id,
  label,
  description,
  error,
  children,
}: {
  id: string;
  label: string;
  description?: string;
  error?: string;
  children: ReactNode;
}) {
  const helperId = description || error ? `${id}-help` : undefined;
  return (
    <div>
      <label htmlFor={id} className="block text-sm font-semibold text-slate-700">{label}</label>
      <div className="mt-2">{children}</div>
      {(error || description) && (
        <p id={helperId} className={cn("mt-2 text-xs leading-5", error ? "text-red-600" : "text-slate-500")}>
          {error || description}
        </p>
      )}
    </div>
  );
}

const fieldStyles = "h-11 w-full rounded-xl border border-slate-300 bg-white px-3.5 text-sm text-slate-900 outline-none transition placeholder:text-slate-400 focus:border-[#2952cc] focus:ring-4 focus:ring-blue-100 disabled:cursor-not-allowed disabled:bg-slate-100 disabled:text-slate-500";

export function Input({ id, label, description, error, className, ...props }: InputHTMLAttributes<HTMLInputElement> & { id: string; label: string; description?: string; error?: string }) {
  const helperId = description || error ? `${id}-help` : undefined;
  return (
    <FieldFrame id={id} label={label} description={description} error={error}>
      <input id={id} aria-describedby={helperId} aria-invalid={Boolean(error) || undefined} className={cn(fieldStyles, error && "border-red-400 focus:border-red-500 focus:ring-red-100", className)} {...props} />
    </FieldFrame>
  );
}

export function Select({ id, label, description, error, className, children, ...props }: SelectHTMLAttributes<HTMLSelectElement> & { id: string; label: string; description?: string; error?: string }) {
  const helperId = description || error ? `${id}-help` : undefined;
  return (
    <FieldFrame id={id} label={label} description={description} error={error}>
      <select id={id} aria-describedby={helperId} aria-invalid={Boolean(error) || undefined} className={cn(fieldStyles, error && "border-red-400 focus:border-red-500 focus:ring-red-100", className)} {...props}>
        {children}
      </select>
    </FieldFrame>
  );
}

export function Textarea({ id, label, description, error, className, ...props }: TextareaHTMLAttributes<HTMLTextAreaElement> & { id: string; label: string; description?: string; error?: string }) {
  const helperId = description || error ? `${id}-help` : undefined;
  return (
    <FieldFrame id={id} label={label} description={description} error={error}>
      <textarea id={id} aria-describedby={helperId} aria-invalid={Boolean(error) || undefined} className={cn(fieldStyles, "min-h-28 resize-y py-3", error && "border-red-400 focus:border-red-500 focus:ring-red-100", className)} {...props} />
    </FieldFrame>
  );
}

export function Table({ label, headers, children, className, ...props }: TableHTMLAttributes<HTMLTableElement> & { label: string; headers: string[]; children: ReactNode }) {
  return (
    <div className="overflow-x-auto">
      <table className={cn("w-full min-w-[760px] text-left", className)} aria-label={label} {...props}>
        <thead className="border-y border-slate-200 bg-slate-50 text-[10px] font-extrabold uppercase tracking-[0.1em] text-slate-500">
          <tr>{headers.map((header) => <th key={header} scope="col" className="whitespace-nowrap px-5 py-3.5">{header}</th>)}</tr>
        </thead>
        <tbody className="divide-y divide-slate-100">{children}</tbody>
      </table>
    </div>
  );
}

export function EmptyState({ icon, title, description, action }: { icon?: ReactNode; title: string; description: string; action?: ReactNode }) {
  return (
    <div className="flex min-h-56 flex-col items-center justify-center rounded-xl border border-dashed border-slate-300 bg-slate-50 px-6 py-10 text-center">
      {icon && <div className="flex size-12 items-center justify-center rounded-2xl bg-white text-[#2952cc] shadow-sm">{icon}</div>}
      <h3 className="mt-4 text-sm font-bold text-slate-900">{title}</h3>
      <p className="mt-2 max-w-md text-sm leading-6 text-slate-500">{description}</p>
      {action && <div className="mt-5">{action}</div>}
    </div>
  );
}

export function Skeleton({ className }: { className?: string }) {
  return <div aria-hidden="true" className={cn("animate-pulse rounded-lg bg-slate-200", className)} />;
}

export function StatCard({
  label,
  value,
  context,
  status,
  icon,
  loading = false,
}: {
  label: string;
  value: string;
  context: string;
  status?: ReactNode;
  icon?: ReactNode;
  loading?: boolean;
}) {
  return (
    <article className="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm">
      <div className="flex items-start justify-between gap-4">
        <div className="flex size-10 items-center justify-center rounded-xl bg-blue-50 text-[#2952cc]">{icon}</div>
        {status}
      </div>
      {loading ? <Skeleton className="mt-7 h-9 w-32" /> : <p className="mt-7 text-3xl font-semibold tracking-[-0.035em] text-[#0b1739]">{value}</p>}
      <p className="mt-2 text-sm font-bold text-slate-800">{label}</p>
      <p className="mt-1 text-xs leading-5 text-slate-500">{context}</p>
    </article>
  );
}
