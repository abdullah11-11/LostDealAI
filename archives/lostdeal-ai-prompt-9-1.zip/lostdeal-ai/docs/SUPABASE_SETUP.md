# Supabase setup for LostDeal AI V1

This guide connects a new Supabase project to the version-controlled database
architecture created in Prompt 3. The LostDeal AI interface remains demo-only
in this milestone; these steps prepare the database for the authentication and
data-connection work that follows.

## Current Prompt 3.5 connection status

The initial migration and `supabase/tests/schema_checks.sql` have already been
run manually against the current hosted Supabase project. Do not apply the
initial migration again. Future schema changes must use a new migration file.

The development connection uses only these client-safe values in `.env.local`:

- `NEXT_PUBLIC_SUPABASE_URL`
- `NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY`

Never commit `.env.local`. After configuring it, run `npm run verify:supabase`
to perform harmless anonymous reads against the six expected tables. A
permission-denied result is expected and confirms the Data API reached the
table while anonymous access remained blocked. The command reports statuses
only and never prints environment values or database rows.

## 1. Create a Supabase project

1. Go to [Supabase](https://supabase.com/dashboard) and create an account or
   sign in.
2. Select **New project**.
3. Choose an organization, project name, region, and a strong database
   password.
4. Store the database password in a password manager. Do not put it in this
   repository or in browser code.
5. Wait until the project finishes provisioning.

The official [Next.js quickstart](https://supabase.com/docs/guides/getting-started/quickstarts/nextjs)
shows the same Project URL and Publishable key setup used here.

## 2. Find the Project URL and Publishable key

1. Open the project in the Supabase Dashboard.
2. Open the project's **Connect** dialog. You can also use **Project Settings →
   API Keys** if the dashboard presents the values there.
3. Copy the **Project URL**.
4. Copy the **Publishable key**. New projects should use the key whose value
   starts with `sb_publishable_`.

The Publishable key identifies a public client and is safe to place in a web
application only when Row Level Security is correctly enabled. Read
[Understanding API keys](https://supabase.com/docs/guides/getting-started/api-keys)
for the current key types.

Do **not** copy a secret key, legacy `service_role` key, database password, or
connection string into client-side environment variables.

## 3. Create `.env.local`

At the project root, copy `.env.example` to a new file named `.env.local`.
Fill the public Supabase values and server-only OpenAI settings:

```dotenv
NEXT_PUBLIC_SUPABASE_URL=https://your-project-ref.supabase.co
NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY=sb_publishable_your_key_here
OPENAI_API_KEY=
OPENAI_MODEL=gpt-5.6
```

Set `OPENAI_API_KEY` only in `.env.local` or the production server secret store.
It is required for LostDeal AI analysis and must never use a `NEXT_PUBLIC_`
prefix. Recovery Score calculation and refresh do not use this key or make an
OpenAI request. `OPENAI_MODEL` selects the server-side analysis model.

`.env.local` is ignored by Git. Never commit it. The two `NEXT_PUBLIC_` values
will eventually be available to browser code, so their safety depends on the
database grants and RLS policies in the migration.

## 4. Apply the migration

The source of truth is:

`supabase/migrations/20260810000000_initial_lostdeal_schema.sql`

Use one of the following methods. Apply it to a new project only once.

### Option A — Supabase SQL Editor

1. Open **SQL Editor** in the Supabase Dashboard.
2. Create a new query.
3. Open the migration file locally and copy its complete contents into the
   editor.
4. Review that the target shown in the Dashboard is the correct project.
5. Select **Run**.
6. Confirm that the query completes without an error.

If it fails, keep the full error message and stop. Do not repeatedly run a
partially applied script without understanding the error. The migration uses a
transaction, so ordinary failures should roll back its changes.

### Option B — Supabase CLI

The [Supabase CLI documentation](https://supabase.com/docs/guides/local-development/cli/getting-started)
describes installation and project linking. A typical flow is:

```bash
npx supabase init
npx supabase login
npx supabase link --project-ref YOUR_PROJECT_REF
npx supabase db push
```

- Run `npx supabase init` only if the repository does not already contain
  `supabase/config.toml`.
- The project reference is the subdomain portion of your Project URL.
- Login may open a browser or request a personal access token. Never commit
  that token.
- `db push` applies unapplied files from `supabase/migrations/` to the linked
  project.

A local Docker-based Supabase stack is useful for deeper testing but is not
required to apply this Prompt 3 migration to a hosted project.

## 5. Verify the tables and RLS

In **Table Editor**, confirm these six tables exist in the `public` schema:

- `profiles`
- `organizations`
- `organization_members`
- `uploads`
- `deals`
- `deal_analyses`

Then open **SQL Editor**, paste the contents of
`supabase/tests/schema_checks.sql`, and run it. That file uses read-only
catalog queries and reports:

- whether every expected table exists;
- whether RLS is enabled;
- whether expected constraints, indexes, policies, triggers, and functions
  exist;
- whether `anon` received any application-table privilege;
- whether authenticated users can execute only the intended authorization
  helpers.

Every `present`, `rls_enabled`, and `configured_as_expected` result should be
`true`. The anonymous-grants result should return zero rows.

You can also run Supabase's **Security Advisor** and **Performance Advisor**.
The [advisor documentation](https://supabase.com/docs/guides/database/database-advisors)
explains what they inspect.

## 6. Understand the onboarding bootstrap

The first organization setup is intentionally a two-step operation:

1. The signed-in user inserts an organization with `created_by` equal to their
   own authenticated user ID.
2. That same user inserts the organization's first membership with themselves
   as `owner`.

Before the first membership exists, a narrow creator-only policy allows the
creator to read that organization. The initial membership policy succeeds only
when all of these are true:

- the caller created the organization;
- `user_id` is the caller's own user ID;
- `role` is `owner`;
- the organization has no membership yet.

As soon as the owner membership exists, ordinary membership becomes the access
mechanism. The helper functions are `SECURITY DEFINER` only to avoid recursive
RLS checks on `organization_members`; they live in a non-exposed `private`
schema, use an empty `search_path`, reference fully qualified table names,
return only booleans, and grant execution only to the `authenticated` role.

## 7. Test profile creation carefully

The migration adds a small trigger that creates `public.profiles` after a new
row is inserted into `auth.users`. Create a test user and confirm its profile
appears. Supabase explicitly warns that a broken `auth.users` trigger can block
signup, so investigate any signup database error before continuing.

See Supabase's [User Management guide](https://supabase.com/docs/guides/auth/managing-user-data)
for the recommended trigger pattern.

## Security rules to keep

- Never place a secret key, `service_role` key, database password, or personal
  access token in `NEXT_PUBLIC_` variables.
- Never disable RLS to make a frontend request work.
- Never rely on a frontend `organization_id` filter as the security boundary;
  the database policy is the boundary.
- Keep schema changes in versioned migration files.
- Do not grant application-table access to `anon` without a specific reviewed
  requirement.
- Test cross-organization access with two real test users before connecting
  production data.

Supabase's [Row Level Security guide](https://supabase.com/docs/guides/database/postgres/row-level-security)
and [Securing your API guide](https://supabase.com/docs/guides/api/securing-your-api)
explain why SQL grants and RLS must be used together.
