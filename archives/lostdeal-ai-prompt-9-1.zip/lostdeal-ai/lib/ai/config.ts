export const AI_CONFIG = Object.freeze({
  model: process.env.OPENAI_MODEL?.trim() || "gpt-5.6",
  sourceCharacterLimit: 50_000,
  batchSizeLimit: 25,
  batchConcurrency: 2,
  maxAutomaticRetries: 1,
  requestTimeoutMs: 45_000,
  maxOutputTokens: 2_000,
});

export function isOpenAIConfigured(): boolean {
  return Boolean(process.env.OPENAI_API_KEY?.trim());
}
