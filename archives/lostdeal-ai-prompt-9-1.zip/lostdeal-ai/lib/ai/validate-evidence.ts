import type { DealAnalysis, DealEvidence } from "@/lib/ai/deal-analysis-schema";
import { DealAnalysisError } from "@/lib/ai/errors";

function normalizeSourceText(value: string | null): string {
  return (value ?? "").replace(/\r\n?/g, "\n").replace(/[\t ]+/g, " ").replace(/ *\n */g, "\n").trim();
}

function normalizedExcerpt(value: string): string {
  return normalizeSourceText(value);
}

export function isEvidenceGrounded(
  evidence: DealEvidence,
  source: { salesNotes: string | null; transcript: string | null },
): boolean {
  const sourceText = evidence.source === "SALES_NOTES" ? source.salesNotes : source.transcript;
  const normalizedSource = normalizeSourceText(sourceText);
  const excerpt = normalizedExcerpt(evidence.excerpt);
  return Boolean(excerpt && normalizedSource.includes(excerpt));
}

export function validateAndGroundEvidence(
  analysis: DealAnalysis,
  source: { salesNotes: string | null; transcript: string | null },
): DealAnalysis {
  const grounded: DealEvidence[] = [];
  const seen = new Set<string>();
  let unsupported = 0;

  for (const evidence of analysis.evidence) {
    if (!isEvidenceGrounded(evidence, source)) {
      unsupported += 1;
      continue;
    }
    const excerpt = normalizedExcerpt(evidence.excerpt);
    const key = `${evidence.source}:${excerpt.toLocaleLowerCase("en-US")}`;
    if (seen.has(key)) continue;
    seen.add(key);
    grounded.push({ ...evidence, excerpt });
  }

  if (unsupported >= 2 || (analysis.evidence.length > 0 && grounded.length === 0)) {
    throw new DealAnalysisError("AI_RESPONSE_INVALID");
  }

  return { ...analysis, evidence: grounded };
}
