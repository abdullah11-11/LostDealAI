import {
  CANONICAL_FIELDS,
  FIELD_DETAILS,
  type CanonicalField,
} from "@/lib/csv/constants";

export type ColumnMapping = Record<CanonicalField, number | null>;

const HEADER_ALIASES: Record<CanonicalField, readonly string[]> = {
  external_deal_id: [
    "external deal id",
    "deal id",
    "id",
    "opportunity id",
    "estimate id",
    "quote id",
  ],
  customer_name: ["customer", "customer name", "client", "client name", "name"],
  deal_value: [
    "deal value",
    "value",
    "amount",
    "quote value",
    "quote amount",
    "estimate",
    "estimate value",
    "price",
    "revenue",
  ],
  quote_date: [
    "quote date",
    "estimate date",
    "date",
    "created date",
    "opportunity date",
  ],
  status: ["status", "deal status", "opportunity status"],
  salesperson: ["salesperson", "sales rep", "rep", "agent", "technician"],
  service_type: ["service", "service type", "job type", "product", "product type"],
  lead_source: ["lead source", "source", "marketing source"],
  sales_notes: ["sales notes", "notes", "note", "comments", "sales comments"],
  transcript: [
    "transcript",
    "call transcript",
    "conversation",
    "conversation transcript",
  ],
};

export function normalizeHeader(value: string): string {
  return value
    .replace(/^\uFEFF/, "")
    .trim()
    .toLocaleLowerCase("en-US")
    .replace(/[_-]+/g, " ")
    .replace(/\s+/g, " ");
}

export function emptyColumnMapping(): ColumnMapping {
  return Object.fromEntries(CANONICAL_FIELDS.map((field) => [field, null])) as ColumnMapping;
}

export function autoMapColumns(headers: readonly string[]): ColumnMapping {
  const mapping = emptyColumnMapping();
  const normalizedHeaders = headers.map(normalizeHeader);
  const used = new Set<number>();

  for (const field of CANONICAL_FIELDS) {
    const aliases = new Set(HEADER_ALIASES[field]);
    const index = normalizedHeaders.findIndex(
      (header, headerIndex) => !used.has(headerIndex) && aliases.has(header),
    );
    if (index >= 0) {
      mapping[field] = index;
      used.add(index);
    }
  }

  return mapping;
}

export function validateColumnMapping(
  mapping: ColumnMapping,
  headerCount: number,
): string[] {
  const errors: string[] = [];
  const mapped = new Map<number, CanonicalField>();

  for (const field of CANONICAL_FIELDS) {
    const columnIndex = mapping[field];
    if (columnIndex === null) continue;
    if (!Number.isInteger(columnIndex) || columnIndex < 0 || columnIndex >= headerCount) {
      errors.push(`${FIELD_DETAILS[field].label} has an invalid source column.`);
      continue;
    }
    const existingField = mapped.get(columnIndex);
    if (existingField) {
      errors.push(
        `One CSV column cannot map to both ${FIELD_DETAILS[existingField].label} and ${FIELD_DETAILS[field].label}.`,
      );
    } else {
      mapped.set(columnIndex, field);
    }
  }

  if (mapping.deal_value === null) errors.push("Map a CSV column to Deal value.");
  if (mapping.sales_notes === null && mapping.transcript === null) {
    errors.push(
      "LostDeal AI needs sales notes or a transcript to understand why a deal was lost.",
    );
  }

  return errors;
}

export function parseColumnMapping(value: unknown, headerCount: number): ColumnMapping | null {
  if (!value || typeof value !== "object") return null;
  const candidate = value as Record<string, unknown>;
  const mapping = emptyColumnMapping();

  for (const field of CANONICAL_FIELDS) {
    const columnIndex = candidate[field];
    if (columnIndex === null) {
      mapping[field] = null;
    } else if (
      typeof columnIndex === "number" &&
      Number.isInteger(columnIndex) &&
      columnIndex >= 0 &&
      columnIndex < headerCount
    ) {
      mapping[field] = columnIndex;
    } else {
      return null;
    }
  }

  return mapping;
}

