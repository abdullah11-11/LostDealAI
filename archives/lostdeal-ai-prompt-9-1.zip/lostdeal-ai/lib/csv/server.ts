import "server-only";

import { MAX_CSV_FILE_BYTES, VALIDATION_PREVIEW_ROWS } from "@/lib/csv/constants";
import {
  parseColumnMapping,
  validateColumnMapping,
  type ColumnMapping,
} from "@/lib/csv/mapping";
import {
  parseCsvText,
  validateCsvFileMetadata,
  validateCsvRows,
  validateParsedCsvShape,
  type CsvValidationResult,
  type InvalidCsvRow,
  type NormalizedDeal,
  type ParsedCsv,
} from "@/lib/csv/validation";
import { createClient } from "@/lib/supabase/server";

type ServerSupabaseClient = Awaited<ReturnType<typeof createClient>>;

export class CsvImportError extends Error {
  constructor(
    message: string,
    public readonly status = 400,
  ) {
    super(message);
    this.name = "CsvImportError";
  }
}

export type AuthoritativeCsvValidation = {
  filename: string;
  parsed: ParsedCsv;
  mapping: ColumnMapping;
  validation: CsvValidationResult;
};

export type CsvPreviewRow = Pick<
  NormalizedDeal,
  | "rowNumber"
  | "customer_name"
  | "deal_value"
  | "quote_date"
  | "service_type"
  | "salesperson"
> & { context: string };

export type CsvValidationResponse = {
  totalRows: number;
  validRows: number;
  invalidRows: number;
  blankRows: number;
  malformedRows: number;
  invalid: InvalidCsvRow[];
  preview: CsvPreviewRow[];
};

function safeFilename(name: string): string {
  return name
    .replace(/[\u0000-\u001F\u007F]/g, "")
    .replace(/[\\/]+/g, "_")
    .trim();
}

async function readUtf8File(file: File): Promise<string> {
  if (file.size > MAX_CSV_FILE_BYTES) {
    throw new CsvImportError("This file is larger than 5 MB. Choose a smaller CSV.");
  }
  try {
    return new TextDecoder("utf-8", { fatal: true }).decode(await file.arrayBuffer());
  } catch {
    throw new CsvImportError("The CSV must use valid UTF-8 text encoding.");
  }
}

async function existingExternalIds(
  supabase: ServerSupabaseClient,
  organizationId: string,
  candidateIds: readonly string[],
): Promise<Set<string>> {
  const existing = new Set<string>();
  const uniqueIds = Array.from(new Set(candidateIds));

  for (let offset = 0; offset < uniqueIds.length; offset += 100) {
    const batch = uniqueIds.slice(offset, offset + 100);
    if (!batch.length) continue;
    const { data, error } = await supabase
      .from("deals")
      .select("external_deal_id")
      .eq("organization_id", organizationId)
      .in("external_deal_id", batch);
    if (error) {
      throw new CsvImportError(
        "LostDeal AI could not check existing deal IDs. Please try again.",
        503,
      );
    }
    for (const row of data ?? []) {
      if (row.external_deal_id) {
        existing.add(row.external_deal_id.toLocaleLowerCase("en-US"));
      }
    }
  }

  return existing;
}

export async function validateCsvFormData(
  formData: FormData,
  supabase: ServerSupabaseClient,
  organizationId: string,
): Promise<AuthoritativeCsvValidation> {
  const fileValue = formData.get("file");
  if (!(fileValue instanceof File)) throw new CsvImportError("Choose a CSV file to continue.");

  const fileError = validateCsvFileMetadata(fileValue);
  if (fileError) throw new CsvImportError(fileError);
  const filename = safeFilename(fileValue.name);
  const parsed = parseCsvText(await readUtf8File(fileValue));
  const shapeError = validateParsedCsvShape(parsed);
  if (shapeError) throw new CsvImportError(shapeError);

  const mappingValue = formData.get("mapping");
  if (typeof mappingValue !== "string") {
    throw new CsvImportError("Column mapping is missing. Return to the mapping step.");
  }

  let mappingJson: unknown;
  try {
    mappingJson = JSON.parse(mappingValue);
  } catch {
    throw new CsvImportError("Column mapping is invalid. Return to the mapping step.");
  }
  const mapping = parseColumnMapping(mappingJson, parsed.headers.length);
  if (!mapping) throw new CsvImportError("Column mapping is invalid. Return to the mapping step.");
  const mappingErrors = validateColumnMapping(mapping, parsed.headers.length);
  if (mappingErrors.length) throw new CsvImportError(mappingErrors.join(" "));

  const preliminary = validateCsvRows(parsed, mapping);
  const candidates = preliminary.validRows
    .map((row) => row.external_deal_id)
    .filter((value): value is string => Boolean(value));
  const existingIds = await existingExternalIds(supabase, organizationId, candidates);
  const validation = validateCsvRows(parsed, mapping, existingIds);

  return { filename, parsed, mapping, validation };
}

function previewContext(row: NormalizedDeal): string {
  if (row.transcript) return "Transcript available";
  if (!row.sales_notes) return "No context";
  return row.sales_notes.length > 78 ? `${row.sales_notes.slice(0, 78)}…` : row.sales_notes;
}

export function toCsvValidationResponse(
  result: AuthoritativeCsvValidation,
): CsvValidationResponse {
  const { parsed, validation } = result;
  return {
    totalRows: validation.totalRows,
    validRows: validation.validRows.length,
    invalidRows: validation.invalidRows.length,
    blankRows: parsed.blankRows,
    malformedRows: parsed.malformedRows,
    invalid: validation.invalidRows,
    preview: validation.validRows.slice(0, VALIDATION_PREVIEW_ROWS).map((row) => ({
      rowNumber: row.rowNumber,
      customer_name: row.customer_name,
      deal_value: row.deal_value,
      quote_date: row.quote_date,
      service_type: row.service_type,
      salesperson: row.salesperson,
      context: previewContext(row),
    })),
  };
}

