-- LostDeal AI V1 — Prompt 3
-- Read-only verification queries for a Supabase SQL Editor session.
-- These checks inspect PostgreSQL catalogs; they do not insert, update, or
-- delete application data.

-- 1. Expected public tables exist.
with expected (table_name) as (
  values
    ('profiles'),
    ('organizations'),
    ('organization_members'),
    ('uploads'),
    ('deals'),
    ('deal_analyses')
)
select
  'table' as check_type,
  expected.table_name as object_name,
  to_regclass(format('public.%I', expected.table_name)) is not null as present
from expected
order by expected.table_name;

-- 2. RLS is enabled on every application table.
with expected (table_name) as (
  values
    ('profiles'),
    ('organizations'),
    ('organization_members'),
    ('uploads'),
    ('deals'),
    ('deal_analyses')
)
select
  'rls' as check_type,
  expected.table_name as object_name,
  coalesce(pg_class.relrowsecurity, false) as rls_enabled
from expected
left join pg_catalog.pg_namespace
  on pg_namespace.nspname = 'public'
left join pg_catalog.pg_class
  on pg_class.relnamespace = pg_namespace.oid
  and pg_class.relname = expected.table_name
  and pg_class.relkind = 'r'
order by expected.table_name;

-- 3. Required constraints exist.
with expected (table_name, constraint_name) as (
  values
    ('organizations', 'organizations_name_not_empty'),
    ('organization_members', 'organization_members_organization_id_user_id_key'),
    ('organization_members', 'organization_members_role_valid'),
    ('uploads', 'uploads_organization_id_id_key'),
    ('uploads', 'uploads_filename_not_empty'),
    ('uploads', 'uploads_total_rows_nonnegative'),
    ('uploads', 'uploads_valid_rows_nonnegative'),
    ('uploads', 'uploads_invalid_rows_nonnegative'),
    ('uploads', 'uploads_status_valid'),
    ('deals', 'deals_organization_id_id_key'),
    ('deals', 'deals_upload_belongs_to_organization'),
    ('deals', 'deals_deal_value_nonnegative'),
    ('deals', 'deals_status_valid'),
    ('deals', 'deals_analysis_status_valid'),
    ('deal_analyses', 'deal_analyses_deal_id_key'),
    ('deal_analyses', 'deal_analyses_deal_belongs_to_organization'),
    ('deal_analyses', 'deal_analyses_lost_reason_valid'),
    ('deal_analyses', 'deal_analyses_buying_intent_score_range'),
    ('deal_analyses', 'deal_analyses_recovery_score_range'),
    ('deal_analyses', 'deal_analyses_confidence_score_range'),
    ('deal_analyses', 'deal_analyses_recovery_priority_valid'),
    ('deal_analyses', 'deal_analyses_recommended_channel_valid'),
    ('deal_analyses', 'deal_analyses_evidence_is_array'),
    ('deal_analyses', 'deal_analyses_positive_signals_is_array'),
    ('deal_analyses', 'deal_analyses_negative_signals_is_array')
)
select
  'constraint' as check_type,
  expected.table_name || '.' || expected.constraint_name as object_name,
  pg_constraint.oid is not null as present
from expected
left join pg_catalog.pg_constraint
  on pg_constraint.conrelid = to_regclass('public.' || expected.table_name)
  and pg_constraint.conname = expected.constraint_name
order by expected.table_name, expected.constraint_name;

-- 4. Required indexes exist. A unique constraint index satisfies the deal_id
-- and organization_id membership lookup requirements noted in the migration.
with expected (index_name) as (
  values
    ('organization_members_organization_id_user_id_key'),
    ('organization_members_user_id_idx'),
    ('uploads_organization_id_idx'),
    ('deals_organization_id_idx'),
    ('deals_upload_id_idx'),
    ('deals_quote_date_idx'),
    ('deals_analysis_status_idx'),
    ('deals_organization_external_deal_id_unique_idx'),
    ('deal_analyses_organization_id_idx'),
    ('deal_analyses_deal_id_key')
)
select
  'index' as check_type,
  expected.index_name as object_name,
  pg_indexes.indexname is not null as present
from expected
left join pg_catalog.pg_indexes
  on pg_indexes.schemaname = 'public'
  and pg_indexes.indexname = expected.index_name
order by expected.index_name;

-- 5. Required RLS policies exist.
with expected (table_name, policy_name) as (
  values
    ('profiles', 'profiles_select_own'),
    ('profiles', 'profiles_update_own'),
    ('organizations', 'organizations_insert_own'),
    ('organizations', 'organizations_select_member_or_bootstrap_creator'),
    ('organizations', 'organizations_update_owner'),
    ('organization_members', 'organization_members_select_org_member'),
    ('organization_members', 'organization_members_insert_initial_owner'),
    ('uploads', 'uploads_select_org_member'),
    ('uploads', 'uploads_insert_org_member'),
    ('uploads', 'uploads_update_org_member'),
    ('deals', 'deals_select_org_member'),
    ('deals', 'deals_insert_org_member'),
    ('deals', 'deals_update_org_member'),
    ('deal_analyses', 'deal_analyses_select_org_member'),
    ('deal_analyses', 'deal_analyses_insert_org_member'),
    ('deal_analyses', 'deal_analyses_update_org_member')
)
select
  'policy' as check_type,
  expected.table_name || '.' || expected.policy_name as object_name,
  pg_policies.policyname is not null as present
from expected
left join pg_catalog.pg_policies
  on pg_policies.schemaname = 'public'
  and pg_policies.tablename = expected.table_name
  and pg_policies.policyname = expected.policy_name
order by expected.table_name, expected.policy_name;

-- 6. Automatic profile and updated_at triggers exist.
with expected (schema_name, table_name, trigger_name) as (
  values
    ('auth', 'users', 'on_auth_user_created'),
    ('public', 'profiles', 'profiles_set_updated_at'),
    ('public', 'organizations', 'organizations_set_updated_at'),
    ('public', 'uploads', 'uploads_set_updated_at'),
    ('public', 'deals', 'deals_set_updated_at'),
    ('public', 'deal_analyses', 'deal_analyses_set_updated_at')
)
select
  'trigger' as check_type,
  expected.schema_name || '.' || expected.table_name || '.' || expected.trigger_name
    as object_name,
  pg_trigger.oid is not null as present
from expected
left join pg_catalog.pg_trigger
  on pg_trigger.tgrelid = to_regclass(
    format('%I.%I', expected.schema_name, expected.table_name)
  )
  and pg_trigger.tgname = expected.trigger_name
  and not pg_trigger.tgisinternal
order by expected.schema_name, expected.table_name, expected.trigger_name;

-- 7. Security-definer helpers exist, use a configured search_path, and expose
-- only the intended EXECUTE access.
with expected (function_signature, security_definer_expected) as (
  values
    ('private.handle_new_user()', true),
    ('private.is_org_member(uuid)', true),
    ('private.is_org_owner(uuid)', true),
    ('private.can_read_organization_during_bootstrap(uuid)', true),
    ('private.can_bootstrap_organization_membership(uuid,uuid,text)', true),
    ('public.set_updated_at()', false)
)
select
  'function_security' as check_type,
  expected.function_signature as object_name,
  pg_proc.oid is not null
    and pg_proc.prosecdef = expected.security_definer_expected
    and coalesce(array_to_string(pg_proc.proconfig, ','), '') like '%search_path=%'
    as configured_as_expected
from expected
left join pg_catalog.pg_proc
  on pg_proc.oid = to_regprocedure(expected.function_signature)
order by expected.function_signature;

with helpers (function_signature) as (
  values
    ('private.is_org_member(uuid)'),
    ('private.is_org_owner(uuid)'),
    ('private.can_read_organization_during_bootstrap(uuid)'),
    ('private.can_bootstrap_organization_membership(uuid,uuid,text)')
)
select
  'helper_execute_grant' as check_type,
  helpers.function_signature as object_name,
  has_function_privilege('authenticated', helpers.function_signature, 'execute')
    and not has_function_privilege('anon', helpers.function_signature, 'execute')
    as configured_as_expected
from helpers
order by helpers.function_signature;

-- 8. Anonymous users have no privilege on application tables. Expected result:
-- configured_as_expected = true.
select
  'anonymous_table_grants' as check_type,
  'public application tables' as object_name,
  count(*) = 0 as configured_as_expected
from information_schema.table_privileges
where grantee = 'anon'
  and table_schema = 'public'
  and table_name in (
    'profiles',
    'organizations',
    'organization_members',
    'uploads',
    'deals',
    'deal_analyses'
  );

-- 9. Authenticated users can read through RLS, but no application table grants
-- DELETE. Expected: can_select = true and can_delete = false for every row.
with expected (table_name) as (
  values
    ('profiles'),
    ('organizations'),
    ('organization_members'),
    ('uploads'),
    ('deals'),
    ('deal_analyses')
)
select
  'authenticated_table_grants' as check_type,
  expected.table_name as object_name,
  has_table_privilege(
    'authenticated',
    format('public.%I', expected.table_name),
    'select'
  ) as can_select,
  has_table_privilege(
    'authenticated',
    format('public.%I', expected.table_name),
    'delete'
  ) as can_delete
from expected
order by expected.table_name;
