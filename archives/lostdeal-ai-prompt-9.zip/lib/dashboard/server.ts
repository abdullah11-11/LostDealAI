import "server-only";

import { calculateDashboardMetrics, selectTopRecoveryOpportunities, tenantRecentImports } from "@/lib/dashboard/metrics";
import type {
  DashboardAnalysisRecord,
  DashboardData,
  DashboardDealRecord,
  DashboardUploadRecord,
} from "@/lib/dashboard/types";
import { createClient } from "@/lib/supabase/server";
import { LOST_REASONS, RECOVERY_PRIORITIES, UPLOAD_STATUSES } from "@/types/database";
import type { LostReason, RecoveryPriority, UploadStatus } from "@/types/database";

type ServerSupabaseClient = Awaited<ReturnType<typeof createClient>>;

export const DASHBOARD_QUERY_PAGE_SIZE = 1_000;
export const TOP_OPPORTUNITY_LIMIT = 5;
export const RECENT_IMPORT_LIMIT = 5;

const LOST_REASON_SET = new Set<string>(LOST_REASONS);
const PRIORITY_SET = new Set<string>(RECOVERY_PRIORITIES);
const UPLOAD_STATUS_SET = new Set<string>(UPLOAD_STATUSES);

export const DASHBOARD_ANALYSIS_FIELDS = "id,lost_reason,recovery_score,recovery_priority,recommended_action,model_metadata";
export const DASHBOARD_DEAL_FIELDS = `id,organization_id,customer_name,deal_value,quote_date,service_type,analysis_status,created_at,deal_analyses(${DASHBOARD_ANALYSIS_FIELDS})`;
export const TOP_OPPORTUNITY_FIELDS = `id,organization_id,customer_name,deal_value,quote_date,service_type,analysis_status,created_at,deal_analyses!inner(${DASHBOARD_ANALYSIS_FIELDS})`;

function objectRecord(value: unknown): Record<string, unknown> | null {
  return value && typeof value === "object" && !Array.isArray(value) ? value as Record<string, unknown> : null;
}

function relatedRecord(value: unknown): Record<string, unknown> | null {
  const candidate = Array.isArray(value) ? value[0] : value;
  return objectRecord(candidate);
}

function nullableString(value: unknown): string | null {
  return typeof value === "string" && value.trim() ? value : null;
}

function scoringCalculatedAt(metadataValue: unknown): string | null {
  const metadata = objectRecord(metadataValue);
  const scoring = objectRecord(metadata?.scoring);
  return nullableString(scoring?.calculated_at);
}

function normalizeAnalysis(value: unknown): DashboardAnalysisRecord | null {
  const row = relatedRecord(value);
  if (!row || typeof row.id !== "string") return null;
  const rawReason = nullableString(row.lost_reason);
  const rawPriority = nullableString(row.recovery_priority);
  const rawScore = row.recovery_score;
  return {
    id: row.id,
    lostReason: rawReason && LOST_REASON_SET.has(rawReason) ? rawReason as LostReason : null,
    recoveryScore: typeof rawScore === "number" && Number.isInteger(rawScore) && rawScore >= 0 && rawScore <= 100
      ? rawScore
      : null,
    recoveryPriority: rawPriority && PRIORITY_SET.has(rawPriority) ? rawPriority as RecoveryPriority : null,
    recommendedAction: nullableString(row.recommended_action),
    scoringCalculatedAt: scoringCalculatedAt(row.model_metadata),
  };
}

export function normalizeDashboardDeal(value: unknown): DashboardDealRecord | null {
  const row = objectRecord(value);
  if (
    !row ||
    typeof row.id !== "string" ||
    typeof row.organization_id !== "string" ||
    typeof row.analysis_status !== "string" ||
    typeof row.created_at !== "string"
  ) return null;
  const dealValue = Number(row.deal_value);
  return {
    id: row.id,
    organizationId: row.organization_id,
    customerName: nullableString(row.customer_name),
    dealValue: Number.isFinite(dealValue) ? dealValue : 0,
    quoteDate: nullableString(row.quote_date),
    serviceType: nullableString(row.service_type),
    analysisStatus: row.analysis_status,
    createdAt: row.created_at,
    analysis: normalizeAnalysis(row.deal_analyses),
  };
}

function normalizeUpload(value: unknown): DashboardUploadRecord | null {
  const row = objectRecord(value);
  const status = nullableString(row?.status);
  if (
    !row ||
    typeof row.id !== "string" ||
    typeof row.organization_id !== "string" ||
    typeof row.filename !== "string" ||
    !status ||
    !UPLOAD_STATUS_SET.has(status) ||
    typeof row.created_at !== "string" ||
    typeof row.updated_at !== "string"
  ) return null;
  return {
    id: row.id,
    organizationId: row.organization_id,
    filename: row.filename,
    status: status as UploadStatus,
    totalRows: typeof row.total_rows === "number" ? row.total_rows : 0,
    validRows: typeof row.valid_rows === "number" ? row.valid_rows : 0,
    invalidRows: typeof row.invalid_rows === "number" ? row.invalid_rows : 0,
    createdAt: row.created_at,
    updatedAt: row.updated_at,
  };
}

async function fetchAllDashboardDeals(
  supabase: ServerSupabaseClient,
  organizationId: string,
): Promise<DashboardDealRecord[]> {
  const records: DashboardDealRecord[] = [];
  let offset = 0;
  let expectedCount: number | null = null;

  do {
    const { data, error, count } = await supabase
      .from("deals")
      .select(DASHBOARD_DEAL_FIELDS, { count: "exact" })
      .eq("organization_id", organizationId)
      .order("id", { ascending: true })
      .range(offset, offset + DASHBOARD_QUERY_PAGE_SIZE - 1);
    if (error) throw new Error("DASHBOARD_DEALS_QUERY_FAILED");
    expectedCount = count ?? expectedCount;
    const page = (data ?? []).map(normalizeDashboardDeal).filter((deal): deal is DashboardDealRecord => Boolean(deal));
    records.push(...page);
    const returnedRows = data?.length ?? 0;
    if (returnedRows === 0) break;
    offset += returnedRows;
  } while (expectedCount === null || offset < expectedCount);

  return records;
}

async function fetchTopOpportunities(
  supabase: ServerSupabaseClient,
  organizationId: string,
): Promise<DashboardDealRecord[]> {
  const { data, error } = await supabase
    .from("deals")
    .select(TOP_OPPORTUNITY_FIELDS)
    .eq("organization_id", organizationId)
    .not("deal_analyses.recovery_score", "is", null)
    .not("deal_analyses.lost_reason", "is", null)
    .order("deal_analyses(recovery_score)", { ascending: false, nullsFirst: false })
    .order("deal_value", { ascending: false, nullsFirst: false })
    .order("quote_date", { ascending: false, nullsFirst: false })
    .order("id", { ascending: true })
    .limit(TOP_OPPORTUNITY_LIMIT);
  if (error) throw new Error("DASHBOARD_TOP_QUERY_FAILED");
  return selectTopRecoveryOpportunities(
    (data ?? []).map(normalizeDashboardDeal).filter((deal): deal is DashboardDealRecord => Boolean(deal)),
    organizationId,
    TOP_OPPORTUNITY_LIMIT,
  );
}

async function fetchRecentImports(
  supabase: ServerSupabaseClient,
  organizationId: string,
): Promise<DashboardUploadRecord[]> {
  const { data, error } = await supabase
    .from("uploads")
    .select("id,organization_id,filename,status,total_rows,valid_rows,invalid_rows,created_at,updated_at")
    .eq("organization_id", organizationId)
    .order("created_at", { ascending: false })
    .order("id", { ascending: true })
    .limit(RECENT_IMPORT_LIMIT);
  if (error) throw new Error("DASHBOARD_IMPORTS_QUERY_FAILED");
  return (data ?? []).map(normalizeUpload).filter((upload): upload is DashboardUploadRecord => Boolean(upload));
}

export async function getDashboardData(
  supabase: ServerSupabaseClient,
  organizationId: string,
): Promise<DashboardData> {
  try {
    const [deals, topOpportunities, recentImports] = await Promise.all([
      fetchAllDashboardDeals(supabase, organizationId),
      fetchTopOpportunities(supabase, organizationId),
      fetchRecentImports(supabase, organizationId),
    ]);
    return {
      metrics: calculateDashboardMetrics(deals, organizationId),
      topOpportunities,
      recentImports: tenantRecentImports(recentImports, organizationId, RECENT_IMPORT_LIMIT),
      error: false,
    };
  } catch {
    return {
      metrics: calculateDashboardMetrics([], organizationId),
      topOpportunities: [],
      recentImports: [],
      error: true,
    };
  }
}
